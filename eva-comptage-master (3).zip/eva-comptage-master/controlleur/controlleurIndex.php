<?php
	require_once './model/modelIndex.php';
	require_once "./model/modelComptage.php";

	$page['css']= '<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		<link href="css/index.css" rel="stylesheet">';
	$page['script']= '
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/index.js"></script>';

	if ($date) {
		$Y = substr($date, 0, 4);
		$m = substr($date, 5, -3);
	} else {
		$Y = date('Y');
		$m = date('m');
	}

	if (array_key_exists('stationgroup_id', $_POST)) {
		$stg_id = $_POST['stationgroup_id'];
	} else {
		$stg_id = 1;
	}

	$yearsOption = '';
	for($i=2016; $i<=date('Y'); $i++)
		$yearsOption .= "\t<option value=\"" . $i . "\" " . (($i == $Y) ? ' selected="selected"' : '') . '>' . $i . "</option>\n";

	$monthOption = '';
	for($i=1; $i<=12; $i++)
		$monthOption .= "\t<option value=\"" . $i . "\" " . (($i == $m) ? ' selected="selected"' : '') . '>' . $i . "</option>\n";


	$dateSelector = "<div id=\"dateSelector\"><label for=\"yearSelector\">Année:</label><select id=\"yearSelector\" name=\"annees\" onchange=\"updatePage()\">\n" . $yearsOption . "</select>\n<label for=\"monthSelector\">Mois:</label><select id=\"monthSelector\" name=\"mois\" onchange=\"updatePage()\">\n" . $monthOption . "</select></div>\n";

	$stgData = getStationGroupe();

	$stgOption = '';
	foreach ($stgData as $stg) {
		$stgOption .= "\t<option value=\"" . $stg['stationgroup_id'] . "\" " . (($stg['stationgroup_id'] == $stg_id) ? ' selected="selected"' : '') . '>' . $stg['stationgroup_name'] . "</option>\n";
	}
	$stgSelector = "<div id=\"stgSelector\"><label for=\"stgSelector\">Groupe de Stations:</label><select id=\"stgSelector\" name=\"stationgroup_id\" onchange=\"\">\n" . $stgOption . "</select>";
	
	$station = '<div id="stationData">' . getStationData($date) . '</div>';
	$facture = '<div id="stationData">' . getFactureForm($date, $stgOption, $stg_id) . '</div>';
?>