<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/* ***************************************    Fonction concernant la partie station    *************************************** */


function getDeviceDataByStation($date, $stationName, $readonly){
	$db = connectRW("comptage");
	$date = new DateTime($date . " 10:00:00.000");
	$date2= DateTime::createFromFormat('U', strtotime('first day of -1 month', $date->getTimestamp()));
	$fromDB1 = 1;
	$fromDB2 = 1;

	$devicestm1 = $db->prepare("SELECT device.device_name, `device`.`device_id` FROM device INNER JOIN station ON device.station_station_id=station.station_id WHERE station.station_name=:station_name ORDER BY `device`.`device_id` ASC");
	$datastm1 = $db->prepare("SELECT device.device_id, `index`.`index_fromuser`, `index`.`index_rate_+1_value`, `index`.`index_rate_-1_value`, `index`.`index_rate_+2_value`, `index`.`index_rate_-2_value`, `index`.`index_rate_+1_operator`, `index`.`index_rate_-1_operator`, `index`.`index_rate_+2_operator`, `index`.`index_rate_-2_operator` FROM station INNER JOIN device ON device.station_station_id=station.station_id INNER JOIN `index` ON `index`.device_device_id=device.device_id WHERE station.station_name=:station_name  AND `index`.`index_date` = :ts ORDER BY `device`.`device_id` ASC");
	$datastm1->execute(array("station_name" => $stationName, "ts" => $date->format('Y-m') . '-01'));
	$data1 = $datastm1->fetchAll();
	$datastm1->execute(array("station_name" => $stationName, "ts" => $date2->format('Y-m') . '-01'));
	$data2 = $datastm1->fetchAll();
	$devicestm1->execute(array("station_name" => $stationName));
	$data = $devicestm1->fetchAll();
	$deviceStr = "<table class=\"bilanTable table table-condensed table-striped\">\n\t<tr>\n\t\t<th>Nom</th>\n\t\t<th>Index rate</th>\n\t</tr>";
	foreach ($data as $i => $tab) {
		$deviceStr .= "<tr><td>" . $tab['device_name'] . "</td><th><table class=\"bilanTable table table-condensed table-striped\"><tr><th></th><th>" . $date->format('Y-m') . '-01' . "</th><th>" . $date2->format('Y-m') . '-01' . "</th><th>Opérateur</th><th>Activer</th></tr>";
		$rate = array('+1', '+2', '-1', '-2');
		foreach ( $rate as $key) {
			$fromDB1 = (!empty($data1) && isset($data1[$i]));
			$fromDB2 = (!empty($data2) && isset($data2[$i]));
			$fromUser1 = ($fromDB1 && !$data1[$i]['index_fromuser']);
			$fromUser2 = ($fromDB2 && !$data2[$i]['index_fromuser']);

			$deviceStr .= "<tr><td>Index rate" . $key . "</td>" . 
			"<td><input type=\"text\" class=\"myInput\" " . (($readonly || $fromUser1) ? "readonly=\"readonly\"" : '') . " name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_value][0]\" value=\"" . (($fromDB1) ? $data1[$i]['index_rate_' . $key . '_value'] : "0") . "\">" . "</td>" . 
			"<td><input type=\"text\" class=\"myInput\" " . (($readonly || $fromUser2) ? "readonly=\"readonly\"" : '') . " name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_value][1]\" value=\"" . (($fromDB2) ? $data2[$i]['index_rate_' . $key . '_value'] : "0") . "\">" . "</td>" . 
			"<td><select type=\"text\" class=\"myInput myOperatorInput\" " . (($readonly) ? "readonly=\"readonly\"" : '') . " maxlength=\"1\" name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_operator]\" value=\"" . (($fromDB1) ? $data1[$i]['index_rate_' . $key . '_operator'] : "+") . "\" >" .
				"<option value=\"+\" " . (($fromDB1 && $data1[$i]['index_rate_' . $key . '_operator'] == '+') ? ' selected="selected"' : '') . "> + </option>" .
				"<option value=\"-\" " . (($fromDB1 && $data1[$i]['index_rate_' . $key . '_operator'] == '-') ? ' selected="selected"' : '') . "> - </option></select></td>". 
			"<td><input type=\"checkbox\" name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_activated]\" value=\"\" /></td></tr>";
		}
		$deviceStr .= "</table></th></tr>";
	}
	$deviceStr .= "</table>";
	$db = null;
	return $deviceStr;
}

function getStationModal($date, $stationName, $readonly, $bilan_id){
	$modal = '<div id="modal'. str_replace(" ", "_", $stationName) .'" class="modal fade bilanModal" role="dialog"><div class="modal-dialog"><div class="modal-content" ><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Bilan ' . $stationName . (($readonly) ? " readonly" : '') . '</h4></div><div class="modal-body"><form enctype="application/json" action="index.php" method="post"><input type="text" name="page" value="bilan" hidden /><input type="text" name="date" value="' . $date . '" hidden /><input type="text" name="bilan_id" value="' . $bilan_id . '" hidden /><input type="text" name="station" value="' . $stationName . '" hidden /><input type="text" name="bilan" value="" id="bilanTest" />';
    $modal .= getDeviceDataByStation($date, $stationName, $readonly) . '<label for="puht">Prix unitaire HT:</label><input type="text" name="puht" id="puht" style="width: 6em;" value="1.96"/><input ' . (($readonly) ? "disabled=\"disabled\"" : '') . ' type="submit" class="btn btn-default" style="float: right;" value="Valider"></input></form></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div>';
	return $modal;
}

function getStationData($date){
	$stationStr = '';
	$modal = '';

	$db = connectRW("comptage");
	$stm = $db->prepare("SELECT station.station_name, station.station_alias, station.station_id  FROM station");
	$bilanStm = $db->prepare("SELECT bilan_id, bilan_kwh, bilan_puht FROM `bilan` WHERE bilan_date=:ts AND station_station_id=(SELECT station_id FROM station WHERE station_name = :station)");
	try {
		$stationStr .= "<table class=\"stationTable table table-condensed table-striped\">\n\t<tr>\n\t\t<th>Nom</th>\n\t\t<th>Alias</th>\n\t\t<th>Bilan</th>\n\t\t<th>kw/h</th>\n\t\t<th>€/kwh HT</th>\n\t</tr>";
		$stm->execute();
		$stationData = $stm->fetchAll();
		foreach ($stationData as $key => $station) {
			//echo "$date\n";
			$bilanStm->execute(array('ts' => $date, "station" => $station['station_name']));
			$check = $bilanStm->fetchAll();
			if (!empty($check)) {
				$bilanClass = "good";
				$bilanValue = '<button type="button" class="btn good" data-toggle="modal" data-target="#modal' . str_replace(" ", "_", $station['station_name']) . '">Présent</button>';
				$modal .= getStationModal($date, $station['station_name'], 0, $check[0]['bilan_id']);
				$kwh = $check[0]['bilan_kwh'];
				$puht = $check[0]['bilan_puht'];
			} else {
				$bilanClass = "bad";
				$bilanValue = '<button type="button" class="btn bad" data-toggle="modal" data-target="#modal' . str_replace(" ", "_", $station['station_name']) . '"> Créer </button>';
				$modal .= getStationModal($date, $station['station_name'], 0, -1);
				$kwh = '';
				$puht = '';
			}
			$stationStr .= "\n\t<tr>\n\t\t<td>" . $station['station_name'] . "</td>\n\t\t<td>" . $station['station_alias'] . "</td>\n\t\t<td><div id=" . $station['station_name'] . ' >' . $bilanValue . "</div></td>\n\t\t<td>" . $kwh . "</td>\n\t\t<td>" . $puht . "</td>\n\t</tr>";
		}
		$stationStr .= "\n</table>" . $modal;
		return $stationStr;
	} catch (Zend_Db_Statement_Exception $e) {
		if ($e->getCode() != 23000) { // check Duplicate error code 
			throw($e);
		}
	}
}

/* ***************************************    Fonction concernant la partie facture    *************************************** */

function getBilanStgData($stg_id){
	$totalKwh = 0;
	$totalHt = 0;
	$puht = 1.95;
	$strBilanTab = '<table id="factureBilanTable" class="bilanTable table table-condensed table-striped"><tr><th>Poste de distribution</th><th>KWH</th><th>PU HT</th><th>Total HT</th></tr>';
	$db = connectRW("comptage");

	$stationStm = $db->prepare("SELECT `station_stationgroup_relations`.`station_id`, `station`.`station_name` FROM `station` INNER JOIN `station_stationgroup_relations` ON `station`.`station_id` = `station_stationgroup_relations`.`station_id` WHERE `station_stationgroup_relations`.`stationgroup_id` = :stg_id");

	$bilanStm = $db->prepare("SELECT `bilan_kwh`, `bilan_puht` FROM `bilan` WHERE `station_station_id` = :station_id");

	$stationStm->execute(array('stg_id' => $stg_id));

	$stationData = $stationStm->fetchAll();
	foreach ($stationData as $station) {
		$bilanStm->execute(array('station_id' => $station['station_id']));
		$bilanData = $bilanStm->fetch(PDO::FETCH_ASSOC);
		if (!empty($bilanData)) {
			$totalKwh += $bilanData['bilan_kwh'];
			$totalHt += $bilanData['bilan_kwh'] * $bilanData['bilan_puht'];
			$strBilanTab .= '<tr><td>' . $station['station_name'] . '</td><td>' . $bilanData['bilan_kwh'] . '</td><td>' . $bilanData['bilan_puht'] . '</td><td>' . ($bilanData['bilan_kwh'] * $bilanData['bilan_puht']) . '</td></tr>';
		} else {
			$strBilanTab .= '<tr class="factureBad"><td>' . $station['station_name'] . '</td><td> Bilan </td><td> non </td><td> générer </td></tr>';
		}
	}
	$strBilanTab .= '<tr><th>Total </th><th>' . $totalKwh . '</th><th>' . ($totalHt / $totalKwh) . '</th><th>' . $totalHt . '</th></tr></table>';

	$tva = ($totalHt / 100) * 13;

	$a = new \NumberFormatter("fr-FR", NumberFormatter::SPELLOUT); 

	$strBilanTab .= '<table id="totalTab" class="bilanTable table table-condensed table-striped">
		<tr><td>Total HT </td><td>' . $totalHt . '</td></tr>
		<tr><td>TVA 13% </td><td>' . $tva . '</td></tr>
		<tr><td>Total TTC </td><td>' . ($tva + $totalHt) . '</td></tr></table>'.
	'<div class="form-group row">
		<label for="facture_total_letter" class="col-sm form-label">Arrêté la présente facture à la somme TTC de : </label>
		<div class="col-sm">
			<input type="text" class="form-control" name="facture_total_letter" id="facture_total_letter" value="' . $a->format(($tva + $totalHt)) . ' francs CFP.">
		</div>
	</div>';

	return $strBilanTab;
}

function getFactureForm($date, $stgOption, $stg_id){
	$factureStr = '<form>'.
	'<input type="hidden" class="form-control" name="date" value="' . $date . '">' .
	'<div class="form-group row">
		<label for="facture_date" class="col-sm-3 form-label">Fait le : </label>
		<div class="col-sm-5">
			<input type="date" class="form-control" id="facture_date" name="facture_date" value="' . date("d-m-Y") . '">
		</div>
	</div>' .
	'<div class="form-group row">
		<label class="col-sm-3" for="stgSelector">Groupe de Stations:</label>
		<div class="col-sm-5">
			<select id="stgSelector" name="stationgroup_id" onchange="updatePage()">' . $stgOption . '</select>
		</div>
	</div>' .
	'<div class="form-group row">
		<label class="col-sm-3 form-label" for="facture_number">Facture N°: </label>
		<div class="col-sm-3">
			<input type="text" class="form-control" name="facture_number" id="facture_number">
		</div>
	</div>' .
	'<div class="form-group row">
		<label for="facture_period" class="col-sm-5 form-label">Redevance TEP du mois de </label>
		<div class="col-sm-4">
			<input type="text" class="form-control" name="facture_period" id="facture_period">
		</div>
	</div>' .
	'<div class="form-group row">
		<label for="facture_zone" class="col-sm-3 form-label">Réseau EDT </label>
		<div class="col-sm-5">
			<input type="text" class="form-control" name="facture_zone" id="facture_zone">
		</div>
	</div>' .
	getBilanStgData($stg_id) .
	'<input type="submit" class="btn btn-default" style="float: right;" value="Créer La facture">' .
	'</form>';
	return $factureStr;
}
?>