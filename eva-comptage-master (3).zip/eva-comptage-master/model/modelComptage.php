<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "DB.php";

function insertStation($tab){
	$db = connectRW("comptage");
	$stm = $db->prepare("INSERT INTO station (station_name, station_alias) VALUES (?, ?)");
	if (is_array($tab)) {
		foreach ($tab as $val) {
			try {
				$stm->execute(array($val, $val));
			} catch (Zend_Db_Statement_Exception $e) {
				if ($e->getCode() != 23000) { // check Duplicate error code 
					throw($e);
				}
			}
		}
	}
}

function parseIndex($tabs){
	$result = array();
	if (is_array($tabs)) {
		foreach ($tabs as $tab) {
			$tmpDate = new DateTime($tab['TS']);
			$ts = $tmpDate->format('Y-m') . '-01';

			$result[$tab['DEVICE']]['TS'] = $ts;
			$result[$tab['DEVICE']]['DEVICE'] = $tab['DEVICE'];
			$result[$tab['DEVICE']][$tab['VARIABLE']] = $tab['VAL'];
		}
	}
	return $result;
}

function insertDevice($tabs){
	$db = connectRW("comptage");
	//$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
	$stm = $db->prepare("INSERT INTO device (station_station_id, device_name, device_alias, device_description) VALUES ((SELECT station_id FROM station WHERE station_name = :station), :devicename, :devicename, :description)");
	if (is_array($tabs)) {
		foreach ($tabs as $tab) {
			try {
				$stm->execute(array("station" => $tab['STATION'], "devicename" => $tab['DEVICENAME'], "description" => $tab['DESCRIPTION']));
			} catch (Zend_Db_Statement_Exception $e) {
				if ($e->getCode() != 23000) { // check Duplicate error code 
					throw($e);
				}
			}
		}
	}
}

function insertIndex($tabs){
	$db = connectRW("comptage");
	$stm = $db->prepare("INSERT INTO `index` (`device_device_id`, `index_date`, `index_rate_+1_value`, `index_rate_+2_value`, `index_rate_-1_value`, `index_rate_-2_value`) VALUES ((SELECT device_id FROM device WHERE device_name = :device_name), :ts, :a1, :a2, :a3, :a4)");
	$check = $db->prepare("SELECT index_id FROM `index` WHERE `device_device_id`=(SELECT `device_id` FROM `device` WHERE `device_name` = :device_name) AND `index_date`=:ts");
	foreach ($tabs as $tab) {
		try {
			$tmpDate = new DateTime($tab['TS']);
			$ts = $tmpDate->format('Y-m') . '-01';
			//print_r($tab);
			$check->execute(array("device_name" => $tab['DEVICE'], "ts" => $ts));
			//$ret = $check->fetch(PDO::FETCH_COLUMN, 0);
			if (!$check->fetchColumn()) {
				$stm->execute(array("device_name" => $tab['DEVICE'], "ts" => $ts, "a1" => $tab['A+_T1'], "a2" => $tab['A+_T2'], "a3" => $tab['A-_T1'], "a4" => $tab['A-_T2']));
			}
			//$stm->execute(array("device_name" => $tab['DEVICE'], "ts" => $tab['TS'], "a1" => $tab['A+_T1'], "a2" => $tab['A+_T2'], "a3" => $tab['A-_T1'], "a4" => $tab['A-_T2']));
		} catch (Zend_Db_Statement_Exception $e) {
			if ($e->getCode() != 23000) { // check Duplicate error code 
				throw($e);
			}
		}
	}
}

function calc($val0, $val1, $val2, $op){
	$ret = $val0;
	if ($op == '+'){
		$ret += $val1 - $val2;
	} else if ($op == '-'){
		$ret -= $val1 - $val2;
	} else if ($op == '*'){
		$ret *= $val1 - $val2;
	} else if ($op == '/'){
		$ret /= $val1 - $val2;
	}
  	return $ret;
}

function insertBilan($tabs, $indate){
	$db = connectRW("comptage");
	$bilan_puht = 1;
	$ok = 1;
	$date = new DateTime($indate . ' 10:00:00.000');
	$date2= DateTime::createFromFormat('U', strtotime('first day of last month', $date->getTimestamp()));

	//$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
	$stm = $db->prepare("INSERT INTO bilan (station_station_id, bilan_date, bilan_kwh, bilan_puht) VALUES ((SELECT station_id FROM station WHERE station_name = :station), :bilandate, :bilankwh, :bilan_puht)");
	foreach ($tabs as $station_name) {
		try {
			$ok = 1;
			$bilanKwh = 0;
			$datastm1 = $db->prepare("SELECT station.station_id, device.device_id, `index`.`index_rate_+1_value`, `index`.`index_rate_-1_value`, `index`.`index_rate_+2_value`, `index`.`index_rate_-2_value`, `index`.`index_rate_+1_operator`, `index`.`index_rate_-1_operator`, `index`.`index_rate_+2_operator`, `index`.`index_rate_-2_operator` FROM station INNER JOIN device ON device.station_station_id=station.station_id INNER JOIN `index` ON `index`.device_device_id=device.device_id WHERE station.station_name=:station_name  AND `index`.`index_date` = :ts ORDER BY `device`.`device_id` ASC");
			$datastm1->execute(array("station_name" => $station_name, "ts" => $date->format('Y-m') . '-01'));
			$data1 = $datastm1->fetchAll();
			$datastm1->execute(array("station_name" => $station_name, "ts" => $date2->format('Y-m') . '-01'));
			$data2 = $datastm1->fetchAll();
			if (empty($data1) || empty($data2))
				$ok = 0;
			foreach ($data1 as $i => $tab) {
				if (!empty($data1[$i]) && !empty($data2[$i])) {
					$tmpbilanKwh = 0;
					foreach (array("+1", "-1", "+2", "-2") as $key) {
						$tmpbilanKwh = calc($tmpbilanKwh, $data1[$i]['index_rate_'. $key .'_value'], $data2[$i]['index_rate_'. $key .'_value'], $data1[$i]['index_rate_'. $key .'_operator']);
					}
					$bilanKwh += $tmpbilanKwh;
				} else
					$ok = 0; 
			}
			if ($ok == 1)
				$stm->execute(array("station" => $station_name, "bilandate" => $indate, "bilankwh" => $bilanKwh, 'bilan_puht' => $bilan_puht));

		} catch (Zend_Db_Statement_Exception $e) {
			if ($e->getCode() != 23000) { // check Duplicate error code   !!!!!!!!!!!    Aréte tt les sqlstate error
				throw($e);
			}
		}
	}
}

function getStationGroupe(){
	$db = connectRW("comptage");
	$stm = $db->prepare("SELECT `stationgroup_id`, `stationgroup_name`, `stationgroup_alias` FROM `stationgroup`");
	try {
		$stm->execute();
	} catch (Zend_Db_Statement_Exception $e) {
		if ($e->getCode() != 23000) { // check Duplicate error code 
			throw($e);
		}
	}
	return $stm->fetchAll();
}

?>