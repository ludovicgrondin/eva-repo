<?php
	$bilanInserted = 0;
	$bilanMsg = '';
	if ($_POST['bilan'] == '' && $_POST['puht'] != ""){
		$data = $_POST['device'];
		$station = $_POST['station'];
		$bilan_puht = $_POST['puht'];
		$bilanInserted = insertPostBilan($data, $station, $bilan_puht, $_POST['bilan_id'], $date, $date2);
	} else if ($_POST['puht'] == "") {
		$bilanMsg .= " Vous avez oubliez le prix unitaire; ";
	} else {
		$bilanMsg = ' Pour Raison non définie; ';
	}


	require_once 'controlleurIndex.php';

?>