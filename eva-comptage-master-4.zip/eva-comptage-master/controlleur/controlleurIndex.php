<?php
	require_once './model/modelIndex.php';
	require_once "./model/modelComptage.php";

	$page['css']= '<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		<link href="css/index.css" rel="stylesheet">';
	$page['script']= '
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/index.js"></script>';

	if ($date) {
		$Y = substr($date, 0, 4);
		$m = substr($date, 5, -3);
	} else {
		$Y = date('Y');
		$m = date('m');
	}

	$yearsOption = '';
	for($i=2016; $i<=date('Y'); $i++)
		$yearsOption .= "\t<option value=\"" . $i . "\" " . (($i == $Y) ? ' selected="selected"' : '') . '>' . $i . "</option>\n";

	$monthOption = '';
	for($i=1; $i<=12; $i++)
		$monthOption .= "\t<option value=\"" . $i . "\" " . (($i == $m) ? ' selected="selected"' : '') . '>' . $i . "</option>\n";


	$dateSelector = "<div id=\"dateSelector\"><label for=\"dateSelector\">Période</label>\n<label for=\"monthSelector\">Mois:</label><select id=\"monthSelector\" name=\"mois\" onchange=\"updatePage()\">\n" . $monthOption . "</select>\n<label for=\"yearSelector\">Année:</label><select id=\"yearSelector\" name=\"annees\" onchange=\"updatePage()\">\n" . $yearsOption . "</select></div>\n";

	$station = '<div id="stationData">' . getStationData($date, $date2) . '</div>';
	$facture = '<div id="stationData">' . getFactureData($date) . '</div>';
?>