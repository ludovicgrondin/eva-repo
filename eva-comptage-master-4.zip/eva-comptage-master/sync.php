<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$tepDbError = '';

require_once "./model/DB.php";
require_once "./model/modelComptage.php";

$ok = 1;
if (isset($_POST['date']) && preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $_POST['date'])) {
	$tmpDate = new DateTime($_POST['date']);
    $date = $tmpDate->format('Y') . '-' . ($tmpDate->format('m')) . '-01';
    $date2 = $tmpDate->format('Y') . '-' . ($tmpDate->format('m') - 1) . '-01';
    $tmpDate = new DateTime($date2);
    $date2 = $tmpDate->format('Y-m') . '-01';
} else {
	die("Date invalide");
}

foreach (array($date, $date2) as $value) {
	$data = getTepData($value);

	if (!empty($data) && !empty($data['stationData']) && !empty($data['deviceData']) && !empty($data['indexData'])) {
		insertStation($data['stationData']);
		insertDevice($data['deviceData']);
		$data['indexData'] = parseIndex($data['indexData']);
		insertIndex($data['indexData']);
		//insertBilan($data['stationData'], $date);
	} else {
		$ok = 0;
	}
}

if ($ok) {
	echo "Synchronisation terminée";
} else {
	echo $tepDbError;
}


?>