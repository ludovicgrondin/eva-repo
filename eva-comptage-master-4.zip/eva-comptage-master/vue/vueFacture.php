<?php
	$page['container']['header'] = '<div id="header"><div id="dateSelector">' . $dateSelector . '</div><input type="button"  onclick="sync()" value="Synchroniser"></input>' . '</div>';
	$page['container']['footer'] = '<p><p/>';

	//require_once 'Calcul/result.php';
	//require_once 'Calcul/set.php';
	
	if ($factureInserted) {
		$alert = "<script type=\"text/javascript\">alert(\"Facture Crée\")</script>";
	} else  {
		$alert = "<script type=\"text/javascript\">alert(\"Facture Non Créer: $factureMsg\")</script>";
	}

	$page['container']['main'] .= $alert;

	require_once 'vueIndex.php';

	//echo $page['container']['frameSet'];
?>
