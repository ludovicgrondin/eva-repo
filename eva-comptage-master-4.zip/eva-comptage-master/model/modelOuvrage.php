<?php
class Ouvrage {
  private $val;

  public function __construct($val = NULL, $op = NULL){
  }

  public function getValByName($name){
  	return (2);
  }
 
}
?>