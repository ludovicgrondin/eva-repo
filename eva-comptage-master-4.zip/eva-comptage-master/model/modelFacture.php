<?php

require_once "./model/modelComptage.php";



function genFactureData($stg_id, $date){
	$totalKwh = 0;
	$totalHt = 0;
	$puht = 1.95;
	$db = connectRW("comptage");

	$stationStm = $db->prepare("SELECT `station_stationgroup_relations`.`station_id`, `station`.`station_name` FROM `station` INNER JOIN `station_stationgroup_relations` ON `station`.`station_id` = `station_stationgroup_relations`.`station_id` WHERE `station_stationgroup_relations`.`stationgroup_id` = :stg_id");

	$bilanStm = $db->prepare("SELECT `bilan_kwh`, `bilan_puht` FROM `bilan` WHERE `station_station_id` = :station_id AND  `bilan_date` = :ts");

	$stationStm->execute(array('stg_id' => $stg_id));

	$stationData = $stationStm->fetchAll();
	foreach ($stationData as $station) {
		$bilanStm->execute(array('station_id' => $station['station_id'], 'ts' => $date));
		$bilanData = $bilanStm->fetch(PDO::FETCH_ASSOC);
		if (!empty($bilanData)) {
			$totalKwh += $bilanData['bilan_kwh'];
			$totalHt += $bilanData['bilan_kwh'] * $bilanData['bilan_puht'];
		}
	}

	$tva = ($totalHt / 100) * 13;

	$a = new \NumberFormatter("fr-FR", NumberFormatter::SPELLOUT); 
	$totalTTC = $tva + $totalHt;
	$total_letter = $a->format($totalTTC);
	return array("facture_total_number" => $totalTTC, "facture_total_letter" => $total_letter);
}

function insertPostFacture($data, $date){
	global $factureMsg;
	$errMsg = '';
	$ok = 1;
	$totalFacture = 0;
	$db = connectRW("comptage");
	//$updateStm = $db->prepare("UPDATE bilan SET bilan_kwh = :bilankwh, bilan_puht = :bilan_puht WHERE bilan_id=:bilan_id");
	$stm = $db->prepare("INSERT INTO `facture` (`facture_id`, `facture_number`, `facture_date`, `facture_period`, `facture_zone`, `facture_total_letter`, `stationgroup_stationgroup_id`, `client_client_id`, `facture_total_number`) VALUES (NULL, :facture_number, CAST(:facture_date AS DATETIME), CAST(:facture_period AS DATETIME), :facture_zone, :facture_total_letter, :stg_id, :client_id, :facture_total_number)");

	try {
		$factureData = genFactureData($data['stationgroup_id'], $date);
		$factureMsg .= $errMsg;
		if ($ok == 1){
			$stm->execute(array("facture_number" => $data['facture_number'], "facture_date" => $data['facture_date'], "facture_period" => $data['facture_period'], "facture_zone" => $data['facture_zone'], "facture_total_letter" => $factureData['facture_total_letter'], "stg_id" => $data['stationgroup_id'], "client_id" => $data['client_id'], "facture_total_number" => $factureData['facture_total_number']));
			return 1;
		}
	} catch (Zend_Db_Statement_Exception $e) {
		if ($e->getCode() != 23000) { // check Duplicate error code   !!!!!!!!!!!    Aréte tt les sqlstate error
			throw($e);
		}
	}
	return (0);
}
?>