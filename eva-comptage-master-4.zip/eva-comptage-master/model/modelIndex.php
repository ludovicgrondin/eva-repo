<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/* ***************************************    Fonction concernant la partie station    *************************************** */


function getDeviceDataByStation($date, $stationName, $readonly){
	$db = connectRW("comptage");
	$date = new DateTime($date . " 10:00:00.000");
	$date2= DateTime::createFromFormat('U', strtotime('first day of -1 month', $date->getTimestamp()));
	$fromDB1 = 1;
	$fromDB2 = 1;

	$devicestm1 = $db->prepare("SELECT device.device_name, `device`.`device_id` FROM device INNER JOIN station ON device.station_station_id=station.station_id WHERE station.station_name=:station_name ORDER BY `device`.`device_id` ASC");
	$datastm1 = $db->prepare("SELECT device.device_id, `index`.`index_fromuser`, `index`.`index_calc_dir`, `index`.`index_status`, `index`.`index_rate_+1_value`, `index`.`index_rate_-1_value`, `index`.`index_rate_+2_value`, `index`.`index_rate_-2_value`, `index`.`index_rate_+1_operator`, `index`.`index_rate_-1_operator`, `index`.`index_rate_+2_operator`, `index`.`index_rate_-2_operator` FROM station INNER JOIN device ON device.station_station_id=station.station_id INNER JOIN `index` ON `index`.device_device_id=device.device_id WHERE station.station_name=:station_name  AND `index`.`index_date` = :ts ORDER BY `device`.`device_id` ASC");
	$datastm1->execute(array("station_name" => $stationName, "ts" => $date->format('Y-m') . '-01'));
	$data1 = $datastm1->fetchAll();
	$datastm1->execute(array("station_name" => $stationName, "ts" => $date2->format('Y-m') . '-01'));
	$data2 = $datastm1->fetchAll();
	$devicestm1->execute(array("station_name" => $stationName));
	$data = $devicestm1->fetchAll();
	$deviceStr = "<table class=\"bilanTable table table-condensed table-striped\">\n\t<tr>\n\t\t<th>Nom</th>\n\t\t<th>Activer</th>\n\t\t<th>Direction</th>\n\t\t<th>Index rate</th>\n\t</tr>";
	foreach ($data as $i => $tab) {
		//print_r($tab);
		$fromDB1 = (!empty($data1) && isset($data1[$i]));
		$fromDB2 = (!empty($data2) && isset($data2[$i]));
		$fromUser1 = ($fromDB1 && !$data1[$i]['index_fromuser']);
		$fromUser2 = ($fromDB2 && !$data2[$i]['index_fromuser']);

		$deviceStr .= "<tr><td>" . $tab['device_name'] . 
			"<td><input type=\"checkbox\" name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][activated]\" value=\"1\" " . (($fromDB1 && $data1[$i]['index_status'] == '1') ? ' checked' : '') . "/></td>" .
			"<td><select type=\"text\" class=\"myInput \" maxlength=\"1\" name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][calc_dir]\" value=\"" . (($fromDB1) ? $data1[$i]['index_calc_dir'] : "0") . "\" >" .
			"<option value=\"0\" " . (($fromDB1 && $data1[$i]['index_calc_dir'] == '0') ? ' selected="selected"' : '') . "> ( +A ) - ( -A ) </option>" .
			"<option value=\"1\" " . (($fromDB1 && $data1[$i]['index_calc_dir'] == '1') ? ' selected="selected"' : '') . "> ( -A ) - ( +A ) </option></select></td>" .
			"</td><th><table class=\"bilanTable table table-condensed table-striped\"><tr><th></th><th>" . $date2->format('Y-m') . '-01' . "</th><th>" . $date->format('Y-m') . '-01' . "</th><!--<th>Opérateur</th>--></tr>";
    		
		$rate = array('+1', '+2', '-1', '-2');
		foreach ( $rate as $key) {
			$deviceStr .= "<tr><td>Index rate" . $key . "</td>" . 
			"<td><input type=\"text\" class=\"myInput\" " . (($readonly || $fromUser2) ? "readonly=\"readonly\"" : '') . " name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_value][1]\" value=\"" . (($fromDB2) ? $data2[$i]['index_rate_' . $key . '_value'] : "0") . "\">" . "</td>" . 
			"<td><input type=\"text\" class=\"myInput\" " . (($readonly || $fromUser1) ? "readonly=\"readonly\"" : '') . " name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_value][0]\" value=\"" . (($fromDB1) ? $data1[$i]['index_rate_' . $key . '_value'] : "0") . "\">" . "</td>" . 
			"<td><select hidden type=\"text\" class=\"myInput myOperatorInput\" " . (($readonly) ? "readonly=\"readonly\"" : '') . " maxlength=\"1\" name=\"device[". str_replace(" ", "_", $tab['device_name']) . "][index_rate_" . $key . "_operator]\" value=\"" . (($fromDB1) ? $data1[$i]['index_rate_' . $key . '_operator'] : "+") . "\" >" .
				"<option value=\"+\" " . (($fromDB1 && $data1[$i]['index_rate_' . $key . '_operator'] == '+') ? ' selected="selected"' : '') . "> + </option>" .
				"<option value=\"-\" " . (($fromDB1 && $data1[$i]['index_rate_' . $key . '_operator'] == '-') ? ' selected="selected"' : '') . "> - </option></select></td>". 
			"</tr>";
		}
		$deviceStr .= "</table></th></tr>";
	}
		    //echo "DeviceSTR2: $deviceStr\n";

	$deviceStr .= "</table>";
	$db = null;
    //echo "DeviceSTR: $deviceStr\n";

	return $deviceStr;
}

function getStationModal($date2, $stationName, $readonly, $bilan_id){
	global $date;
	$modal = '<div id="modal'. str_replace(" ", "_", $stationName) .'" class="modal fade bilanModal" role="dialog"><div class="modal-dialog"><div class="modal-content" ><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Bilan ' . $stationName . (($readonly) ? " readonly" : '') . '</h4></div><div class="modal-body"><form enctype="application/json" action="index.php" method="post"><input type="text" name="page" value="bilan" hidden /><input type="text" name="date" value="' . $date . '" hidden /><input type="text" name="bilan_date" value="' . $date2 . '" hidden /><input type="text" name="bilan_id" value="' . $bilan_id . '" hidden /><input type="text" name="station" value="' . $stationName . '" hidden /><input type="text" name="bilan" value="" id="bilanTest" />';
    $modal .= getDeviceDataByStation($date, $stationName, $readonly) . '<label for="puht">Prix unitaire HT:</label><input type="text" name="puht" id="puht" style="width: 6em;" value="1.96"/><input ' . (($readonly) ? "disabled=\"disabled\"" : '') . ' type="submit" class="btn btn-default" style="float: right;" value="Valider"></input></form></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div>';
	return $modal;
}

function getStationData($date, $date2){
	$stationStr = '';
	$modal = '';

	$db = connectRW("comptage");
	$stm = $db->prepare("SELECT station.station_name, station.station_alias, station.station_id  FROM station");
	$bilanStm = $db->prepare("SELECT bilan_id, bilan_kwh, bilan_puht FROM `bilan` WHERE bilan_date=:ts AND station_station_id=(SELECT station_id FROM station WHERE station_name = :station)");
	try {
		$stationStr .= "<table class=\"stationTable table table-condensed table-striped\">\n\t<tr>\n\t\t<th>Nom</th>\n\t\t<th>Alias</th>\n\t\t<th>Bilan</th>\n\t\t<th>kw/h</th>\n\t\t<th>€/kwh HT</th>\n\t</tr>";
		$stm->execute();
		$stationData = $stm->fetchAll();
		foreach ($stationData as $key => $station) {
			//echo "$date\n";
			$bilanStm->execute(array('ts' => $date2, "station" => $station['station_name']));
			$check = $bilanStm->fetchAll();
			if (!empty($check)) {
				$bilanClass = "good";
				$bilanValue = '<button type="button" class="btn good" data-toggle="modal" data-target="#modal' . str_replace(" ", "_", $station['station_name']) . '">Présent</button>';
				$modal .= getStationModal($date, $station['station_name'], 0, $check[0]['bilan_id']);
				$kwh = $check[0]['bilan_kwh'];
				$puht = $check[0]['bilan_puht'];
			} else {
				$bilanClass = "bad";
				$bilanValue = '<button type="button" class="btn bad" data-toggle="modal" data-target="#modal' . str_replace(" ", "_", $station['station_name']) . '"> Créer </button>';
				$modal .= getStationModal($date, $station['station_name'], 0, -1);
				$kwh = '';
				$puht = '';
			}
			$stationStr .= "\n\t<tr>\n\t\t<td>" . $station['station_name'] . "</td>\n\t\t<td>" . $station['station_alias'] . "</td>\n\t\t<td><div id=" . $station['station_name'] . ' >' . $bilanValue . "</div></td>\n\t\t<td>" . $kwh . "</td>\n\t\t<td>" . $puht . "</td>\n\t</tr>";
		}
		$stationStr .= "\n</table>" . $modal;
		return $stationStr;
	} catch (Zend_Db_Statement_Exception $e) {
		if ($e->getCode() != 23000) { // check Duplicate error code 
			throw($e);
		}
	}
}

/* ***************************************    Fonction concernant la partie facture    *************************************** */

function getBilanStgData($stg_id){
	$totalKwh = 0;
	$totalHt = 0;
	$puht = 1.95;
	$strBilanTab = '<table id="factureBilanTable" class="bilanTable table table-condensed table-striped"><tr><th>Poste de distribution</th><th>KWH</th><th>PU HT</th><th>Total HT</th></tr>';
	$db = connectRW("comptage");

	$stationStm = $db->prepare("SELECT `station_stationgroup_relations`.`station_id`, `station`.`station_name` FROM `station` INNER JOIN `station_stationgroup_relations` ON `station`.`station_id` = `station_stationgroup_relations`.`station_id` WHERE `station_stationgroup_relations`.`stationgroup_id` = :stg_id");

	$bilanStm = $db->prepare("SELECT `bilan_kwh`, `bilan_puht` FROM `bilan` WHERE `station_station_id` = :station_id");

	$stationStm->execute(array('stg_id' => $stg_id));

	$stationData = $stationStm->fetchAll();
	foreach ($stationData as $station) {
		$bilanStm->execute(array('station_id' => $station['station_id']));
		$bilanData = $bilanStm->fetch(PDO::FETCH_ASSOC);
		if (!empty($bilanData)) {
			$totalKwh += $bilanData['bilan_kwh'];
			$totalHt += $bilanData['bilan_kwh'] * $bilanData['bilan_puht'];
			$strBilanTab .= '<tr><td>' . $station['station_name'] . '</td><td>' . $bilanData['bilan_kwh'] . '</td><td>' . $bilanData['bilan_puht'] . '</td><td>' . ($bilanData['bilan_kwh'] * $bilanData['bilan_puht']) . '</td></tr>';
		} else {
			$strBilanTab .= '<tr class="factureBad"><td>' . $station['station_name'] . '</td><td> Bilan </td><td> non </td><td> générer </td></tr>';
		}
	}
	$strBilanTab .= '<tr><th>Total </th><th>' . $totalKwh . '</th><th>' . (($totalKwh != 0) ? ($totalHt / $totalKwh) : '0') . '</th><th>' . $totalHt . '</th></tr></table>';

	$tva = ($totalHt / 100) * 13;

	$a = new \NumberFormatter("fr-FR", NumberFormatter::SPELLOUT); 

	$strBilanTab .= '<table id="totalTab" class="bilanTable table table-condensed table-striped">
		<tr><td>Total HT </td><td>' . $totalHt . '</td></tr>
		<tr><td>TVA 13% </td><td>' . $tva . '</td></tr>
		<tr><td>Total TTC </td><td>' . ($tva + $totalHt) . '</td></tr></table>'.
	'<div class="form-group row">
		<label for="facture_total_letter" class="col-sm form-label">Arrêté la présente facture à la somme TTC de : </label>
		<div class="col-sm">
			<input type="text" class="form-control" name="facture_total_letter" id="facture_total_letter" value="' . $a->format(($tva + $totalHt)) . ' francs CFP.">
		</div>
	</div>';

	return $strBilanTab;
}

function getFactureModal($date, $stgName, $readonly, $stg_id, $data, $stgSelector, $clientSelector){
	$modal = '<div id="modal'. str_replace(" ", "_", $stgName) .'" class="modal fade bilanModal" role="dialog"><div class="modal-dialog"><div class="modal-content" ><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Facture ' . (($readonly) ? " readonly" : '') . '</h4></div><div class="modal-body">
		<form enctype="application/json" action="index.php" method="post">
			<input type="text" name="page" value="facture" hidden />
			<input type="text" name="date" value="' . $date . '" hidden />
			
			<input type="text" name="station" value="' . $stgName . '" hidden />
			<input type="text" name="bilan" value="" id="factureTest" />' .
			'<input type="hidden" class="form-control" name="date" value="' . $date . '" hidden>' .
			$stgSelector . $clientSelector .
			'<div class="form-group row">
				<label for="facture_date" class="col-sm-3 form-label">Fait le : </label>
				<div class="col-sm-5">
					<input type="date" class="form-control" id="facture_date" name="facture_date" value="' . date("Y-m-d") . '">
				</div>
			</div>' .
			'<div class="form-group row">
				<label class="col-sm-3 form-label" for="facture_number">Facture N°: </label>
				<div class="col-sm-3">
					<input type="text" class="form-control" name="facture_number" id="facture_number" value="' . ((!empty($data)) ? $data["facture_number"] : '') . '">
				</div>
			</div>' .
			'<div class="form-group row" hidden>
				<label for="facture_period" class="col-sm-5 form-label">Redevance TEP du mois de </label>
				<div class="col-sm-4">
					<input type="date" readonly class="form-control" name="facture_period" id="facture_period" value="' . ((!empty($data)) ? $data["facture_period"] : $date) . '">
				</div>
			</div>' .
			'<div class="form-group row">
				<label for="facture_zone" class="col-sm-3 form-label">Réseau EDT </label>
				<div class="col-sm-5">
					<input type="text" class="form-control" name="facture_zone" id="facture_zone" value="' . ((!empty($data)) ? $data["facture_zone"] : '') . '">
				</div>
			</div>' .
			'<input ' . (($readonly) ? "disabled=\"disabled\"" : '') . ' type="submit" class="btn btn-default" style="float: right;" value="Créer La facture"></input>
		</form></div><div class="modal-footer"></div></div></div></div></div></div></div>';
	return $modal;
}

function getFactureData($date){
	if (array_key_exists('stationgroup_id', $_POST)) {
		$stg_id = $_POST['stationgroup_id'];
	} else {
		$stg_id = 1;
	}
	$db = connectRW("comptage");
	$factureStm = $db->prepare("SELECT `facture`.`facture_id`, `facture`.`facture_number`, `facture`.`facture_period`, `facture`.`facture_zone`, `facture`.`client_client_id`, `client`.`client_name`, `facture`.`facture_total_number` FROM `facture` INNER JOIN `client` ON `client`.`client_id`=`facture`.`client_client_id` WHERE `facture`.`stationgroup_stationgroup_id`=:stg_id AND `facture`.`facture_period`=:ts");
	
	$stgData = getStationGroupe();
	$stgModal = '';

	$stgOption = '';
	foreach ($stgData as $stg) {
		$stgOption .= "\t<option value=\"" . $stg['stationgroup_id'] . "\" " . (($stg['stationgroup_id'] == $stg_id) ? ' selected="selected"' : '') . '>' . utf8_encode($stg['stationgroup_name']) . "</option>\n";
	}
	$stgSelector = "<div id=\"divStgSelector\"><label for=\"stgSelector\">Groupe de Stations:</label><select id=\"stgSelector\" name=\"stationgroup_id\" onchange=\"\">\n" . $stgOption . "</select>";

	$clientOption = '';
	$clientData = getClient();
	foreach ($clientData as $client) {
		$clientOption .= "\t<option value=\"" . $client['client_id'] . "\" " . (($client['client_id'] == 1) ? ' selected="selected"' : '') . '>' . utf8_encode($client['client_name']) . "</option>\n";
	}
	$clientSelector = "<div id=\"divclientSelector\"><label for=\"clientSelector\">Client:</label><select id=\"clientSelector\" name=\"client_id\" onchange=\"\">\n" . $clientOption . "</select>";


	$factureStr = "<table class=\"factureTable table table-condensed table-striped\">\n\t<tr>\n\t\t<th>N°</th>\n\t\t<th>Client</th>\n\t\t<th>Zone</th>\n\t\t<th>Status</th>\n\t\t<th>Total TTC</th>\n\t</tr>";
	foreach ($stgData as $stg) {
		$factureStm->execute(array("stg_id" => $stg['stationgroup_id'], "ts" => $date));
		$checks = $factureStm->fetchAll();
			if (!empty($checks)) {
				foreach ($checks as $key => $check) {
				$factureClass = "good";
				$factureValue = '<button type="button" class="btn good" data-toggle="modal" data-target="#modal' . str_replace(" ", "_", $stg['stationgroup_name']) . '">Présent</button>';
				$stgModal .= getFactureModal($date, $stg['stationgroup_name'], 0, $stg['stationgroup_id'], $check, $stgSelector, $clientSelector);
				$factureStr .= "\n\t<tr>\n\t\t<td>" . $check['facture_number'] . "</td>\n\t\t<td>" . $check['client_name'] . "</td>\n\t\t<td>" . $check['facture_zone'] . "</td>\n\t\t<td><div id=" . $check['facture_number'] . ' >' . $factureValue . "</div></td>\n\t\t<td>" . $check['facture_total_number'] . "</td>\n\t</tr>";
				}
			} else {
				$factureClass = "bad";
				$factureValue = '<button type="button" class="btn bad" data-toggle="modal" data-target="#modal' . str_replace(" ", "_", $stg['stationgroup_name']) . '"> Créer </button>';
				$stgModal .= getFactureModal($date, $stg['stationgroup_name'], 0, $stg['stationgroup_id'], $checks, $stgSelector, $clientSelector);
				$factureStr .= "\n\t<tr>\n\t\t<td>NULL</td>\n\t\t<td>NULL</td>\n\t\t<td>NULL</td>\n\t\t<td><div id=" . $stg['stationgroup_name'] . ' >' . $factureValue . "</div></td>\n\t\t<td>NULL</td>\n\t</tr>";
			}
	}
	$boutonAjouter = '<button type="button" class="btn" data-toggle="modal" data-target="#modalnewFacture">Ajouter une Facture</button>';
	$stgModal .= getFactureModal($date, "newFacture", 0, 0, NULL, $stgSelector, $clientSelector);
	$factureStr .= "\n</table>" . $boutonAjouter . $stgModal;

	$db = null;
	return $factureStr;
}
?>