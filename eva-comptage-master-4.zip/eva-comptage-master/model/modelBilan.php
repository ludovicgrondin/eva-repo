<?php

require_once "./model/modelComptage.php";

function checkIndex($tabs, $date){
	$db = connectRW("comptage");
	$stm = $db->prepare("INSERT INTO `index` (`device_device_id`, `index_date`, `index_rate_+1_value`, `index_rate_+2_value`, `index_rate_-1_value`, `index_rate_-2_value`, `index_rate_+1_operator`, `index_rate_+2_operator`, `index_rate_-1_operator`, `index_rate_-2_operator`, `index_fromuser`, `index_calc_dir`, `index_status`) VALUES ((SELECT device_id FROM device WHERE device_name = :device_name), :ts, :a1, :a2, :a3, :a4, :a1o, :a2o, :a3o, :a4o, 1, :dir, :status)");
	$check = $db->prepare("SELECT index_id, index_fromuser FROM `index` WHERE `device_device_id`=(SELECT `device_id` FROM `device` WHERE `device_name` = :device_name) AND `index_date`=:ts");
	$updatestm = $db->prepare("UPDATE `index`SET `index_rate_+1_operator` = :a1o , `index_rate_+2_operator` = :a2o , `index_rate_-1_operator` = :a3o , `index_rate_-2_operator` = :a4o, `index_calc_dir` = :dir,  `index_status` = :status  WHERE index_id=:index_id");
	$fullupdatestm = $db->prepare("UPDATE `index`SET `index_rate_+1_value` = :a1 , `index_rate_+2_value` = :a2 , `index_rate_-1_value` = :a3 , `index_rate_-2_value` = :a4 , `index_rate_+1_operator` = :a1o , `index_rate_+2_operator` = :a2o , `index_rate_-1_operator` = :a3o , `index_rate_-2_operator` = :a4o, `index_calc_dir` = :dir,  `index_status` = :status  WHERE `index_id`=:index_id");
	foreach ($tabs as $key => $tab) {
		try {
			if (array_key_exists('activated' ,$tab))
				$status = 1;
			else 
				$status = 0;
			//print_r($tab);
			foreach (array(0, 1) as $i) {
				$check->execute(array("device_name" => str_replace("_", " ", $key), "ts" => $date[$i]));
				$data = $check->fetch();
				if (!$data) {
					$stm->execute(array("device_name" => str_replace("_", " ", $key), "ts" => $date[$i], "a1" => $tab['index_rate_+1_value'][$i], "a2" => $tab['index_rate_+2_value'][$i], "a3" => $tab['index_rate_-1_value'][$i], "a4" => $tab['index_rate_-2_value'][$i], "a1o" => $tab['index_rate_+1_operator'], "a2o" => $tab['index_rate_+2_operator'], "a3o" => $tab['index_rate_-1_operator'], "a4o" => $tab['index_rate_-2_operator'], "dir" => $tab['calc_dir'], "status" => $status));
				} else if ($data['index_fromuser']){
					$fullupdatestm->execute(array("index_id" => $data['index_id'], "a1" => $tab['index_rate_+1_value'][$i], "a2" => $tab['index_rate_+2_value'][$i], "a3" => $tab['index_rate_-1_value'][$i], "a4" => $tab['index_rate_-2_value'][$i], "a1o" => $tab['index_rate_+1_operator'], "a2o" => $tab['index_rate_+2_operator'], "a3o" => $tab['index_rate_-1_operator'], "a4o" => $tab['index_rate_-2_operator'], "dir" => $tab['calc_dir'], "status" => $status));
				} else if (!$data['index_fromuser']){
					$updatestm->execute(array("index_id" => $data['index_id'], "a1o" => $tab['index_rate_+1_operator'], "a2o" => $tab['index_rate_+2_operator'], "a3o" => $tab['index_rate_-1_operator'], "a4o" => $tab['index_rate_-2_operator'], "dir" => $tab['calc_dir'], "status" => $status));
				}
			}
		

		} catch (Zend_Db_Statement_Exception $e) {
			//if ($e->getCode() != 23000) { // check Duplicate error code 
				throw($e);
			//}
		}
	}

}

function insertPostBilan($data, $station, $bilan_puht, $update, $date, $date2){
	global $bilanMsg;
	$errMsg = '';
	$check = 0;
	$ok = 1;
	$db = connectRW("comptage");
	$updateStm = $db->prepare("UPDATE bilan SET bilan_kwh = :bilankwh, bilan_puht = :bilan_puht WHERE bilan_id=:bilan_id");
	$stm = $db->prepare("INSERT INTO bilan (station_station_id, bilan_date, bilan_kwh, bilan_puht) VALUES ((SELECT station_id FROM station WHERE station_name = :station), :bilandate, :bilankwh, :bilan_puht) ON DUPLICATE KEY UPDATE bilan_kwh = :bilankwh, bilan_puht = :bilan_puht");
	$bilanKwh = 0;
	$rate_a_pos = 0;
	$rate_a_neg = 0;
	checkIndex($data, array($date, $date2));

	foreach ($data as $i => $tab) {
		$tmpbilanKwh = 0;
		if (array_key_exists('activated' ,$data[$i]))
		{
			foreach (array("+1", "-1", "+2", "-2") as $key) {
				$check++;
				if ($key == "+1" || $key == "+2") {
					if (!empty($data[$i]) && $data[$i]['index_rate_'. $key .'_value'][0] != 'NULL' && $data[$i]['index_rate_'. $key .'_value'][1] != 'NULL' ) {
						$rate_a_pos = calc($rate_a_pos, $data[$i]['index_rate_'. $key .'_value'][0], $data[$i]['index_rate_'. $key .'_value'][1], "-");
					}
				} else if ($key == "-1" || $key == "-2") {
					if (!empty($data[$i]) && $data[$i]['index_rate_'. $key .'_value'][0] != 'NULL' && $data[$i]['index_rate_'. $key .'_value'][1] != 'NULL' ) {
						$rate_a_neg = calc($rate_a_neg, $data[$i]['index_rate_'. $key .'_value'][0], $data[$i]['index_rate_'. $key .'_value'][1], "-");
					}
				}
			}
		}
		if ($data[$i]['calc_dir'] == 0) {
			$bilanKwh += ($rate_a_pos - $rate_a_neg);
		} else if ($data[$i]['calc_dir'] == 1) {
			$bilanKwh += ($rate_a_neg - $rate_a_pos);
		}
		$bilanKwh += $tmpbilanKwh;
	}

	if ($check == 0) {
		$errMsg = " Vous avez sélectioner aucun éléments; ";
	}
	$bilanMsg .= $errMsg;
	try {
		if ($ok == 1 && $check > 0){
			if ($update >= 0) {
				$updateStm->execute(array("bilan_id" => $update, "bilankwh" => $bilanKwh, 'bilan_puht' => $bilan_puht));
				return 2;
			} else {
				$stm->execute(array("station" => $station, "bilandate" => $date2, "bilankwh" => $bilanKwh, 'bilan_puht' => $bilan_puht));
				return 1;
			}
		}
	} catch (Zend_Db_Statement_Exception $e) {
		if ($e->getCode() != 23000) { // check Duplicate error code   !!!!!!!!!!!    Aréte tt les sqlstate error
			throw($e);
		}
	}
	return (0);
}
?>