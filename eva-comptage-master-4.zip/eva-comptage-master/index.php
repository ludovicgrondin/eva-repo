<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

@session_start();

//require_once "model/DB.php";


if (!empty($_POST['page']))
	$ask = $_POST['page'];
else
	$ask = 'index';

if (!empty($_POST['date'])){
    $tmpDate = new DateTime($_POST['date']);
    $date = $tmpDate->format('Y') . '-' . ($tmpDate->format('m')) . '-01';
    $date2 = $tmpDate->format('Y') . '-' . ($tmpDate->format('m') - 1) . '-01';
    $tmpDate = new DateTime($date2);
    $date2 = $tmpDate->format('Y-m') . '-01';
} else {
    $tmpDate = new DateTime();
    $date = $tmpDate->format('Y') . '-' . ($tmpDate->format('m') - 1) . '-01';
    $tmpDate = new DateTime($date);
    $date = $tmpDate->format('Y-m') . '-01';
    $date2 = $tmpDate->format('Y') . '-' . ($tmpDate->format('m') - 1) . '-01';
    $tmpDate = new DateTime($date2);
    $date2 = $tmpDate->format('Y-m') . '-01';
}

$page['container']['main'] = '';

$data = array(
	'index' => array('model' => 'model/modelIndex.php', 'view' => 'vue/vueIndex.php', 'controller' => 'controlleur/controlleurIndex.php'),
    'bilan' => array('model' => 'model/modelBilan.php', 'view' => 'vue/vueBilan.php', 'controller' => 'controlleur/controlleurBilan.php'),
    'facture' => array('model' => 'model/modelFacture.php', 'view' => 'vue/vueFacture.php', 'controller' => 'controlleur/controlleurFacture.php'),
);

foreach($data as $key => $components){
    if ($ask == $key) {
        $model = $components['model'];
        $view = $components['view'];
        $controller = $components['controller'];
        break;
    }
}

if (isset($view)) {
	require_once "$model";
    require_once "$controller";
    require_once "$view";
}

?>