-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Ven 17 Février 2017 à 07:47
-- Version du serveur: 5.1.44
-- Version de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `comptage`
--

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE IF NOT EXISTS `bilan` (
  `bilan_id` int(11) NOT NULL AUTO_INCREMENT,
  `station_station_id` int(11) NOT NULL,
  `bilan_date` datetime NOT NULL,
  `bilan_kwh` int(11) NOT NULL,
  `bilan_puht` int(11) NOT NULL,
  PRIMARY KEY (`bilan_id`),
  UNIQUE KEY `bilan_id` (`bilan_id`,`station_station_id`,`bilan_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `bilan`
--


-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(100) NOT NULL,
  `client_address` int(100) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `client`
--


-- --------------------------------------------------------

--
-- Structure de la table `device`
--

CREATE TABLE IF NOT EXISTS `device` (
  `device_id` int(10) NOT NULL AUTO_INCREMENT,
  `station_station_id` int(10) NOT NULL,
  `device_name` varchar(100) NOT NULL,
  `device_alias` varchar(100) NOT NULL,
  `device_description` varchar(255) NOT NULL,
  PRIMARY KEY (`device_id`),
  UNIQUE KEY `device_name` (`device_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `device`
--


-- --------------------------------------------------------

--
-- Structure de la table `index`
--

CREATE TABLE IF NOT EXISTS `index` (
  `index_id` int(10) NOT NULL AUTO_INCREMENT,
  `device_device_id` int(10) NOT NULL,
  `index_date` datetime NOT NULL,
  `index_rate_+1_value` float NOT NULL,
  `index_rate_+1_operator` varchar(1) NOT NULL DEFAULT '+',
  `index_rate_+2_value` float NOT NULL,
  `index_rate_+2_operator` varchar(1) NOT NULL DEFAULT '+',
  `index_rate_-1_value` float NOT NULL,
  `index_rate_-1_operator` varchar(1) NOT NULL DEFAULT '-',
  `index_rate_-2_value` float NOT NULL,
  `index_rate_-2_operator` varchar(1) NOT NULL DEFAULT '-',
  `index_status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`index_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `index`
--


-- --------------------------------------------------------

--
-- Structure de la table `station`
--

CREATE TABLE IF NOT EXISTS `station` (
  `station_id` int(6) NOT NULL AUTO_INCREMENT,
  `station_name` varchar(100) NOT NULL,
  `station_alias` varchar(100) NOT NULL,
  PRIMARY KEY (`station_id`),
  UNIQUE KEY `station_name` (`station_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `station`
--

