<?php
class Calcul {
  private $val;

  /*public function __construct($val = NULL, $op = NULL){
  	if (isset($val) && isset($op)){
  		$this->val[] = $val;
  	} else {
  		$this->val[] = array();
  	}
    return $this;
  }*/

  public function getCalcul(){
  	$i = 0;
  	$ret = 0;
  	$str = '';
  	while (isset($this->val[$i])) {
  		$str +=  $this->val[$i]['name'] + ' ' + $this->val[$i]['op'] + ' ';
  		if (isset($this->val[$i]['op']) && $this->val[$i]['op'] == '+'){
  			$ret += $this->val[$i]['value'];
  		} else if (isset($this->val[$i]['op']) && $this->val[$i]['op'] == '-'){
  			$ret -= $this->val[$i]['value'];
  		} else if (isset($this->val[$i]['op']) && $this->val[$i]['op'] == '*'){
  			$ret *= $this->val[$i]['value'];
  		} else if (isset($this->val[$i]['op']) && $this->val[$i]['op'] == '/'){
  			$ret /= $this->val[$i]['value'];
  		}
  	}
  	return array("str" => $str, "value" => $ret);
  }

  public function addVal($name, $value, $op = '+'){
  	$this->val[] = array("name" => $name, "value" => $value, "op" => $op);
  }

  public function updateVal($ind, $name, $value, $op){
  	$this->val[$ind] = array("name" => $name, "value" => $value, "op" => $op);
  }
 
}
?>