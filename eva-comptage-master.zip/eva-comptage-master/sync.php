<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "./model/DB.php";
require_once "./model/modelComptage.php";

if (isset($_POST['date']) && preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $_POST['date'])) {
	$date = $_POST['date'];
} else {
	die("Date invalide");
}

$data = getTepData($date);


insertStation($data['stationData']);
insertDevice($data['deviceData']);
$data['indexData'] = parseIndex($data['indexData']);
insertIndex($data['indexData']);

insertBilan($data['stationData'], $date . ' 10:00:00.000');


//print_r($data);
echo "Synchronisation finie";
?>