<?php

$page['container']['calc_str'] = '
  <div id="calc_str">
  ' . $msg['calc_str'] . '
  </div>';

?>