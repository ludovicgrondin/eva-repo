<?php
 
// Main page
 
# INIT


	$page['container']['header'] = '<p>ceci est le header <input id="sync_date" type="date" min="2016-01-01" name="date"><input type="button"  onclick="sync()" value="Synchroniser"></input><p/>';
	$page['container']['footer'] = '<p>ceci est le footer<p/>';

	require_once 'Calcul/result.php';
	require_once 'Calcul/set.php';
	
	$page['container']['main'] = '<div>' . $page['container']['calc_form'] . $page['container']['calc_str'] . '</div>';

	require_once 'vueFrame.php';

	echo $page['container']['frameSet'];
?>
