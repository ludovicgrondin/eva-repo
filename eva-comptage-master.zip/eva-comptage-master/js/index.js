function sync(){
	$.ajax({
		type: 'POST',
		url: 'sync.php',
		data : 'date=' + document.getElementById('sync_date').value,
		dataType : 'html',
		success: function(data) {
			alert(data);
		}
	})
};    
