<?php
if($_GET["id"] == 1){
$chart_id = 1;
$homepage = file_get_contents('https://10.140.4.6/h5performance/getWoRttSrt.php');
}else if($_GET["id"] == 2){
$chart_id = 2;
$homepage = file_get_contents('https://10.140.4.6/h5performance/getWoTcpPortTopIpRtt.php');
}else if($_GET["id"] == 3){
$chart_id = 3;
$homepage = file_get_contents('https://10.140.4.6/h5performance/getWoTopIpCam.php');
}else {
$homepage = file_get_contents('https://192.168.0.72/h5performance/getWoRttSrt.php');
$chart_id = 1;
}
if (isset($_GET["type"])){
$type = $_GET["type"];
// options possibles = pie, stackedarea, line
}else{
$type = 'line';
}
if (isset($_GET["setting"])){
$setting = $_GET["setting"];
// options possibles = TOP_TIMING_CHART_SETTINGS , METRIC_CHART_SETTINGS, TOP_PIE_CHART_SETTINGS
}else{
$setting = 'TOP_TIMING_CHART_SETTINGS';
}
?>

<!-- <div id="splitter" class="row-fluid"></div> -->
<script type="text/javascript">
	var CHART_ENABLE_ANIMATIONS = true;
</script>
<div class="chart-container"
	id="metric-chart-<?php echo $chart_id; ?>"
	style="width: 100%; height: 250px"></div>    

<script type="text/javascript">
$(document).ready(function() {
	var dashlet = $('#metric-chart-<?php echo $chart_id; ?>');
	
	dashlet.jqxChart('showToolTips', true);
	
	var width = dashlet.width();
	var height = dashlet.height();
	var period = 'LAST_DAY';
	var chartType = '<?php echo $type; ?>';
	var language = 'fr_FR';
	var chartData = <?php echo $homepage; ?>;
	var settings = <?php echo $setting; ?>.getSettings(
				width,
				height,
				period,
				chartData,
				chartType,
				language);
	
	dashlet.jqxChart(settings);
		 
	});
</script>