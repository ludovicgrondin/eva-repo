<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
//$plagecidr = '172.18.152.0/21';
$get_ip = $argv["1"];
$get_mask = $argv["2"];
$plagecidr = $get_ip.'/'.$get_mask;
//$plagecidr = '10.205.12.0/25';
$cmd = ' /root/nbtscan '.$plagecidr.'';
echo $cmd;
$output= shell_exec($cmd);
$output=trimUltime($output);


$arr= explode("\n", $output);

foreach ($arr as &$value) {
    $newtab = explode(" ", $value);
    $tabname = explode("\\", $newtab[1]);
    $newtab[1] = $tabname[1];
    $plop[] = $newtab;
}


// get valeurs existantes en database
require_once ('ModelH5Charts.php');
$exist = getAllIpToNetbios($db);

// pour chaque ip découverte
$discovered = $plop;
foreach ($discovered as $value){

if (!isset ($value[4]) && $value[1] != NULL){ // contournement bug ERROR: rdlength = 104, remaining bytes = 101  et  -no name- 
	$already_exist = 0;
	// verif si existe deja
	foreach ($exist as $existip){
		if ($value[0] == $existip["ip"]){
			$already_exist = 1;
		}
	}
	
	$data_i['ip'] = $value[0];
	$ip = $value[0];
	$data_i['name'] = $value[1];
	$data_u['name'] = $value[1];
	if (isset ($value[3])){
	$data_i['user'] = $value[3];
	$data_u['user'] = $value[3];
	} else{
	$data_i['user'] = "";
	$data_u['user'] = "";
	}
	
	if ($already_exist == 1){
	//update
	updateIpToNetbios($db,$data_u,$ip);
	echo 'update \n';
	var_dump($ip);
	} elseif ($already_exist == 0){
	//insert
	setIpToNetbios($db,$data_i);
	echo 'insert \n';
	var_dump($data_i['ip']);
	}
	unset($data_i,$data_u,$ip);
}	
	
}


function trimUltime($chaine){
$chaine = trim($chaine);
$chaine = str_replace("\t", " ", $chaine);
$chaine = eregi_replace("[ ]+", " ", $chaine);
return $chaine;
}