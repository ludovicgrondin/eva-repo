<form action="/dashlet/TOP_CHART/config/25" method="post" name="DASHLET_CONFIGURATION" id="dashlet-25-conf-form"
 class="form-horizontal"><div class="modal-header">
    <button id="button_cancel_create_dashlet" type="button" class="close" data-dismiss="modal" aria-hidden
="true">&times;</button>
    <h3>
        Graphique de TOP    </h3>
</div>
<div class="modal-body">
    <ul class="validation-errors text-error">
    </ul>
    <div id="commonConfigtitle" class="control-group"><label class="control-label" for="commonConfig
[title]"><span>Titre</span></label><div class="controls"><input name="commonConfig[title]" type="text"
 required="required" value="LINE"></div></div>    <div id="customConfigtop_chart_type" class="control-group"
><label class="control-label" for="customConfig[top_chart_type]"><span>Type de graphique</span></label
><div class="controls"><select name="customConfig[top_chart_type]" required="required"><option value
="">-----</option>
<option value="LINE" selected="selected">Série</option>
<option value="STACKEDAREA">Cumul</option>
<option value="PIE">Camembert</option></select></div></div><div id="customConfigtop_type" class="control-group"
><label class="control-label" for="customConfig[top_type]"><span>Type de top</span></label><div class
="controls"><select name="customConfig[top_type]" required="required"><option value="">-----</option
>
<option value="IP" selected="selected">IPs</option>
<option value="WO">Objets surveillés</option>
<option value="BF">Flux métier</option>
<option value="HTTP">Applications HTTP</option>
<option value="VLAN">VLANs</option>
<option value="TCP">Applications TCP</option>
<option value="UDP">Applications UDP</option></select></div></div><div id="customConfigtop_metric" class
="control-group"><label class="control-label" for="customConfig[top_metric]"><span>Métrique du top</span
></label><div class="controls"><select name="customConfig[top_metric]" required="required"><option value
="">-----</option>
<option value="bandwidth" selected="selected">Débit</option>
<option value="bandwidth_in">Débit in</option>
<option value="bandwidth_out">Débit out</option>
<option value="bytes">Volume</option>
<option value="bytes_in">Volume in</option>
<option value="bytes_out">Volume out</option>
<option value="con_fail_rate_in">Taux d&#039;échecs con. in</option>
<option value="con_fail_rate_out">Taux d&#039;échecs con. out</option>
<option value="con_req_in">Requêtes de connexion in</option>
<option value="con_req_out">Requêtes de connexion out</option>
<option value="con_setup_time_in">Tps de connexion in</option>
<option value="con_setup_time_out">Tps de connexion out</option>
<option value="delay_in">RTP Délai inter-paquets in</option>
<option value="delay_out">RTP Délai inter-paquets out</option>
<option value="con_est_in">Connexions établies in</option>
<option value="con_est_out">Connexions établies out</option>
<option value="jitter_in">RTP Gigue in</option>
<option value="jitter_out">RTP Gigue out</option>
<option value="loss_burst_in">RTP Taille des bursts in</option>
<option value="loss_burst_out">RTP Taille des bursts out</option>
<option value="loss_rate_in">Taux de perte in</option>
<option value="loss_rate_out">Taux de perte out</option>
<option value="mos_in">MOS calculé in</option>
<option value="mos_out">MOS calculé out</option>
<option value="out_of_seq_in">RTP Paquets hors séquence in</option>
<option value="out_of_seq_out">RTP Paquets hors séquence out</option>
<option value="pkts_in">Paquets in</option>
<option value="pkts_out">Paquets out</option>
<option value="payload_in">Charge utile in</option>
<option value="payload_out">Charge utile out</option>
<option value="rst_in">Resets TCP in</option>
<option value="rst_out">Resets TCP out</option>
<option value="ret_time_in">Tps de retrans. in</option>
<option value="ret_time_out">Tps de retrans. out</option>
<option value="rtp_dup_in">RTP Paquets dupliqués in</option>
<option value="rtp_dup_out">RTP Paquets dupliqués out</option>
<option value="rtp_loss_in">RTP Paquets perdus in</option>
<option value="rtp_loss_out">RTP Paquets perdus out</option>
<option value="rtt_in">RTT in</option>
<option value="rtt_out">RTT out</option>
<option value="serv_resp_time_in">Tps de réponse serveur in</option>
<option value="serv_resp_time_out">Tps de réponse serveur out</option>
<option value="tcp_dup_in">Paquets dupliqués in</option>
<option value="tcp_dup_out">Paquets dupliqués out</option>
<option value="tcp_loss_in">Paquets perdus in</option>
<option value="tcp_loss_out">Paquets perdus out</option>
<option value="throughput_in">Débit de paquets in</option>
<option value="throughput_out">Débit de paquets out</option>
<option value="turn_in">Pseudo requêtes in</option>
<option value="turn_out">Pseudo requêtes out</option>
<option value="call_prog_in">Appels in</option>
<option value="call_prog_out">Appels out</option>
<option value="call_est_in">Etablissements d&#039;appel in</option>
<option value="call_est_out">Etablissements d&#039;appel out</option>
<option value="call_req_in">Requêtes d&#039;appel in</option>
<option value="call_req_out">Requêtes d&#039;appel out</option>
<option value="call_end_in">Fins d&#039;appel in</option>
<option value="call_end_out">Fins d&#039;appel out</option>
<option value="call_can_in">Annulations d&#039;appel in</option>
<option value="call_can_out">Annulations d&#039;appel out</option>
<option value="call_rej_in">Rejets d&#039;appel in</option>
<option value="call_rej_out">Rejets d&#039;appel out</option>
<option value="tcp_sess_in">TCP Sessions in</option>
<option value="tcp_sess_out">TCP Sessions out</option>
<option value="udp_sess_in">UDP Sessions in</option>
<option value="udp_sess_out">UDP Sessions out</option>
<option value="rtp_sess_in">RTP Sessions in</option>
<option value="rtp_sess_out">RTP Sessions out</option></select></div></div><div id="customConfigtop_size"
 class="control-group"><label class="control-label" for="customConfig[top_size]"><span>Taille du top
</span></label><div class="controls"><input type="number" name="customConfig[top_size]" required="required"
 min="1" max="10" step="1" value="5"></div></div><hr/><div id="customConfigtop_filter" class="control-group"
><label class="control-label" for="customConfig[top_filter]"><span>Expression régulière</span></label
><div class="controls"><input name="customConfig[top_filter]" placeholder="Expression régulière" type
="text" value=""></div></div></div>
<div class="modal-footer">
    <a href="#" id="link_cancel_create_dashlet" class="btn sharp flat" data-dismiss="modal" aria-hidden
="true">
        Annuler    </a>
    <input type="hidden" name="csrf" value="4bbfe0f127f988eaf5de8139efc729b6"><input name="submit" type
="submit" class="btn btn-h5 sharp flat" value="Sauvegarder"></div>
</form>