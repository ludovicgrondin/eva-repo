<form action="/dashlet/METRIC_CHART/config/29" method="post" name="DASHLET_CONFIGURATION" id="dashlet-29-conf-form"
 class="form-horizontal"><div class="modal-header">
    <button id="button_cancel_create_dashlet" type="button" class="close" data-dismiss="modal" aria-hidden
="true">&times;</button>
    <h3>
        Graphique de métriques    </h3>
</div>
<div class="modal-body">
    <ul class="validation-errors text-error">
    </ul>
    <div id="commonConfigtitle" class="control-group"><label class="control-label" for="commonConfig
[title]"><span>Titre</span></label><div class="controls"><input name="commonConfig[title]" type="text"
 required="required" value="LINE"></div></div>    <div id="customConfigchart_type" class="control-group"
><label class="control-label" for="customConfig[chart_type]"><span>Type de graphique</span></label><div
 class="controls"><select name="customConfig[chart_type]" required="required"><option value="">-----
</option>
<option value="LINE" selected="selected">Série</option>
<option value="STACKEDAREA">Cumul</option>
<option value="PIE">Camembert</option></select></div></div><div id="customConfigdata_type" class="control-group"
><label class="control-label" for="customConfig[data_type]"><label for="id_metric_chart_data_type">Type
 de donnée</label></label><div class="controls"><select name="customConfig[data_type]" required="required"
 id="id_metric_chart_data_type"><option value="">-----</option>
<option value="TOTAL" selected="selected">Total</option>
<option value="IP">IP</option>
<option value="WO">Objet surveillé</option>
<option value="BF">Flux métier</option>
<option value="HTTP">Application HTTP</option>
<option value="VLAN">VLAN</option></select></div></div><div id="customConfigdata_identifier_ip" class
="control-group"><label class="control-label" for="customConfig[data_identifier_ip]"><span>Identifiant
 IP</span></label><div class="controls"><input name="customConfig[data_identifier_ip]" type="text" value
=""></div></div><div id="customConfigdata_identifier_wo" class="control-group"><label class="control-label"
 for="customConfig[data_identifier_wo]"><span>Identifiant objet surveillé</span></label><div class="controls"
><select name="customConfig[data_identifier_wo]"><option value="" selected="selected">-----</option>

<option value="ALAMBIX">ALAMBIX</option>
<option value="Alambix-1">Alambix-1</option>
<option value="Alambix-2">Alambix-2</option>
<option value="Alambix-3">Alambix-3</option>
<option value="Alambix-4">Alambix-4</option>
<option value="Alambix-5">Alambix-5</option>
<option value="Alambix-6">Alambix-6</option>
<option value="Alambix-7">Alambix-7</option>
<option value="Alambix-8">Alambix-8</option>
<option value="ANTENNE_EST">ANTENNE_EST</option>
<option value="ANTENNE_EST_LEBON">ANTENNE_EST_LEBON</option>
<option value="ANTENNE_OUEST">ANTENNE_OUEST</option>
<option value="ANTENNE_SUD">ANTENNE_SUD</option>
<option value="ANTENNE_SUD_2">ANTENNE_SUD_2</option>
<option value="APP MONITORING">APP MONITORING</option>
<option value="Arcgis">Arcgis</option>
<option value="Assurancetourix">Assurancetourix</option>
<option value="Asterisk">Asterisk</option>
<option value="Asterix">Asterix</option>
<option value="Boc-Group">Boc-Group</option>
<option value="Boulimix">Boulimix</option>
<option value="Boxi-GFI">Boxi-GFI</option>
<option value="CADJEE">CADJEE</option>
<option value="CCEE">CCEE</option>
<option value="CESER">CESER</option>
<option value="CHAUDRON">CHAUDRON</option>
<option value="Cindoc">Cindoc</option>
<option value="Citrix-0">Citrix-0</option>
<option value="Citrix-02">Citrix-02</option>
<option value="Citrix-04">Citrix-04</option>
<option value="Citrix-05">Citrix-05</option>
<option value="Citrix-06">Citrix-06</option>
<option value="Citrix-20">Citrix-20</option>
<option value="Citrix-21">Citrix-21</option>
<option value="Citrix-22">Citrix-22</option>
<option value="Citrix-23">Citrix-23</option>
<option value="Citrix-24">Citrix-24</option>
<option value="Citrix-25">Citrix-25</option>
<option value="Citrix-26">Citrix-26</option>
<option value="Citrix-27">Citrix-27</option>
<option value="Citrix-28">Citrix-28</option>
<option value="Citrix-29">Citrix-29</option>
<option value="Citrix-x">Citrix-x</option>
<option value="CLIENT">CLIENT</option>
<option value="CNR_NORD">CNR_NORD</option>
<option value="CNR_SAINT_BENOIT">CNR_SAINT_BENOIT</option>
<option value="CNR_SAINT_PAUL">CNR_SAINT_PAUL</option>
<option value="CNR_SAINT_PIERRE">CNR_SAINT_PIERRE</option>
<option value="CPOI">CPOI</option>
<option value="DACS">DACS</option>
<option value="DBA_CHAUDRON">DBA_CHAUDRON</option>
<option value="DDE_CHATEL">DDE_CHATEL</option>
<option value="DDE_LES_AIGRETTES">DDE_LES_AIGRETTES</option>
<option value="DDE_SAINT_PIERRE">DDE_SAINT_PIERRE</option>
<option value="DDE_SAINTE_BENOIT">DDE_SAINTE_BENOIT</option>
<option value="DIRECTION_RR">DIRECTION_RR</option>
<option value="DIRECTION_RR2">DIRECTION_RR2</option>
<option value="Directorix">Directorix</option>
<option value="DRIEM">DRIEM</option>
<option value="DRR">DRR</option>
<option value="ECM1">ECM1</option>
<option value="ECM2">ECM2</option>
<option value="EcmRegionInterne">EcmRegionInterne</option>
<option value="EDGC">EDGC</option>
<option value="ExtremeNetworks">ExtremeNetworks</option>
<option value="Firewall LAN">Firewall LAN</option>
<option value="FOUCHEROLLES">FOUCHEROLLES</option>
<option value="FOUCQUE_CHAUDRON">FOUCQUE_CHAUDRON</option>
<option value="Frame">Frame</option>
<option value="GECO">GECO</option>
<option value="Geco-Apache">Geco-Apache</option>
<option value="Geco-Bdd">Geco-Bdd</option>
<option value="Geco1">Geco1</option>
<option value="Geco2">Geco2</option>
<option value="Ged-GFI">Ged-GFI</option>
<option value="GERTRUDE">GERTRUDE</option>
<option value="GERTRUDE-PreProd">GERTRUDE-PreProd</option>
<option value="GRP_CITRIX">GRP_CITRIX</option>
<option value="GRP_XENAPP">GRP_XENAPP</option>
<option value="Impression">Impression</option>
<option value="Imprimante">Imprimante</option>
<option value="Infocentre">Infocentre</option>
<option value="INFRA_XENAPP">INFRA_XENAPP</option>
<option value="Iparapheur">Iparapheur</option>
<option value="ipout">ipout</option>
<option value="Ironport">Ironport</option>
<option value="Ironport31">Ironport31</option>
<option value="Ironport32">Ironport32</option>
<option value="Kaspersky">Kaspersky</option>
<option value="Keskonrix">Keskonrix</option>
<option value="ksv-172-16-16-105">ksv-172-16-16-105</option>
<option value="ksv-172-16-16-106">ksv-172-16-16-106</option>
<option value="ksv-172-16-16-107">ksv-172-16-16-107</option>
<option value="ksv-172-16-16-108">ksv-172-16-16-108</option>
<option value="Ligeo">Ligeo</option>
<option value="MAISON_FOUCQUE">MAISON_FOUCQUE</option>
<option value="Mifetout">Mifetout</option>
<option value="MimeSweeper-Clearswift">MimeSweeper-Clearswift</option>
<option value="mini">mini</option>
<option value="MOBIUS_OPEN_VPN">MOBIUS_OPEN_VPN</option>
<option value="MRST">MRST</option>
<option value="Naspro1">Naspro1</option>
<option value="Naspro2">Naspro2</option>
<option value="Naspro3">Naspro3</option>
<option value="NUXEO">NUXEO</option>
<option value="Oasis">Oasis</option>
<option value="Obelix">Obelix</option>
<option value="OCS-Region">OCS-Region</option>
<option value="Olfeo">Olfeo</option>
<option value="Pastel">Pastel</option>
<option value="Phoenix">Phoenix</option>
<option value="Photocopieur">Photocopieur</option>
<option value="Plagix">Plagix</option>
<option value="POSTE_CLIENT_HOTEL">POSTE_CLIENT_HOTEL</option>
<option value="Prod">Prod</option>
<option value="Proxy">Proxy</option>
<option value="Proxy Zimbra">Proxy Zimbra</option>
<option value="RUP">RUP</option>
<option value="SAMNA">SAMNA</option>
<option value="Semdee">Semdee</option>
<option value="SERVEUR">SERVEUR</option>
<option value="ServMercurial">ServMercurial</option>
<option value="ServWebIntranet2">ServWebIntranet2</option>
<option value="ServWebMail">ServWebMail</option>
<option value="ServWebMailProxy2">ServWebMailProxy2</option>
<option value="ServWebRsem">ServWebRsem</option>
<option value="ServWebRsemProxy">ServWebRsemProxy</option>
<option value="Sherpa">Sherpa</option>
<option value="Si-Ocr">Si-Ocr</option>
<option value="Srv_equatis">Srv_equatis</option>
<option value="STELLA_MATUTINA">STELLA_MATUTINA</option>
<option value="storefront1">storefront1</option>
<option value="SUPER_CAMELIA">SUPER_CAMELIA</option>
<option value="TELEPHONIE">TELEPHONIE</option>
<option value="TEST">TEST</option>
<option value="THALES">THALES</option>
<option value="vShield Manager Phoenix">vShield Manager Phoenix</option>
<option value="webdelib">webdelib</option>
<option value="webdelib-dedoo">webdelib-dedoo</option>
<option value="webdelib-test">webdelib-test</option>
<option value="Xenapp-01">Xenapp-01</option>
<option value="Xenapp-02">Xenapp-02</option>
<option value="Xenapp-03">Xenapp-03</option>
<option value="Xenapp-04">Xenapp-04</option>
<option value="Xenapp-05">Xenapp-05</option>
<option value="Xenapp-06">Xenapp-06</option>
<option value="Xenapp-07">Xenapp-07</option>
<option value="Xenapp-08">Xenapp-08</option>
<option value="Xenapp-09">Xenapp-09</option>
<option value="Xenapp-10">Xenapp-10</option>
<option value="Xenapp-11">Xenapp-11</option>
<option value="Xenapp-12">Xenapp-12</option>
<option value="Xenapp-13">Xenapp-13</option>
<option value="Xenapp-14">Xenapp-14</option>
<option value="Xenapp-15">Xenapp-15</option>
<option value="Xenapp-16">Xenapp-16</option>
<option value="Xenapp-17">Xenapp-17</option>
<option value="Xenapp-18">Xenapp-18</option>
<option value="Xenapp-19">Xenapp-19</option>
<option value="xenappagw">xenappagw</option>
<option value="xenappctrl1">xenappctrl1</option>
<option value="xenappctrl2">xenappctrl2</option>
<option value="xenappedgesight">xenappedgesight</option>
<option value="xenapplic">xenapplic</option>
<option value="xenappsql">xenappsql</option>
<option value="xenappweb1">xenappweb1</option>
<option value="xenappweb2">xenappweb2</option></select></div></div><div id="customConfigdata_identifier_bf"
 class="control-group"><label class="control-label" for="customConfig[data_identifier_bf]"><span>Identifiant
 flux métier</span></label><div class="controls"><select name="customConfig[data_identifier_bf]"><option
 value="" selected="selected">-----</option>
<option value="CENTREON-WEB">CENTREON-WEB</option>
<option value="PROXY-WEB">PROXY-WEB</option></select></div></div><div id="customConfigdata_identifier_http"
 class="control-group"><label class="control-label" for="customConfig[data_identifier_http]"><span>Identifiant
 application HTTP</span></label><div class="controls"><select name="customConfig[data_identifier_http
]"><option value="" selected="selected">-----</option></select></div></div><div id="customConfigdata_identifier_vlan"
 class="control-group"><label class="control-label" for="customConfig[data_identifier_vlan]"><span>Identifiant
 VLAN</span></label><div class="controls"><input name="customConfig[data_identifier_vlan]" type="text"
 value=""></div></div><div id="customConfigmetric_1" class="control-group"><label class="control-label"
 for="customConfig[metric_1]"><span>Métrique n°1</span></label><div class="controls"><select name="customConfig
[metric_1]" required="required"><option value="">-----</option>
<option value="bandwidth">Débit</option>
<option value="bandwidth_in" selected="selected">Débit in</option>
<option value="bandwidth_out">Débit out</option>
<option value="bytes">Volume</option>
<option value="bytes_in">Volume in</option>
<option value="bytes_out">Volume out</option>
<option value="con_fail_rate_in">Taux d&#039;échecs con. in</option>
<option value="con_fail_rate_out">Taux d&#039;échecs con. out</option>
<option value="con_req_in">Requêtes de connexion in</option>
<option value="con_req_out">Requêtes de connexion out</option>
<option value="con_setup_time_in">Tps de connexion in</option>
<option value="con_setup_time_out">Tps de connexion out</option>
<option value="delay_in">RTP Délai inter-paquets in</option>
<option value="delay_out">RTP Délai inter-paquets out</option>
<option value="con_est_in">Connexions établies in</option>
<option value="con_est_out">Connexions établies out</option>
<option value="jitter_in">RTP Gigue in</option>
<option value="jitter_out">RTP Gigue out</option>
<option value="loss_burst_in">RTP Taille des bursts in</option>
<option value="loss_burst_out">RTP Taille des bursts out</option>
<option value="loss_rate_in">Taux de perte in</option>
<option value="loss_rate_out">Taux de perte out</option>
<option value="mos_in">MOS calculé in</option>
<option value="mos_out">MOS calculé out</option>
<option value="out_of_seq_in">RTP Paquets hors séquence in</option>
<option value="out_of_seq_out">RTP Paquets hors séquence out</option>
<option value="pkts_in">Paquets in</option>
<option value="pkts_out">Paquets out</option>
<option value="payload_in">Charge utile in</option>
<option value="payload_out">Charge utile out</option>
<option value="rst_in">Resets TCP in</option>
<option value="rst_out">Resets TCP out</option>
<option value="ret_time_in">Tps de retrans. in</option>
<option value="ret_time_out">Tps de retrans. out</option>
<option value="rtp_dup_in">RTP Paquets dupliqués in</option>
<option value="rtp_dup_out">RTP Paquets dupliqués out</option>
<option value="rtp_loss_in">RTP Paquets perdus in</option>
<option value="rtp_loss_out">RTP Paquets perdus out</option>
<option value="rtt_in">RTT in</option>
<option value="rtt_out">RTT out</option>
<option value="serv_resp_time_in">Tps de réponse serveur in</option>
<option value="serv_resp_time_out">Tps de réponse serveur out</option>
<option value="tcp_dup_in">Paquets dupliqués in</option>
<option value="tcp_dup_out">Paquets dupliqués out</option>
<option value="tcp_loss_in">Paquets perdus in</option>
<option value="tcp_loss_out">Paquets perdus out</option>
<option value="throughput_in">Débit de paquets in</option>
<option value="throughput_out">Débit de paquets out</option>
<option value="turn_in">Pseudo requêtes in</option>
<option value="turn_out">Pseudo requêtes out</option>
<option value="call_prog_in">Appels in</option>
<option value="call_prog_out">Appels out</option>
<option value="call_est_in">Etablissements d&#039;appel in</option>
<option value="call_est_out">Etablissements d&#039;appel out</option>
<option value="call_req_in">Requêtes d&#039;appel in</option>
<option value="call_req_out">Requêtes d&#039;appel out</option>
<option value="call_end_in">Fins d&#039;appel in</option>
<option value="call_end_out">Fins d&#039;appel out</option>
<option value="call_can_in">Annulations d&#039;appel in</option>
<option value="call_can_out">Annulations d&#039;appel out</option>
<option value="call_rej_in">Rejets d&#039;appel in</option>
<option value="call_rej_out">Rejets d&#039;appel out</option>
<option value="tcp_sess_in">TCP Sessions in</option>
<option value="tcp_sess_out">TCP Sessions out</option>
<option value="udp_sess_in">UDP Sessions in</option>
<option value="udp_sess_out">UDP Sessions out</option>
<option value="rtp_sess_in">RTP Sessions in</option>
<option value="rtp_sess_out">RTP Sessions out</option></select></div></div><div id="customConfigmetric_2"
 class="control-group"><label class="control-label" for="customConfig[metric_2]"><span>Métrique n°2<
/span></label><div class="controls"><select name="customConfig[metric_2]"><option value="">-----</option
>
<option value="bandwidth">Débit</option>
<option value="bandwidth_in">Débit in</option>
<option value="bandwidth_out" selected="selected">Débit out</option>
<option value="bytes">Volume</option>
<option value="bytes_in">Volume in</option>
<option value="bytes_out">Volume out</option>
<option value="con_fail_rate_in">Taux d&#039;échecs con. in</option>
<option value="con_fail_rate_out">Taux d&#039;échecs con. out</option>
<option value="con_req_in">Requêtes de connexion in</option>
<option value="con_req_out">Requêtes de connexion out</option>
<option value="con_setup_time_in">Tps de connexion in</option>
<option value="con_setup_time_out">Tps de connexion out</option>
<option value="delay_in">RTP Délai inter-paquets in</option>
<option value="delay_out">RTP Délai inter-paquets out</option>
<option value="con_est_in">Connexions établies in</option>
<option value="con_est_out">Connexions établies out</option>
<option value="jitter_in">RTP Gigue in</option>
<option value="jitter_out">RTP Gigue out</option>
<option value="loss_burst_in">RTP Taille des bursts in</option>
<option value="loss_burst_out">RTP Taille des bursts out</option>
<option value="loss_rate_in">Taux de perte in</option>
<option value="loss_rate_out">Taux de perte out</option>
<option value="mos_in">MOS calculé in</option>
<option value="mos_out">MOS calculé out</option>
<option value="out_of_seq_in">RTP Paquets hors séquence in</option>
<option value="out_of_seq_out">RTP Paquets hors séquence out</option>
<option value="pkts_in">Paquets in</option>
<option value="pkts_out">Paquets out</option>
<option value="payload_in">Charge utile in</option>
<option value="payload_out">Charge utile out</option>
<option value="rst_in">Resets TCP in</option>
<option value="rst_out">Resets TCP out</option>
<option value="ret_time_in">Tps de retrans. in</option>
<option value="ret_time_out">Tps de retrans. out</option>
<option value="rtp_dup_in">RTP Paquets dupliqués in</option>
<option value="rtp_dup_out">RTP Paquets dupliqués out</option>
<option value="rtp_loss_in">RTP Paquets perdus in</option>
<option value="rtp_loss_out">RTP Paquets perdus out</option>
<option value="rtt_in">RTT in</option>
<option value="rtt_out">RTT out</option>
<option value="serv_resp_time_in">Tps de réponse serveur in</option>
<option value="serv_resp_time_out">Tps de réponse serveur out</option>
<option value="tcp_dup_in">Paquets dupliqués in</option>
<option value="tcp_dup_out">Paquets dupliqués out</option>
<option value="tcp_loss_in">Paquets perdus in</option>
<option value="tcp_loss_out">Paquets perdus out</option>
<option value="throughput_in">Débit de paquets in</option>
<option value="throughput_out">Débit de paquets out</option>
<option value="turn_in">Pseudo requêtes in</option>
<option value="turn_out">Pseudo requêtes out</option>
<option value="call_prog_in">Appels in</option>
<option value="call_prog_out">Appels out</option>
<option value="call_est_in">Etablissements d&#039;appel in</option>
<option value="call_est_out">Etablissements d&#039;appel out</option>
<option value="call_req_in">Requêtes d&#039;appel in</option>
<option value="call_req_out">Requêtes d&#039;appel out</option>
<option value="call_end_in">Fins d&#039;appel in</option>
<option value="call_end_out">Fins d&#039;appel out</option>
<option value="call_can_in">Annulations d&#039;appel in</option>
<option value="call_can_out">Annulations d&#039;appel out</option>
<option value="call_rej_in">Rejets d&#039;appel in</option>
<option value="call_rej_out">Rejets d&#039;appel out</option>
<option value="tcp_sess_in">TCP Sessions in</option>
<option value="tcp_sess_out">TCP Sessions out</option>
<option value="udp_sess_in">UDP Sessions in</option>
<option value="udp_sess_out">UDP Sessions out</option>
<option value="rtp_sess_in">RTP Sessions in</option>
<option value="rtp_sess_out">RTP Sessions out</option></select></div></div><div id="customConfigmetric_3"
 class="control-group"><label class="control-label" for="customConfig[metric_3]"><span>Métrique n°3<
/span></label><div class="controls"><select name="customConfig[metric_3]"><option value="" selected="selected"
>-----</option>
<option value="bandwidth">Débit</option>
<option value="bandwidth_in">Débit in</option>
<option value="bandwidth_out">Débit out</option>
<option value="bytes">Volume</option>
<option value="bytes_in">Volume in</option>
<option value="bytes_out">Volume out</option>
<option value="con_fail_rate_in">Taux d&#039;échecs con. in</option>
<option value="con_fail_rate_out">Taux d&#039;échecs con. out</option>
<option value="con_req_in">Requêtes de connexion in</option>
<option value="con_req_out">Requêtes de connexion out</option>
<option value="con_setup_time_in">Tps de connexion in</option>
<option value="con_setup_time_out">Tps de connexion out</option>
<option value="delay_in">RTP Délai inter-paquets in</option>
<option value="delay_out">RTP Délai inter-paquets out</option>
<option value="con_est_in">Connexions établies in</option>
<option value="con_est_out">Connexions établies out</option>
<option value="jitter_in">RTP Gigue in</option>
<option value="jitter_out">RTP Gigue out</option>
<option value="loss_burst_in">RTP Taille des bursts in</option>
<option value="loss_burst_out">RTP Taille des bursts out</option>
<option value="loss_rate_in">Taux de perte in</option>
<option value="loss_rate_out">Taux de perte out</option>
<option value="mos_in">MOS calculé in</option>
<option value="mos_out">MOS calculé out</option>
<option value="out_of_seq_in">RTP Paquets hors séquence in</option>
<option value="out_of_seq_out">RTP Paquets hors séquence out</option>
<option value="pkts_in">Paquets in</option>
<option value="pkts_out">Paquets out</option>
<option value="payload_in">Charge utile in</option>
<option value="payload_out">Charge utile out</option>
<option value="rst_in">Resets TCP in</option>
<option value="rst_out">Resets TCP out</option>
<option value="ret_time_in">Tps de retrans. in</option>
<option value="ret_time_out">Tps de retrans. out</option>
<option value="rtp_dup_in">RTP Paquets dupliqués in</option>
<option value="rtp_dup_out">RTP Paquets dupliqués out</option>
<option value="rtp_loss_in">RTP Paquets perdus in</option>
<option value="rtp_loss_out">RTP Paquets perdus out</option>
<option value="rtt_in">RTT in</option>
<option value="rtt_out">RTT out</option>
<option value="serv_resp_time_in">Tps de réponse serveur in</option>
<option value="serv_resp_time_out">Tps de réponse serveur out</option>
<option value="tcp_dup_in">Paquets dupliqués in</option>
<option value="tcp_dup_out">Paquets dupliqués out</option>
<option value="tcp_loss_in">Paquets perdus in</option>
<option value="tcp_loss_out">Paquets perdus out</option>
<option value="throughput_in">Débit de paquets in</option>
<option value="throughput_out">Débit de paquets out</option>
<option value="turn_in">Pseudo requêtes in</option>
<option value="turn_out">Pseudo requêtes out</option>
<option value="call_prog_in">Appels in</option>
<option value="call_prog_out">Appels out</option>
<option value="call_est_in">Etablissements d&#039;appel in</option>
<option value="call_est_out">Etablissements d&#039;appel out</option>
<option value="call_req_in">Requêtes d&#039;appel in</option>
<option value="call_req_out">Requêtes d&#039;appel out</option>
<option value="call_end_in">Fins d&#039;appel in</option>
<option value="call_end_out">Fins d&#039;appel out</option>
<option value="call_can_in">Annulations d&#039;appel in</option>
<option value="call_can_out">Annulations d&#039;appel out</option>
<option value="call_rej_in">Rejets d&#039;appel in</option>
<option value="call_rej_out">Rejets d&#039;appel out</option>
<option value="tcp_sess_in">TCP Sessions in</option>
<option value="tcp_sess_out">TCP Sessions out</option>
<option value="udp_sess_in">UDP Sessions in</option>
<option value="udp_sess_out">UDP Sessions out</option>
<option value="rtp_sess_in">RTP Sessions in</option>
<option value="rtp_sess_out">RTP Sessions out</option></select></div></div><div id="customConfigmetric_4"
 class="control-group"><label class="control-label" for="customConfig[metric_4]"><span>Métrique n°4<
/span></label><div class="controls"><select name="customConfig[metric_4]"><option value="" selected="selected"
>-----</option>
<option value="bandwidth">Débit</option>
<option value="bandwidth_in">Débit in</option>
<option value="bandwidth_out">Débit out</option>
<option value="bytes">Volume</option>
<option value="bytes_in">Volume in</option>
<option value="bytes_out">Volume out</option>
<option value="con_fail_rate_in">Taux d&#039;échecs con. in</option>
<option value="con_fail_rate_out">Taux d&#039;échecs con. out</option>
<option value="con_req_in">Requêtes de connexion in</option>
<option value="con_req_out">Requêtes de connexion out</option>
<option value="con_setup_time_in">Tps de connexion in</option>
<option value="con_setup_time_out">Tps de connexion out</option>
<option value="delay_in">RTP Délai inter-paquets in</option>
<option value="delay_out">RTP Délai inter-paquets out</option>
<option value="con_est_in">Connexions établies in</option>
<option value="con_est_out">Connexions établies out</option>
<option value="jitter_in">RTP Gigue in</option>
<option value="jitter_out">RTP Gigue out</option>
<option value="loss_burst_in">RTP Taille des bursts in</option>
<option value="loss_burst_out">RTP Taille des bursts out</option>
<option value="loss_rate_in">Taux de perte in</option>
<option value="loss_rate_out">Taux de perte out</option>
<option value="mos_in">MOS calculé in</option>
<option value="mos_out">MOS calculé out</option>
<option value="out_of_seq_in">RTP Paquets hors séquence in</option>
<option value="out_of_seq_out">RTP Paquets hors séquence out</option>
<option value="pkts_in">Paquets in</option>
<option value="pkts_out">Paquets out</option>
<option value="payload_in">Charge utile in</option>
<option value="payload_out">Charge utile out</option>
<option value="rst_in">Resets TCP in</option>
<option value="rst_out">Resets TCP out</option>
<option value="ret_time_in">Tps de retrans. in</option>
<option value="ret_time_out">Tps de retrans. out</option>
<option value="rtp_dup_in">RTP Paquets dupliqués in</option>
<option value="rtp_dup_out">RTP Paquets dupliqués out</option>
<option value="rtp_loss_in">RTP Paquets perdus in</option>
<option value="rtp_loss_out">RTP Paquets perdus out</option>
<option value="rtt_in">RTT in</option>
<option value="rtt_out">RTT out</option>
<option value="serv_resp_time_in">Tps de réponse serveur in</option>
<option value="serv_resp_time_out">Tps de réponse serveur out</option>
<option value="tcp_dup_in">Paquets dupliqués in</option>
<option value="tcp_dup_out">Paquets dupliqués out</option>
<option value="tcp_loss_in">Paquets perdus in</option>
<option value="tcp_loss_out">Paquets perdus out</option>
<option value="throughput_in">Débit de paquets in</option>
<option value="throughput_out">Débit de paquets out</option>
<option value="turn_in">Pseudo requêtes in</option>
<option value="turn_out">Pseudo requêtes out</option>
<option value="call_prog_in">Appels in</option>
<option value="call_prog_out">Appels out</option>
<option value="call_est_in">Etablissements d&#039;appel in</option>
<option value="call_est_out">Etablissements d&#039;appel out</option>
<option value="call_req_in">Requêtes d&#039;appel in</option>
<option value="call_req_out">Requêtes d&#039;appel out</option>
<option value="call_end_in">Fins d&#039;appel in</option>
<option value="call_end_out">Fins d&#039;appel out</option>
<option value="call_can_in">Annulations d&#039;appel in</option>
<option value="call_can_out">Annulations d&#039;appel out</option>
<option value="call_rej_in">Rejets d&#039;appel in</option>
<option value="call_rej_out">Rejets d&#039;appel out</option>
<option value="tcp_sess_in">TCP Sessions in</option>
<option value="tcp_sess_out">TCP Sessions out</option>
<option value="udp_sess_in">UDP Sessions in</option>
<option value="udp_sess_out">UDP Sessions out</option>
<option value="rtp_sess_in">RTP Sessions in</option>
<option value="rtp_sess_out">RTP Sessions out</option></select></div></div><div id="customConfigmetric_5"
 class="control-group"><label class="control-label" for="customConfig[metric_5]"><span>Métrique n°5<
/span></label><div class="controls"><select name="customConfig[metric_5]"><option value="" selected="selected"
>-----</option>
<option value="bandwidth">Débit</option>
<option value="bandwidth_in">Débit in</option>
<option value="bandwidth_out">Débit out</option>
<option value="bytes">Volume</option>
<option value="bytes_in">Volume in</option>
<option value="bytes_out">Volume out</option>
<option value="con_fail_rate_in">Taux d&#039;échecs con. in</option>
<option value="con_fail_rate_out">Taux d&#039;échecs con. out</option>
<option value="con_req_in">Requêtes de connexion in</option>
<option value="con_req_out">Requêtes de connexion out</option>
<option value="con_setup_time_in">Tps de connexion in</option>
<option value="con_setup_time_out">Tps de connexion out</option>
<option value="delay_in">RTP Délai inter-paquets in</option>
<option value="delay_out">RTP Délai inter-paquets out</option>
<option value="con_est_in">Connexions établies in</option>
<option value="con_est_out">Connexions établies out</option>
<option value="jitter_in">RTP Gigue in</option>
<option value="jitter_out">RTP Gigue out</option>
<option value="loss_burst_in">RTP Taille des bursts in</option>
<option value="loss_burst_out">RTP Taille des bursts out</option>
<option value="loss_rate_in">Taux de perte in</option>
<option value="loss_rate_out">Taux de perte out</option>
<option value="mos_in">MOS calculé in</option>
<option value="mos_out">MOS calculé out</option>
<option value="out_of_seq_in">RTP Paquets hors séquence in</option>
<option value="out_of_seq_out">RTP Paquets hors séquence out</option>
<option value="pkts_in">Paquets in</option>
<option value="pkts_out">Paquets out</option>
<option value="payload_in">Charge utile in</option>
<option value="payload_out">Charge utile out</option>
<option value="rst_in">Resets TCP in</option>
<option value="rst_out">Resets TCP out</option>
<option value="ret_time_in">Tps de retrans. in</option>
<option value="ret_time_out">Tps de retrans. out</option>
<option value="rtp_dup_in">RTP Paquets dupliqués in</option>
<option value="rtp_dup_out">RTP Paquets dupliqués out</option>
<option value="rtp_loss_in">RTP Paquets perdus in</option>
<option value="rtp_loss_out">RTP Paquets perdus out</option>
<option value="rtt_in">RTT in</option>
<option value="rtt_out">RTT out</option>
<option value="serv_resp_time_in">Tps de réponse serveur in</option>
<option value="serv_resp_time_out">Tps de réponse serveur out</option>
<option value="tcp_dup_in">Paquets dupliqués in</option>
<option value="tcp_dup_out">Paquets dupliqués out</option>
<option value="tcp_loss_in">Paquets perdus in</option>
<option value="tcp_loss_out">Paquets perdus out</option>
<option value="throughput_in">Débit de paquets in</option>
<option value="throughput_out">Débit de paquets out</option>
<option value="turn_in">Pseudo requêtes in</option>
<option value="turn_out">Pseudo requêtes out</option>
<option value="call_prog_in">Appels in</option>
<option value="call_prog_out">Appels out</option>
<option value="call_est_in">Etablissements d&#039;appel in</option>
<option value="call_est_out">Etablissements d&#039;appel out</option>
<option value="call_req_in">Requêtes d&#039;appel in</option>
<option value="call_req_out">Requêtes d&#039;appel out</option>
<option value="call_end_in">Fins d&#039;appel in</option>
<option value="call_end_out">Fins d&#039;appel out</option>
<option value="call_can_in">Annulations d&#039;appel in</option>
<option value="call_can_out">Annulations d&#039;appel out</option>
<option value="call_rej_in">Rejets d&#039;appel in</option>
<option value="call_rej_out">Rejets d&#039;appel out</option>
<option value="tcp_sess_in">TCP Sessions in</option>
<option value="tcp_sess_out">TCP Sessions out</option>
<option value="udp_sess_in">UDP Sessions in</option>
<option value="udp_sess_out">UDP Sessions out</option>
<option value="rtp_sess_in">RTP Sessions in</option>
<option value="rtp_sess_out">RTP Sessions out</option></select></div></div>
<script type="text/javascript">
$(document).ready(function() {
	var CONFIGURATION_METRIC_CHART = (function() {
		// ---------------------------------------------------------------------
		// Variable
		// ---------------------------------------------------------------------
		var var_public = {};
		// ---------------------------------------------------------------------
		// Public
		// ---------------------------------------------------------------------
		var_public.setDataIdentifier = function(divId) {
			var dataType = $(divId + ' #id_metric_chart_data_type').val();

			switch (dataType) {
			case 'IP':
				$(divId + ' #customConfigdata_identifier_ip').show();
				$(divId + ' #customConfigdata_identifier_wo').hide();
				$(divId + ' #customConfigdata_identifier_bf').hide();
				$(divId + ' #customConfigdata_identifier_http').hide();
				$(divId + ' #customConfigdata_identifier_vlan').hide();
				break;
			case 'WO':
				$(divId + ' #customConfigdata_identifier_ip').hide();
				$(divId + ' #customConfigdata_identifier_wo').show();
				$(divId + ' #customConfigdata_identifier_bf').hide();
				$(divId + ' #customConfigdata_identifier_http').hide();
				$(divId + ' #customConfigdata_identifier_vlan').hide();
				break;
			case 'BF':
				$(divId + ' #customConfigdata_identifier_ip').hide();
				$(divId + ' #customConfigdata_identifier_wo').hide();
				$(divId + ' #customConfigdata_identifier_bf').show();
				$(divId + ' #customConfigdata_identifier_http').hide();
				$(divId + ' #customConfigdata_identifier_vlan').hide();
				break;
			case 'HTTP':
				$(divId + ' #customConfigdata_identifier_ip').hide();
				$(divId + ' #customConfigdata_identifier_wo').hide();
				$(divId + ' #customConfigdata_identifier_bf').hide();
				$(divId + ' #customConfigdata_identifier_http').show();
				$(divId + ' #customConfigdata_identifier_vlan').hide();
				break;
			case 'VLAN':
				$(divId + ' #customConfigdata_identifier_ip').hide();
				$(divId + ' #customConfigdata_identifier_wo').hide();
				$(divId + ' #customConfigdata_identifier_bf').hide();
				$(divId + ' #customConfigdata_identifier_http').hide();
				$(divId + ' #customConfigdata_identifier_vlan').show();
				break;
			default:
				$(divId + ' #customConfigdata_identifier_ip').hide();
				$(divId + ' #customConfigdata_identifier_wo').hide();
				$(divId + ' #customConfigdata_identifier_bf').hide();
				$(divId + ' #customConfigdata_identifier_http').hide();
				$(divId + ' #customConfigdata_identifier_vlan').hide();
				break;
			}
		};
		// ---------------------------------------------------------------------
		return var_public;
		// ---------------------------------------------------------------------
	})();

	var dashletId = '29';
	var divId = '#dashlet-' + dashletId + '-conf-form';
	
	$(divId + ' #id_metric_chart_data_type').change(function() {
		CONFIGURATION_METRIC_CHART.setDataIdentifier(divId);
	});

	CONFIGURATION_METRIC_CHART.setDataIdentifier(divId);
});
</script>
</div>
<div class="modal-footer">
    <a href="#" id="link_cancel_create_dashlet" class="btn sharp flat" data-dismiss="modal" aria-hidden
="true">
        Annuler    </a>
    <input type="hidden" name="csrf" value="94ba18b0eb6753c1fb44b8ca649d6e9e"><input name="submit" type
="submit" class="btn btn-h5 sharp flat" value="Sauvegarder"></div>
</form>