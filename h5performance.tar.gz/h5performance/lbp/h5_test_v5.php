<?php
/**
 * \file      Data_H5_main.c
 * \author    Anonime
 * \version   1.0
 * \date      16 Juin 2015
 * \brief     Fichier principale.
 *
 * \details   Ce fichier est le fichier principale, il contien des exemples
 *            de configuration.
 */

require 'WsUser.php';
require 'MyProbeDataService.php';

/**
 * \detail
 *
 *- Pour obtenir un graphe historique sur la derniére journée pour rtt_in et rtt_out:
 *\n $WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");   // instanciation de l'objet
 *\n $WSdata->setChartFonc("getMetricTimingChart"); 
 *\n $WSdata->setDataIdentifier(null);  
 *\n $WSdata->setDataMetrics(array("rtt_in", "rtt_out")); 
 *\n $WSdata->setDataType("TOTAL"); 
 *\n $WSdata->setPeriod("LAST_DAY");
 *\n $data=$WSdata->getTimingChart(); 
 *\n       //    /!\ le DataIdentifier est en fonction du DataType (a trouver dans la configurat)
 *\n 
 *\n - pour un graphe historique des 5 aplication TCP utilisant le plus de débit concernant l'@ IP 192.168.0.24:
 *\n $WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
 *\n $WSdata->setChartFonc("getFilteredTopTimingChart"); 
 *\n $WSdata->setPeriod("LAST_DAY");
 *\n $WSdata->setFilteredTopType("TCP"); // Selectione le type d'aplication a classé 
 *\n $WSdata->setMetric("bandwidth");
 *\n $WSdata->setIp("192.168.0.24"); // filtre de sélection de l'IP
 *\n $WSdata->setSize(5); //le nombre max d'élément clasé dans le graphe
 *\n $data=$WSdata->getTimingChart();
 *\n 
 *\n - les équivalent en camenbert sont obtenu en remplacant "timing" par "pie":
 *\n $WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
 *\n $WSdata->setChartFonc("getFilteredTopPieChart"); 
 *\n $WSdata->setPeriod("LAST_DAY");
 *\n $WSdata->setFilteredTopType("TCP");
 *\n $WSdata->setTopMetric("bandwidth"); 
 *\n $WSdata->setSize(5);
 *\n $data=$WSdata->getChart(); // récupére le résultat sous forme de tableau
 *\n 
 *\n - pour son équivelent sans filtrage peut étre réaliser en metant les filtres a null ou de la maniére suivante:
 *\n $WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
 *\n $WSdata->setChartFonc("getTopTimingChart"); 
 *\n $WSdata->setPeriod("LAST_DAY");
 *\n $WSdata->setTopType("TCP");
 *\n $WSdata->setTopMetric("bandwidth"); 
 *\n $WSdata->setSize(5);
 *\n $data=$WSdata->getTimingChart();
 *\n  
 *\n - pour son équivalent en filtrant sur un objet surveillé on remplace le filtre IP par un filtre WO ce qui donne:
 *\n $WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
 *\n $WSdata->setChartFonc("getFilteredTopTimingChart"); 
 *\n $WSdata->setDataType("TOTAL"); 
 *\n $WSdata->setPeriod("LAST_DAY");
 *\n $WSdata->setFilter("HTTP");
 *\n $WSdata->setFilteredTopType("TCP");
 *\n $WSdata->setWo("Sonde");
 *\n $WSdata->setTopMetric("bandwidth"); 
 *\n $WSdata->setSize(5);
 *\n $data=$WSdata->getTimingChart();
 *\n 
 *\n - pour intéroger directement un objet ou plusieurs objet:
 *\n $WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
 *\n $WSdata->setChartFonc("getObjectTimingChart"); 
 *\n $WSdata->setPeriod("LAST_DAY");
 *\n $WSdata->setWo(array("Sonde", "objet2"));
 *\n $WSdata->setMetric("bandwidth"); 
 *\n $WSdata->setDataType("WO");
 *\n $data=$WSdata->getChart();
 *\n 
 */
$exemple= '';

// ----------------------------------------------------------------    source -------------------------------------------------------------

$UserName= 'administrateur';
$UserPwd= 'h5admin';
$WsServer= '192.168.0.22';
$WsPort= '8080';

$MyWsUser = new WsUser();
$MyWsUser -> setLogin($UserName);
$MyWsUser -> setPassword($UserPwd);
$MyWsUser -> setProbe($WsServer);
$MyWsUser -> setPort($WsPort);

/*
$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getMetricTimingChart");	
$WSdata->setDataIdentifier(null);	
$WSdata->setDataMetrics(array("rtt_in", "rtt_out"));	
$WSdata->setDataType("TOTAL");	
$WSdata->setPeriod("LAST_DAY");
$data=$WSdata->getTimingChart();
*/

/*
$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getFilteredTopTimingChart");	
$WSdata->setPeriod("LAST_DAY");
//$WSdata->setFilter("HTTP");
$WSdata->setFilteredTopType("TCP");
//$WSdata->setIp("192.168.0.24");
$WSdata->setMetric("bandwidth");	
$WSdata->setSize(5);
$data=$WSdata->getTimingChart();
*/

/*
$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getTopTimingChart");	
//$WSdata->setDataType("TOTAL");	
$WSdata->setPeriod("LAST_DAY");
$WSdata->setTopType("TCP");
$WSdata->setTopMetric("bandwidth");	
$WSdata->setSize(5);
$data=$WSdata->getTimingChart();
*/

/*
$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getFilteredTopTimingChart");	
$WSdata->setDataType("TOTAL");	
$WSdata->setPeriod("LAST_DAY");
//$WSdata->setFilter("HTTP");
$WSdata->setFilteredTopType("TCP");
$WSdata->setWo("Sonde");
$WSdata->setMetric("bandwidth");	
$WSdata->setSize(5);
$data=$WSdata->getTimingChart();
*/

/*
$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getObjectTimingChart");	
$WSdata->setPeriod("LAST_DAY");
$WSdata->setWo(array("Sonde"));
$WSdata->setMetric("bandwidth");	
$WSdata->setDataType("WO");
$data=$WSdata->getTimingChart();
*/
/*
$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getFilteredTopTimingChart");	
$WSdata->setPeriod("LAST_DAY");
$WSdata->setFilteredTopType("IP");
$WSdata->setWo("APP MONITORING");
$WSdata->setMetric("bandwidth_out");	
$WSdata->setSize(5);
//$data=$WSdata->getTimingChart();
$data=$WSdata->getChart();

//var_dump ($data);
echo "$data \n\n";

$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getFilteredTopPieChart");	
$WSdata->setPeriod("LAST_DAY");
$WSdata->setFilteredTopType("IP");
$WSdata->setWo("APP MONITORING");
$WSdata->setIpOrWo("IP");
$WSdata->setMetric("bytes_out");	
$WSdata->setSize(5);
$data=$WSdata->getChart(); 


//var_dump ($data);
*/

$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");   // instanciation de l'objet
$WSdata->setChartFonc("getMetricTimingChart"); 
$WSdata->setDataIdentifier(null);  
$WSdata->setDataMetrics(array("rtt_in", "rtt_out")); 
$WSdata->setDataType("TOTAL"); 
$WSdata->setPeriod("LAST_DAY");
$data=$WSdata->getTimingChart(); 
echo "$data \n\n";
