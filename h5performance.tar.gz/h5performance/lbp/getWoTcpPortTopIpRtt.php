<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 * \file      Data_H5_main.c
 * \author    Ludo
 * \version   1.0
 * \date      16 Juin 2015
 * \brief     RTT et SRT d'un objet surveillé
 */

require 'WsUser.php';
require 'MyProbeDataService.php';

$UserName= 'administrateur';
$UserPwd= 'h5admin';
$WsServer= '10.205.12.64';
$WsPort= '8080';

$MyWsUser = new WsUser();
$MyWsUser -> setLogin($UserName);
$MyWsUser -> setPassword($UserPwd);
$MyWsUser -> setProbe($WsServer);
$MyWsUser -> setPort($WsPort);

$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getFilteredTopTimingChart");	
$WSdata->setPeriod("LAST_DAY");
$WSdata->setFilteredTopType("IP");
$WSdata->setIpOrWo("WO");
$WSdata->setWo("AMON ADMIN");
//$WSdata->setProtocol("TCP");
//$WSdata->setTcpPort("443");  
$WSdata->setMetric("bandwidth_out");	
$WSdata->setSize(10);
$data=$WSdata->getTopTimingChart();
echo "$data \n\n";
//$data=$WSdata->getChart(); 
//var_dump ($data);
