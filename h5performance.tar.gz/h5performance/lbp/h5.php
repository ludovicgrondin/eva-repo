<?php
if($_GET["id"] == 1){
$chart_id = 1;
$homepage = file_get_contents('https://10.140.4.6/h5performance/getWoRttSrt.php');
}else if($_GET["id"] == 2){
$chart_id = 2;
$homepage = file_get_contents('https://10.140.4.6/h5performance/getWoTcpPortTopIpRtt.php');
}else if($_GET["id"] == 3){
$chart_id = 3;
$homepage = file_get_contents('https://10.140.4.6/h5performance/getWoTopIpCam.php');
}else {
$homepage = file_get_contents('https://192.168.0.72/h5performance/getWoRttSrt.php');
$chart_id = 1;
}
if (isset($_GET["type"])){
$type = $_GET["type"];
// options possibles = pie, stackedarea, line
}else{
$type = 'line';
}
if (isset($_GET["setting"])){
$setting = $_GET["setting"];
// options possibles = TOP_TIMING_CHART_SETTINGS , METRIC_CHART_SETTINGS, TOP_PIE_CHART_SETTINGS
}else{
$setting = 'TOP_TIMING_CHART_SETTINGS';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
   "http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">
<head>
<meta http-equiv="refresh" content="300">
 <!-- CSS -->
<link href="js/jqwidgets/styles/jqx.base.css" media="screen" rel="stylesheet" type="text/css">
<link href="js/jqwidgets/styles/jqx.metro.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/style.css" media="screen" rel="stylesheet" type="text/css">

 <!-- JS jqwidgets -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxcore.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxchart.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxdata.js"></script>

 <!-- JS h5 chart settings -->
<script type="text/javascript" src="js/h5.main.js"></script> <!-- Couleurs metric -->
<script type="text/javascript" src="js/dashlet/chart/chart.js"></script>
<script type="text/javascript" src="js/dashlet/chart/toptimingchart.js"></script>
<script type="text/javascript" src="js/dashlet/chart/toppiechart.js"></script>
<script type="text/javascript" src="js/dashlet/chart/metricchart.js"></script>
<script type="text/javascript" src="js/dashlet/alarm/alarmgravityhistory.js"></script>
<script type="text/javascript" src="js/dashlet/alarm/alarmgravitytop.js"></script>

<!--<script type="text/javascript" src="js/jqwidgets/jqxgrid.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<link href="js/jqwidgets/styles/jqx.bootstrap.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/bootstrap.min.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/bootstrap-responsive.min.css" media="screen" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jqwidgets/jqxgrid.grouping.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxgrid.edit.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxgrid.pager.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxgrid.sort.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxgrid.filter.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxgrid.columnsresize.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxgrid.selection.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxdropdownlist.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxlistbox.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxmenu.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxscrollbar.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxwindow.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxdragdrop.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxchart.js"></script> 
<script type="text/javascript" src="js/Dashboard/main.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxsplitter.js"></script> 
<script type="text/javascript" src="js/jqwidgets/jqxcheckbox.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxbuttons.js"></script>
<script type="text/javascript" src="js/jqwidgets/jqxtooltip.js"></script>
<script type="text/javascript" src="js/h5/h5.modal.js"></script>
<script type="text/javascript" src="js/h5/calendar/h5.calendar.js"></script>
<script type="text/javascript" src="js/h5/tree/h5.tree.js"></script>
<script type="text/javascript" src="js/h5/h5.utils.js"></script>
<script type="text/javascript" src="js/h5/dashboard/h5.dashboard.js"></script>
<link href="js/h5/tree/css/h5.tree.css" media="screen" rel="stylesheet" type="text/css">
<link href="js/h5/calendar/css/h5.calendar.css" media="screen" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/h5/dashlet/h5.dashlet.js"></script>
-->

</head>
<body>
<!-- <div id="splitter" class="row-fluid"></div> -->
<script type="text/javascript">
	var CHART_ENABLE_ANIMATIONS = true;
</script>
<div class="chart-container"
	id="metric-chart-<?php echo $chart_id; ?>"
	style="width: 100%; height: 250px"></div>    

<script type="text/javascript">
$(document).ready(function() {
	var dashlet = $('#metric-chart-<?php echo $chart_id; ?>');
	
	dashlet.jqxChart('showToolTips', true);
	
	var width = dashlet.width();
	var height = dashlet.height();
	var period = 'LAST_DAY';
	var chartType = '<?php echo $type; ?>';
	var language = 'fr_FR';
	var chartData = <?php echo $homepage; ?>;
	var settings = <?php echo $setting; ?>.getSettings(
				width,
				height,
				period,
				chartData,
				chartType,
				language);
	
	dashlet.jqxChart(settings);
		 
	});
</script>
</body>
</html>