<?php
/**
 * \file      Data_H5_main.c
 * \author    Ludo
 * \version   1.0
 * \date      16 Juin 2015
 * \brief     Graphique de métriques : $WSdata->setChartFonc("getMetricTimingChart");
 */
 
/**
PARAMETERS:
 
Type de graphe: (pas nécessaire ici)
 - pie 
 - stackedarea 
 - line
 
Période : $WSdata->setPeriod("LAST_DAY");
 - LAST_DAY
 - LAST_WEEK
 - LAST_MONTH

Type de données : $WSdata->setDataType()
 - TOTAL (Total)
 - IP (IP)
 - WO (Objet surveillé)
 - BF (Flux métier)
 - HTTP (Application HTTP)
 - VLAN (VLAN)
 
Identifiant (IP ou WO ou BF ou HTTP ou VLAN) : $WSdata->setDataIdentifier()
 - L'indentifiant du type de données concerné (ex: 192.168.0.10 ou PROXY)
 - Pas nécessaire pour le TOTAL
 
 Métriques : $WSdata->setDataMetrics(array("m1", "m2"));
 
------ Débit/Volume/Charge ------
"bandwidth" => "Débit",
"bandwidth_in" => "Débit in",
"bandwidth_out" => "Débit out",
"bytes" => "Volume",
"bytes_in" => "Volume in",
"bytes_out" => "Volume out",
"pkts_in" => "Paquets in",
"pkts_out" => "Paquets out",
"payload_in" => "Charge utile in",
"payload_out" => "Charge utile out",
"throughput_in" => "Débit de paquets in",
"throughput_out" => "Débit de paquets out",
"turn_in" => "Pseudo requêtes in",
"turn_out" => "Pseudo requêtes out",

------ Temps de réponse ------
"rtt_in" => "RTT in",
"rtt_out" => "RTT out",
"serv_resp_time_in" => "Tps de réponse serveur in",
"serv_resp_time_out" => "Tps de réponse serveur out",

------ Connexions ------
"con_est_in" => "Connexions établies in",
"con_est_out" => "Connexions établies out", 
"con_fail_rate_in" => "Taux d'échecs con. in",
"con_fail_rate_out" => "Taux d'échecs con. out",
"con_req_in" => "Requêtes de connexion in",
"con_req_out" => "Requêtes de connexion out",
"con_setup_time_in" => "Tps de connexion in",
"con_setup_time_out" => "Tps de connexion out",

------ Sessions actives ------
"tcp_sess_in" => "TCP Sessions in",
"tcp_sess_out" => "TCP Sessions out",
"udp_sess_in" => "UDP Sessions in",
"udp_sess_out" => "UDP Sessions out",
"rtp_sess_in" => "RTP Sessions in",
"rtp_sess_out" => "RTP Sessions out"

------ Qualité ------
"loss_rate_in" => "Taux de perte in",
"loss_rate_out" => "Taux de perte out",
"rst_in" => "Resets TCP in",
"rst_out" => "Resets TCP out",
"ret_time_in" => "Tps de retrans. in",
"ret_time_out" => "Tps de retrans. out",
"tcp_dup_in" => "Paquets dupliqués in",
"tcp_dup_out" => "Paquets dupliqués out",
"tcp_loss_in" => "Paquets perdus in",
"tcp_loss_out" => "Paquets perdus out",

------ RTP ------
"mos_in" => "MOS calculé in",
"mos_out" => "MOS calculé out",
"delay_in" => "RTP Délai inter-paquets in",
"delay_out" => "RTP Délai inter-paquets out",
"jitter_in" => "RTP Gigue in",
"jitter_out" => "RTP Gigue out",
"loss_burst_in" => "RTP Taille des bursts in",
"loss_burst_out" => "RTP Taille des bursts out",
"out_of_seq_in" => "RTP Paquets hors séquence in",
"out_of_seq_out" => "RTP Paquets hors séquence out", 
"rtp_dup_in" => "RTP Paquets dupliqués in",
"rtp_dup_out" => "RTP Paquets dupliqués out",
"rtp_loss_in" => "RTP Paquets perdus in",
"rtp_loss_out" => "RTP Paquets perdus out",

------ VOIP ------
"call_prog_in" => "Appels in",
"call_prog_out" => "Appels out",
"call_est_in" => "Etablissements d'appel in",
"call_est_out" => "Etablissements d'appel out",
"call_req_in" => "Requêtes d'appel in",
"call_req_out" => "Requêtes d'appel out",
"call_end_in" => "Fins d'appel in",
"call_end_out" => "Fins d'appel out",
"call_can_in" => "Annulations d'appel in",
"call_can_out" => "Annulations d'appel out",
"call_rej_in" => "Rejets d'appel in",
"call_rej_out" => "Rejets d'appel out",

*/

require 'WsUser.php';
require 'MyProbeDataService.php';

$UserName= 'administrateur';
$UserPwd= 'h5admin';
$WsServer= '10.205.12.64';
$WsPort= '8080';

$MyWsUser = new WsUser();
$MyWsUser -> setLogin($UserName);
$MyWsUser -> setPassword($UserPwd);
$MyWsUser -> setProbe($WsServer);
$MyWsUser -> setPort($WsPort);

$WSdata= new MyProbeDataService($MyWsUser, "data?wsdl");
$WSdata->setChartFonc("getMetricTimingChart");

// paramètres
$WSdata->setPeriod("LAST_DAY");
$WSdata->setDataType("WO");		
$WSdata->setDataIdentifier("AMON ADMIN");	
$WSdata->setDataMetrics(array("serv_resp_time_in", "rtt_out"));	

// appel des données
$data=$WSdata->getTimingChart();

// envoie des données
echo $data;