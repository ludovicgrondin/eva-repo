// -----------------------------------------------------------------------------
var ALARM_GRAVITY_TOP_SETTINGS = (function() {
	// -------------------------------------------------------------------------
	// Variable
	// -------------------------------------------------------------------------
	var var_private = {};
	var var_public = {};
	// -------------------------------------------------------------------------
	// Private
	// -------------------------------------------------------------------------
	var_private.getCategoryAxis = function() {
		var categoryAxis = new Object();
		categoryAxis.textRotationAngle = 90;
		categoryAxis.dataField = 'Alarm';
		categoryAxis.showTickMarks = true;
		categoryAxis.tickMarksInterval = 1;
		categoryAxis.tickMarksColor = '#888888';
		categoryAxis.unitInterval = 1;
		categoryAxis.flip = false;
		categoryAxis.showGridLines = false;
		categoryAxis.gridLinesInterval = 1;
		categoryAxis.gridLinesColor = '#888888';
		categoryAxis.axisSize = 'auto';
		return categoryAxis;
	};
	// -------------------------------------------------------------------------
	var_private.getSeriesGroups = function(period) {
		valueAxis = new Object();
		valueAxis.unitInterval = 10;
		valueAxis.minValue = 0;
		valueAxis.flip = true;
		valueAxis.maxValue = 100;
		valueAxis.displayValueAxis = true;
		valueAxis.textRotationAngle = 45;
		valueAxis.description = period;
		valueAxis.axisSize = 'auto';
		valueAxis.tickMarksColor = '#888888';

		var series = new Array();

		series.push({
			dataField : 'CRITICAL',
			displayText : TXT_ALARM_LEVEL_CRITICAL,
			color : '#D83737'
		});

		series.push({
			dataField : 'WARNING',
			displayText : TXT_ALARM_LEVEL_WARNING,
			color : '#FFB93C'
		});

		series.push({
			dataField : 'NONE',
			displayText : TXT_ALARM_LEVEL_NONE,
			color : '#B3EB50'
		});

		var seriesGroup = new Object();
		seriesGroup.type = 'stackedcolumn100';
		seriesGroup.orientation = 'horizontal';
		seriesGroup.columnsGapPercent = 100;
		seriesGroup.seriesGapPercent = 5;
		seriesGroup.useGradient = false;
		seriesGroup.valueAxis = valueAxis;
		seriesGroup.series = series;
		seriesGroup.formatSettings = {
			decimalPlaces : 2,
			sufix : '%'
		};

		var seriesGroups = new Array();
		seriesGroups.push(seriesGroup);

		return seriesGroups;
	};
	// -------------------------------------------------------------------------
	// Public
	// -------------------------------------------------------------------------
	var_public.getSettings = function(dataJSON) {
		// ---------------------------------------------------------------------
		var period = dataJSON.period;
		var source = dataJSON.source;
		// ---------------------------------------------------------------------
		var categoryAxis = var_private.getCategoryAxis();
		var seriesGroups = var_private.getSeriesGroups(period);
		// ---------------------------------------------------------------------
		var settings = {
			renderEngine : 'SVG',
			colorScheme : 'h5',

			title : '',
			description : '',

			enableAnimations : CHART_ENABLE_ANIMATIONS,
			showBorderLine : false,
			showLegend : false,

			enableCrosshairs : true,
			showToolTips : true,

			padding : {
				left : 0,
				top : 15,
				bottom : 0,
				right : 15
			},

			source : source,
			categoryAxis : categoryAxis,
			seriesGroups : seriesGroups
		};
		// ---------------------------------------------------------------------
		return settings;
	};
	// -------------------------------------------------------------------------
	return var_public;
	// -------------------------------------------------------------------------
})();
// -----------------------------------------------------------------------------
