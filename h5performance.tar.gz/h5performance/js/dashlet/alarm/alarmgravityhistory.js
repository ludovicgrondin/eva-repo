// -----------------------------------------------------------------------------
var ALARM_GRAVITY_HISTORY_SETTINGS = (function() {
	// -------------------------------------------------------------------------
	// Variable
	// -------------------------------------------------------------------------
	var var_private = {};
	var var_public = {};
	// -------------------------------------------------------------------------
	// Private
	// -------------------------------------------------------------------------
	var_private.getAxisX = function(period) {
		var axisX = {};

		switch (period) {
		case 'LAST_MONTH':
			axisX.tickMarksInterval = 7;
			axisX.gridLinesInterval = 1;
			axisX.unitInterval = 1;
			break;
		case 'LAST_WEEK':
			axisX.tickMarksInterval = 1;
			axisX.gridLinesInterval = 1;
			axisX.unitInterval = 1;
			break;
		case 'LAST_DAY':
			axisX.tickMarksInterval = 4;
			axisX.gridLinesInterval = 1;
			axisX.unitInterval = 1;
			break;
		default:
			console.error('Unknow period type: ' + period);
		}

		return axisX;
	};
	// -------------------------------------------------------------------------
	var_private.getAxisY = function(period) {
		var axisY = {};

		axisY.minValue = 0;
		axisY.maxValue = 100;
		axisY.unitInterval = 10;

		switch (period) {
		case 'LAST_MONTH':
			axisY.description = TXT_ALARM_PERCENTAGE_OF_DAY;
			break;
		case 'LAST_WEEK':
			axisY.description = TXT_ALARM_PERCENTAGE_OF_DAY;
			break;
		case 'LAST_DAY':
			axisY.description = TXT_ALARM_PERCENTAGE_OF_HOUR;
			break;
		default:
			console.error('Unknow period type: ' + period);
		}

		return axisY;
	};
	// -------------------------------------------------------------------------
	var_private.formatFunction = function(value) {
		if (value.display == 'display') {
			return value.begin;
		} else {
			return '';
		}
	};
	// -------------------------------------------------------------------------
	var_private.toolTipFormatFunction = function(value) {
		return value.begin + ' - ' + value.end;
	};
	// -------------------------------------------------------------------------
	var_private.getCategoryAxis = function(period) {
		var axisX = var_private.getAxisX(period);

		var categoryAxis = new Object();
		categoryAxis.dataField = 'period';
		categoryAxis.type = 'default';
		categoryAxis.showTickMarks = true;
		categoryAxis.valuesOnTicks = false;
		categoryAxis.showGridLines = false;
		categoryAxis.textRotationAngle = 0;
		categoryAxis.axisSize = 'auto';
		categoryAxis.tickMarksInterval = axisX.tickMarksInterval;
		categoryAxis.gridLinesInterval = axisX.gridLinesInterval;
		categoryAxis.unitInterval = axisX.unitInterval;
		categoryAxis.formatFunction = var_private.formatFunction;
		categoryAxis.toolTipFormatFunction = var_private.toolTipFormatFunction;
		return categoryAxis;
	};
	// -------------------------------------------------------------------------
	var_private.getSeriesGroups = function(period) {
		var axisY = var_private.getAxisY(period);

		valueAxis = new Object();
		valueAxis.axisSize = 'auto';
		valueAxis.displayValueAxis = true;
		valueAxis.minValue = axisY.minValue;
		valueAxis.maxValue = axisY.maxValue;
		valueAxis.unitInterval = axisY.unitInterval;
		valueAxis.description = axisY.description;

		var serieCritical = new Object();
		serieCritical.dataField = 'CRITICAL';
		serieCritical.displayText = TXT_ALARM_LEVEL_CRITICAL;
		serieCritical.color = '#D83737';

		var serieWarning = new Object();
		serieWarning.dataField = 'WARNING';
		serieWarning.displayText = TXT_ALARM_LEVEL_WARNING;
		serieWarning.color = '#FFB93C';

		var serieNone = new Object();
		serieNone.dataField = 'NONE';
		serieNone.displayText = TXT_ALARM_LEVEL_NONE;
		serieNone.color = '#B3EB50';

		var series = new Array();
		series.push(serieCritical);
		series.push(serieWarning);
		series.push(serieNone);

		var seriesGroup = new Object();
		seriesGroup.type = 'stackedcolumn100';
		seriesGroup.columnsGapPercent = 100;
		seriesGroup.seriesGapPercent = 5;
		seriesGroup.useGradient = false;
		seriesGroup.valueAxis = valueAxis;
		seriesGroup.series = series;
		seriesGroup.formatSettings = {
			decimalPlaces : 2,
			sufix : '%'
		};

		var seriesGroups = new Array();
		seriesGroups.push(seriesGroup);

		return seriesGroups;
	};
	// -------------------------------------------------------------------------
	// Public
	// -------------------------------------------------------------------------
	var_public.getSettings = function(period, dataJSON) {
		// ---------------------------------------------------------------------
		var categoryAxis = var_private.getCategoryAxis(period);
		var seriesGroups = var_private.getSeriesGroups(period);
		// ---------------------------------------------------------------------
		var settings = {
			renderEngine : 'SVG',
			colorScheme : 'h5',

			title : '',
			description : '',

			enableAnimations : CHART_ENABLE_ANIMATIONS,
			showBorderLine : false,
			showLegend : true,

			padding : {
				left : 0,
				top : 15,
				bottom : 0,
				right : 15
			},

			source : dataJSON,
			categoryAxis : categoryAxis,
			seriesGroups : seriesGroups
		};
		// ---------------------------------------------------------------------
		return settings;
	};
	// -------------------------------------------------------------------------
	return var_public;
	// -------------------------------------------------------------------------
})();
// -----------------------------------------------------------------------------
