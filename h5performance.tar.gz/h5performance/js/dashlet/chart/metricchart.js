// -----------------------------------------------------------------------------
var METRIC_CHART_SETTINGS = (function() {
	// -------------------------------------------------------------------------
	// Variable
	// -------------------------------------------------------------------------
	var var_private = {};
	var var_public = {};
	// -------------------------------------------------------------------------
	// Private
	// -------------------------------------------------------------------------
	var_private.getPadding = function(contentWidth, contentHeight) {
		var padding = new Object();
		padding.left = 15;
		padding.top = 15;
		padding.right = 30;
		padding.bottom = 40;
		return padding;
	};
	// -------------------------------------------------------------------------
	var_private.getLegendLayout = function(contentWidth, contentHeight) {
		var legendLayout = new Object();
		legendLayout.left = 15;
		legendLayout.top = contentHeight - 40;
		legendLayout.width = contentWidth - (15 + 30);
		legendLayout.height = 40;
		legendLayout.flow = 'horizontal';
		return legendLayout;
	};
	// -------------------------------------------------------------------------
	var_private.getCategoryAxis = function(period, language) {
		var axisX = CHART_UTILITY.getMetricAxisX(period);

		var categoryAxis = new Object();
		categoryAxis.dataField = 'date';
		categoryAxis.type = 'default';
		categoryAxis.baseUnit = 'millisecond';
		categoryAxis.showTickMarks = true;
		categoryAxis.valuesOnTicks = true;
		categoryAxis.showGridLines = true;
		categoryAxis.axisSize = 'auto';
		categoryAxis.unitInterval = axisX.unitInterval;
		categoryAxis.gridLinesInterval = axisX.gridLinesInterval;
		categoryAxis.formatFunction = function(seconds) {
			return CHART_UTILITY.getDateX(seconds, period, language);
		};

		return categoryAxis;
	};
	// -------------------------------------------------------------------------
	var_private.toolTipFormatFunction = function(value, itemIndex, serie,
			group, categoryValue, categoryAxis) {
		var seconds = categoryValue;
		var metricType = serie.metrictype;
		var language = serie.language;

		var valueDate = CHART_UTILITY.getDate(seconds, language);
		var valueMetric = CHART_UTILITY.getValueByMetricType(metricType, value);

		return valueMetric + ' - ' + valueDate;
	};
	// -------------------------------------------------------------------------
	var_private.getSeriesGroups = function(chartData) {
		var seriesGroups = new Array();

		for (var serieIndex = 0; serieIndex < chartData.series.length; serieIndex++) {
			var serie = chartData.series[serieIndex];
			serie.toolTipFormatFunction = var_private.toolTipFormatFunction;

			var metric = serie.metrictype;
			var minimum = serie.minimum;
			var maximum = serie.maximum;
			var description = serie.metriclabel;

			var axisY = CHART_UTILITY.getAxisY(minimum, maximum);

			var seriesGroup = null;

			for (var seriesGroupsIndex = 0; seriesGroupsIndex < seriesGroups.length; seriesGroupsIndex++) {
				var serieGroupMetricType = seriesGroups[seriesGroupsIndex].metrictype;

				if (serieGroupMetricType == metric) {
					seriesGroup = seriesGroups[seriesGroupsIndex];
					break;
				}
			}

			if (seriesGroup == null) {
				var series = new Array();
				series.push(serie);

				var position = (serieIndex == 0 ? 'left' : 'right');

				var valueAxis = new Object();
				valueAxis.axisSize = 'auto';
				valueAxis.displayValueAxis = true;
				valueAxis.minValue = axisY.minValue;
				valueAxis.maxValue = axisY.maxValue;
				valueAxis.unitInterval = axisY.unitInterval;
				valueAxis.description = description;
				valueAxis.position = position;
				valueAxis.metricType = serie.metrictype;
				valueAxis.formatFunction = function(value) {
					return CHART_UTILITY.getValueByMetricType(this.metricType,
							value);
				};

				seriesGroup = new Object();
				seriesGroup.metrictype = serie.metrictype;
				seriesGroup.useGradient = false;
				seriesGroup.type = 'line';
				seriesGroup.valueAxis = valueAxis;
				seriesGroup.series = series;

				seriesGroups.push(seriesGroup);
			} else {
				if (axisY.unitInterval > seriesGroup.valueAxis.unitInterval) {
					seriesGroup.valueAxis.minValue = axisY.minValue;
					seriesGroup.valueAxis.maxValue = axisY.maxValue;
					seriesGroup.valueAxis.unitInterval = axisY.unitInterval;
				}

				seriesGroup.valueAxis.description = seriesGroup.valueAxis.description
						+ ' / ' + description;

				seriesGroup.series.push(serie);
			}
		}

		return seriesGroups;
	};
	// -------------------------------------------------------------------------
	// Public
	// -------------------------------------------------------------------------
	var_public.getSettings = function(contentWidth, contentHeight, period,
			chartData, language) {
		// ---------------------------------------------------------------------
		var padding = var_private.getPadding(contentWidth, contentHeight);
		var legendLayout = var_private.getLegendLayout(contentWidth,
				contentHeight);

		var source = chartData.source;

		var categoryAxis = var_private.getCategoryAxis(period, language);
		var seriesGroups = var_private.getSeriesGroups(chartData);
		// ---------------------------------------------------------------------
		var settings = {
			renderEngine : 'SVG',
			colorScheme : 'h5',

			title : '',
			description : '',

			enableAnimations : CHART_ENABLE_ANIMATIONS,
			showBorderLine : false,
			showLegend : true,

			padding : padding,
			legendLayout : legendLayout,

			source : source,
			categoryAxis : categoryAxis,
			seriesGroups : seriesGroups
		};
		// ---------------------------------------------------------------------
		return settings;
	};
	// -------------------------------------------------------------------------
	return var_public;
})();
// -----------------------------------------------------------------------------
