// -----------------------------------------------------------------------------
var TOP_PIE_CHART_SETTINGS = (function() {
	// -------------------------------------------------------------------------
	// Variable
	// -------------------------------------------------------------------------
	var var_private = {};
	var var_public = {};
	// -------------------------------------------------------------------------
	// Private
	// -------------------------------------------------------------------------
	var_private.getPadding = function(contentWidth, contentHeight) {
		var padding = new Object();
		padding.left = 15 + 150;
		padding.top = 5;
		padding.right = 15;
		padding.bottom = 5;
		return padding;
	};
	// -------------------------------------------------------------------------
	var_private.getLegendLayout = function(contentWidth, contentHeight) {
		var legendLayout = new Object();
		legendLayout.left = 15;
		legendLayout.top = 5;
		legendLayout.width = 150;
		legendLayout.height = contentHeight - 5;
		legendLayout.flow = 'vertical';
		return legendLayout;
	};
	// -------------------------------------------------------------------------
	var_private.getLabelRadius = function(contentWidth, contentHeight) {
		return ((contentHeight - 15) / 2);
	};
	// -------------------------------------------------------------------------
	var_private.getRadius = function(contentWidth, contentHeight) {
		return ((contentHeight - 30 - 25) / 2);
	};
	// -------------------------------------------------------------------------
	var_private.getSource = function(chartData) {
		var source = new Array();
		var data = chartData.data;

		for (var dataIndex = 0; dataIndex < data.length; dataIndex++) {
			var currentData = data[dataIndex];

			var entry = new Object();
			entry.description = currentData.description + '\0';
			entry.value = currentData.value;
			entry.percent = currentData.percent;

			source.push(entry);
		}

		return source;
	};
	// -------------------------------------------------------------------------
	var_private.getSeriesGroups = function(contentWidth, contentHeight,
			metrictype, sum) {
		var labelRadius = var_private.getLabelRadius(contentWidth,
				contentHeight);
		var radius = var_private.getRadius(contentWidth, contentHeight);

		var serie = new Object();
		serie.dataField = 'value';
		serie.displayText = 'description';
		serie.initialAngle = 0;
		serie.centerOffset = 0;
		serie.radius = radius;
		serie.labelRadius = labelRadius;

		serie.formatFunction = function(value) {
			if (isNaN(value)) {
				return value;
			}

			var valueByMetricType = CHART_UTILITY.getValueByMetricType(
					metrictype, value);
			var percent = ((value / sum) * 100).toFixed(2) + '%';

			return valueByMetricType + ' / ' + percent;
		};

		var series = new Array();
		series.push(serie);

		var seriesGroup = new Object();
		seriesGroup.type = 'pie';
		seriesGroup.useGradient = false;
		seriesGroup.showLabels = true;
		seriesGroup.series = series;

		var seriesGroups = new Array();
		seriesGroups.push(seriesGroup);

		return seriesGroups;
	};
	// -------------------------------------------------------------------------
	// Public
	// -------------------------------------------------------------------------
	var_public.getSettings = function(contentWidth, contentHeight, period,
			chartData, language) {
		// ---------------------------------------------------------------------
		var padding = var_private.getPadding(contentWidth, contentHeight);
		var legendLayout = var_private.getLegendLayout(contentWidth,
				contentHeight);

		var source = var_private.getSource(chartData);

		var metrictype = chartData.metrictype;
		var sum = chartData.sum;

		var seriesGroups = var_private.getSeriesGroups(contentWidth,
				contentHeight, metrictype, sum);
		// ---------------------------------------------------------------------
		var settings = {
			renderEngine : 'SVG',
			colorScheme : 'h5',

			title : '',
			description : '',

			enableAnimations : CHART_ENABLE_ANIMATIONS,
			showBorderLine : false,
			showLegend : true,

			padding : padding,
			legendLayout : legendLayout,

			source : source,
			seriesGroups : seriesGroups
		};

		return settings;
	};
	// -------------------------------------------------------------------------
	return var_public;
	// -------------------------------------------------------------------------
})();
// -----------------------------------------------------------------------------
