// -----------------------------------------------------------------------------
var CHART_UTILITY = (function() {
	// -------------------------------------------------------------------------
	// Variable
	// -------------------------------------------------------------------------
	var var_private = {};
	var var_public = {};
	// -------------------------------------------------------------------------
	// Private
	// -------------------------------------------------------------------------
	var_private.getTimeString = function(date, language) {
		var hoursValue = date.getHours();
		var minutesValue = date.getMinutes();

		var formatString;

		if (language == 'en_EN') {
			if (hoursValue < 12) {
				formatString = ' AM';

				if (hoursValue == 0) {
					hoursValue = 12;
				}
			} else {
				formatString = ' PM';

				if (hoursValue != 12) {
					hoursValue = hoursValue % 12;
				}
			}
		} else {
			formatString = '';
		}

		var hoursString;

		if (language == 'en_EN') {
			hoursString = hoursValue.toString();
			minutesString = minutesValue.toString();
		} else {
			if (hoursValue < 10) {
				hoursString = '0' + hoursValue.toString();
			} else {
				hoursString = hoursValue.toString();
			}
		}

		var minutesString;

		if (minutesValue < 10) {
			minutesString = '0' + minutesValue.toString();
		} else {
			minutesString = minutesValue.toString();
		}

		return hoursString + ':' + minutesString + formatString;
	};
	// -------------------------------------------------------------------------
	var_private.getDateString = function(date) {
		var dateValue = date.getDate();
		var dateString;

		if (dateValue < 10) {
			dateString = '0' + dateValue.toString();
		} else {
			dateString = dateValue.toString();
		}

		var monthValue = date.getMonth() + 1;
		var monthString;

		if (monthValue < 10) {
			monthString = '0' + monthValue.toString();
		} else {
			monthString = monthValue.toString();
		}

		return dateString + '/' + monthString + '/' + date.getFullYear();
	};
	// -------------------------------------------------------------------------
	// Values by metric type
	// -------------------------------------------------------------------------
	var_private.getPrefixValue = function(prefix) {
		switch (prefix) {
		case 'unit':
			return 1;
		case 'kilo':
			return 1000;
		case 'mega':
			return 1000000;
		case 'giga':
			return 1000000000;
		case 'tera':
			return 1000000000000;
		default:
			console.error('Unknow prefix type: ' + prefix);
		}
	};
	// -------------------------------------------------------------------------
	var_private.getPrefixValue1024 = function(prefix) {
		switch (prefix) {
		case 'unit':
			return 1;
		case 'kilo':
			return 1024; // Math.pow(2, 10)
		case 'mega':
			return 1048576; // Math.pow(2, 20)
		case 'giga':
			return 1073741824; // Math.pow(2, 30)
		case 'tera':
			return 1099511627776; // Math.pow(2, 40)
		default:
			console.error('Unknow prefix type: ' + prefix);
		}
	};
	// -------------------------------------------------------------------------
	var_private.getQuantity = function(value) {
		return value;
	};
	// -------------------------------------------------------------------------
	var_private.getPercentage = function(value) {
		return value + ' %';
	};
	// -------------------------------------------------------------------------
	var_private.getPacketRate = function(value) {
		return value + ' pps';
	};
	// -------------------------------------------------------------------------
	var_private.getTime = function(value) {
		if (value < 1000) {
			return value.toFixed(2) + ' ms';
		} else {
			return (value / 1000).toFixed(2) + ' s';
		}
	};
	// -------------------------------------------------------------------------
	var_private.getBitRateInBitPerSecond = function(value) {
		if (value < var_private.getPrefixValue('kilo')) {
			return (value).toFixed(2) + ' ' + 'bit/s';
		} else if (value < var_private.getPrefixValue('mega')) {
			return (value / var_private.getPrefixValue('kilo')).toFixed(2)
					+ ' ' + 'Kbit/s';
		} else if (value < var_private.getPrefixValue('giga')) {
			return (value / var_private.getPrefixValue('mega')).toFixed(2)
					+ ' ' + 'Mbit/s';
		} else if (value < var_private.getPrefixValue('tera')) {
			return (value / var_private.getPrefixValue('giga')).toFixed(2)
					+ ' ' + 'Gbit/s';
		} else {
			return (value / var_private.getPrefixValue('tera')).toFixed(2)
					+ ' ' + 'Tbit/s';
		}
	};
	// -------------------------------------------------------------------------
	var_private.getVolumeInByte1024 = function(value) {
		if (value < var_private.getPrefixValue1024('kilo')) {
			return (value).toFixed(2) + ' ' + 'o';
		} else if (value < var_private.getPrefixValue1024('mega')) {
			return (value / var_private.getPrefixValue1024('kilo')).toFixed(2)
					+ ' ' + 'Ko';
		} else if (value < var_private.getPrefixValue1024('giga')) {
			return (value / var_private.getPrefixValue1024('mega')).toFixed(2)
					+ ' ' + 'Mo';
		} else if (value < var_private.getPrefixValue1024('tera')) {
			return (value / var_private.getPrefixValue1024('giga')).toFixed(2)
					+ ' ' + 'Go';
		} else {
			return (value / var_private.getPrefixValue1024('tera')).toFixed(2)
					+ ' ' + 'To';
		}
	};
	// -------------------------------------------------------------------------
	// Public
	// -------------------------------------------------------------------------
	var_public.getValueByMetricType = function(metricType, value) {
		switch (metricType) {
		case 'QUANTITY':
			return var_private.getQuantity(value);
		case 'PERCENTAGE':
			return var_private.getPercentage(value);
		case 'PACKETRATE':
			return var_private.getPacketRate(value);
		case 'TIME':
			return var_private.getTime(value);
		case 'BITRATE':
			return var_private.getBitRateInBitPerSecond(value);
		case 'VOLUME':
			return var_private.getVolumeInByte1024(value);
		default:
			console.error('Unknow metric type: ' + metricType);
		}
	};
	// -------------------------------------------------------------------------
	var_public.getDate = function(seconds, language) {
		var date = new Date(seconds * 1000);
		var timeString = var_private.getTimeString(date, language);
		var dateString = var_private.getDateString(date);
		return timeString + ' - ' + dateString;
	};
	// -------------------------------------------------------------------------
	var_public.getDateX = function(seconds, period, language) {
		var date = new Date(seconds * 1000);

		switch (period) {
		case 'LAST_MONTH':
			return var_private.getDateString(date);
		case 'LAST_WEEK':
			return var_private.getDateString(date);
		case 'LAST_DAY':
			return var_private.getTimeString(date, language);
		default:
			console.error('Unknow period type: ' + period);
		}
	};
	// -------------------------------------------------------------------------
	var_public.getAxisX = function(period) {
		var axisX = new Object();

		switch (period) {
		case 'LAST_MONTH': // granularity day
			axisX.unitInterval = 7;
			axisX.gridLinesInterval = 7;
			break;
		case 'LAST_WEEK': // granularity hour
			axisX.unitInterval = 24;
			axisX.gridLinesInterval = 48;
			break;
		// case 'LAST_DAY': // granularity hour
		// axisX.unitInterval = 6;
		// axisX.gridLinesInterval = 12;
		// break;
		case 'LAST_DAY': // granularity five minutes
			axisX.unitInterval = 24;
			axisX.gridLinesInterval = 48;
			break;
		default:
			console.error('Unknow period type: ' + period);
		}

		return axisX;
	};
	// -------------------------------------------------------------------------
	var_public.getMetricAxisX = function(period) {
		var axisX = new Object();

		switch (period) {
		case 'LAST_MONTH': // granularity day
			axisX.unitInterval = 7;
			axisX.gridLinesInterval = 7;
			break;
		case 'LAST_WEEK': // granularity hour
			axisX.unitInterval = 24;
			axisX.gridLinesInterval = 48;
			break;
		// case 'LAST_DAY': // granularity hour
		// axisX.unitInterval = 6;
		// axisX.gridLinesInterval = 12;
		// break;
		case 'LAST_DAY': // granularity five minutes
			axisX.unitInterval = 24;
			axisX.gridLinesInterval = 48;
			break;
		default:
			console.error('Unknow period type: ' + period);
		}

		return axisX;
	};
	// -------------------------------------------------------------------------
	var_public.getAxisY = function(minimum, maximum) {
		var axisY = new Object();

		if (maximum == 0) {
			axisY.minValue = -1;
			axisY.maxValue = 1;
			axisY.unitInterval = 1;
		} else {
			var quotient = maximum / 4;
			var ceil = Math.ceil(quotient);

			axisY.minValue = 0;
			axisY.maxValue = ceil * 4;
			axisY.unitInterval = ceil;
		}

		return axisY;
	};
	// -------------------------------------------------------------------------
	return var_public;
	// -------------------------------------------------------------------------
})();
// -----------------------------------------------------------------------------
