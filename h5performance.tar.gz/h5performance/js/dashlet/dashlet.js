// -------------------------------------------------------------------------
// Encapsulate functions related to a Dashlet in their own module
// -------------------------------------------------------------------------
// Module pattern:
// var <DASHLET_TYPE> = (function () {
//  var var_public = {};
//
//  var_public.<function_name> = function () {...};
//
//  return var_public;
// })();
// -------------------------------------------------------------------------