$(document).ready(function () {
    $.jqx._jqxChart.prototype.addColorScheme('h5', ['#B3EB50','#D83737','#FFB92C','#1D3161','#5A80AD','#307DD7','#AA4643','#89A54E','#71588F','#4198AF']);
});