<?php
require 'MySecureService.php';

class MyProbeDataService extends MySecureService {
	/**
	 * \file	MyProbeDataService.php
	 * \version	1.0
	 * \date	16 Juin 2015
	 * \brief	Définit un objet permetant la récupération de donnée sur un Wenb service avec authentification.
	 *
	 * \details    Cette classe hérite de MySecureService pour gérer l'authentification et génére elle même les requetes
	 *                  puis traite la réponse pour sortir les resultat sous fiférentes formes.
	 */

	private $ChartFonc= null;
	private $request= null;	
	private $dataIdentifier= null;
	private $dataMetrics= null;
	private $period= null;
	private $filter= null;
	private $ip= null;
	private $ipOrWo= null;
	private $metric= null;
	private $protocol= null;
	private $size= null;
	private $tcpPort= null;
	private $udpPort= null;
	private $vlan= null;
	private $wo= null;
	private $objects= null;
	private $type= null;
	private $topFilter= null;
	private $begin= null;
	private $end= null;
	private $granularityType= null;
	private $ip1= null;
	private $ip1Descr= null;
	private $ip2= null;
	private $ip2Descr= null;
	private $ipContainer= null;
	private $ipContainerDescr= null;
	private $limit= null;
	private $orderRow= null;
	private $orderedConv= null;
	private $p2= null;
	private $p2Descr= null;
	private $p4= null;
	private $p4Descr= null;
	private $p7= null;
	private $p7Descr= null;
	private $p7Type= null;
	private $ip1Type= null;
	private $ip2Type= null;
	private $ipContainerType= null;
	private $sipId1= null;
	private $sipId1Descr= null;
	private $sipId2= null;
	private $sipId2Descr= null;
	private $regex= null;
	private $vlanDescr= null;
	private $resultType= null;
	private $Netbios= null;

	public function __construct(WsUser $wsUser, $wsdl, $options = null) {
		parent::__construct($wsUser, $wsdl, $options);
	}

	public function setRequest() {
		/**
		 * \brief    Génére la requette à executer sur le Web service.
		 * \details  La requette est générer en fonction des valeur paramétrer à l'aide des setter .
		 * \return   Un \e string  représenntant la requette a executer via le client soap.
		 */
		$Request = "";
		if ($this->ChartFonc == "getProbeFilteredTopPieChart") {

				$Request = "<tns:getProbeFilteredTopPieChart  xmlns:tns=\"http://services.h5300report.h5audits.com\"><parameters><filter>".$this->filter."</filter><filteredTopType>".$this->type."</filteredTopType><ip>".$this->ip."</ip><ipOrWo>".$this->ipOrWo."</ipOrWo><metric>".$this->metric."</metric><period>".$this->period."</period><protocol>".$this->protocol."</protocol><size>".$this->size."</size><tcpPort>".$this->tcpPort."</tcpPort><udpPort>".$this->udpPort."</udpPort><vlan>".$this->vlan."</vlan><wo>".$this->wo."</wo></parameters></tns:getProbeFilteredTopPieChart>";

		} elseif ($this->ChartFonc == "getFilteredTopProbeQueryParameters") {

				$Request = "<tns:getFilteredTopProbeQueryParameters  xmlns:tns=\"http://services.h5300report.h5audits.com\"><parameters><filter>".$this->filter."</filter><filteredTopType>".$this->type."</filteredTopType><ip>".$this->ip."</ip><ipOrWo>".$this->ipOrWo."</ipOrWo><metric>".$this->metric."</metric><period>".$this->period."</period><protocol>".$this->protocol."</protocol><size>".$this->size."</size><tcpPort>".$this->tcpPort."</tcpPort><udpPort>".$this->udpPort."</udpPort><vlan>".$this->vlan."</vlan><wo>".$this->wo."</wo></parameters></tns:getFilteredTopProbeQueryParameters>";

		} elseif ($this->ChartFonc == "getProbeFilteredTopTimingChart") {

				$Request = "<tns:getProbeFilteredTopTimingChart  xmlns:tns=\"http://services.h5300report.h5audits.com\"><parameters><filter>".$this->filter."</filter><filteredTopType>".$this->type."</filteredTopType><ip>".$this->ip."</ip><ipOrWo>".$this->ipOrWo."</ipOrWo><metric>".$this->metric."</metric><period>".$this->period."</period><protocol>".$this->protocol."</protocol><size>".$this->size."</size><tcpPort>".$this->tcpPort."</tcpPort><udpPort>".$this->udpPort."</udpPort><vlan>".$this->vlan."</vlan><wo>".$this->wo."</wo></parameters></tns:getProbeFilteredTopTimingChart>";

		} elseif ($this->ChartFonc == "getMetricPieChart") {

				$Request = "<tns:getMetricPieChart  xmlns:tns=\"http://services.h5300report.h5audits.com\"><parameters><dataIdentifier>".$this->dataIdentifier."</dataIdentifier>";
				foreach($this->dataMetrics as $key => $Metrics){
					$Request = $Request."<dataMetrics>$Metrics</dataMetrics>";
				}
				$Request = $Request."<dataType>".$this->type."</dataType><period>".$this->period."</period></parameters></tns:getMetricPieChart>";

		}elseif ($this->ChartFonc == "getMetricProbeQueryParameters") {

				$Request = "<tns:getMetricProbeQueryParameters  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<dataIdentifier>".$this->dataIdentifier."</dataIdentifier>";
				foreach($this->dataMetrics as $key => $Metrics){
					$Request = $Request."<dataMetrics>$Metrics</dataMetrics>";
				}
				$Request = $Request."<dataType>".$this->type."</dataType><period>".$this->period."</period></parameters></tns:getMetricProbeQueryParameters>";

		}elseif ($this->ChartFonc == "getProbeMetricTimingChart") {

				$Request = "\n<tns:getProbeMetricTimingChart  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<dataIdentifier>".$this->dataIdentifier."</dataIdentifier>\n\t\t";
				foreach($this->dataMetrics as $key => $Metrics){
					$Request = $Request."<dataMetrics>$Metrics</dataMetrics>\n\t\t";
				}
				$Request = $Request."<dataType>".$this->type."</dataType>\n\t\t<period>".$this->period."</period>\n\t</parameters>\n</tns:getProbeMetricTimingChart>\n";

		} elseif ($this->ChartFonc == "getObjectPieChart") {

				$Request = "<tns:getObjectPieChart  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<metric>".$this->metric."</metric>";
					foreach($this->objects as $key => $Object){
						$Request = $Request."<objects>".$Object."</objects>";
					}
			$Request = $Request."<period>".$this->period."</period><type>".$this->type."</type></parameters></tns:getObjectPieChart>";
		} elseif ($this->ChartFonc == "getObjectProbeQueryParameters") {

				$Request = "<tns:getObjectProbeQueryParameters  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<metric>".$this->metric."</metric><objects>".$this->objects."</objects><period>".$this->period."</period><type>".$this->type."</type></parameters></tns:getObjectProbeQueryParameters>";


		} elseif ($this->ChartFonc == "getObjectTimingChart") {

			$Request = "<tns:getObjectTimingChart  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<metric>".$this->metric."</metric>";
				foreach($this->objects as $key => $Object){
					$Request = $Request."<objects>".$Object."</objects>";
				}
			$Request = $Request."<period>".$this->period."</period><type>".$this->type."</type></parameters></tns:getObjectTimingChart>";


		} elseif ($this->ChartFonc == "getPieChart") {

			$Request = "<tns:getPieChart  xmlns:tns=\"http://services.h5300report.h5audits.com\"><parameters><begin>".$this->begin."</begin><end>".$this->end."</end><granularityType>".$this->granularityType."</granularityType><ip1>".$this->ip1."</ip1><ip1Descr>".$this->ip1Descr."</ip1Descr><ip2>".$this->ip2."</ip2><ip2Descr>".$this->ip2Descr."</ip2Descr><ipContainer>".$this->ipContainer."</ipContainer><ipContainerDescr>".$this->ipContainerDescr."</ipContainerDescr><limit>".$this->limit."</limit><orderRow>".$this->orderRow."</orderRow><orderedConv>".$this->orderedConv."</orderedConv><p2>".$this->p2."</p2><p2Descr>".$this->p2Descr."</p2Descr><p4>".$this->p4."</p4><p4Descr>".$this->p4Descr."</p4Descr><p7>".$this->p7."</p7><p7Descr>".$this->p7Descr."</p7Descr><p7Type>".$this->p7Type."</p7Type><regex>".$this->regex."</regex><vlan>".$this->vlan."</vlan><vlanDescr>".$this->vlanDescr."</vlanDescr><ip1Type>".$this->ip1Type."</ip1Type><ip2Type>".$this->ip2Type."</ip2Type><ipContainerType>".$this->ipContainerType."</ipContainerType><resultType>".$this->resultType."</resultType><sipId1>".$this->sipId1."</sipId1><sipId1Descr>".$this->sipId1Descr."</sipId1Descr><sipId2>".$this->sipId2."</sipId2><sipId2Descr>".$this->sipId2Descr."</sipId2Descr></parameters></tns:getObjectTimingChart>";

		} elseif ($this->ChartFonc == "getTimingChart") {

			$Request = "<tns:getPieChart  xmlns:tns=\"http://services.h5300report.h5audits.com\"><parameters><begin>".$this->begin."</begin><end>".$this->end."</end><granularityType>".$this->granularityType."</granularityType><ip1>".$this->ip1."</ip1><ip1Descr>".$this->ip1Descr."</ip1Descr><ip2>".$this->ip2."</ip2><ip2Descr>".$this->ip2Descr."</ip2Descr><ipContainer>".$this->ipContainer."</ipContainer><ipContainerDescr>".$this->ipContainerDescr."</ipContainerDescr><limit>".$this->limit."</limit><orderRow>".$this->orderRow."</orderRow><orderedConv>".$this->orderedConv."</orderedConv><p2>".$this->p2."</p2><p2Descr>".$this->p2Descr."</p2Descr><p4>".$this->p4."</p4><p4Descr>".$this->p4Descr."</p4Descr><p7>".$this->p7."</p7><p7Descr>".$this->p7Descr."</p7Descr><p7Type>".$this->p7Type."</p7Type><regex>".$this->regex."</regex><vlan>".$this->vlan."</vlan><vlanDescr>".$this->vlanDescr."</vlanDescr><ip1Type>".$this->ip1Type."</ip1Type><ip2Type>".$this->ip2Type."</ip2Type><ipContainerType>".$this->ipContainerType."</ipContainerType><resultType>".$this->resultType."</resultType><sipId1>".$this->sipId1."</sipId1><sipId1Descr>".$this->sipId1Descr."</sipId1Descr><sipId2>".$this->sipId2."</sipId2><sipId2Descr>".$this->sipId2Descr."</sipId2Descr></parameters></tns:getObjectTimingChart>";

		} elseif ($this->ChartFonc == "getTopPieChart") {

			$Request = "<tns:getTopPieChart  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<period>".$this->period."</period><topFilter>".$this->topFilter."</topFilter><topMetric>".$this->metric."</topMetric><topSize>".$this->size."</topSize><topType>".$this->type."</topType></parameters></tns:getTopPieChart>";


		} elseif ($this->ChartFonc == "getTopProbeQueryParameters") {

			$Request = "<tns:getTopProbeQueryParameters  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<period>".$this->period."</period><topFilter>".$this->topFilter."</topFilter><topMetric>".$this->metric."</topMetric><topSize>".$this->size."</topSize><topType>".$this->type."</topType></parameters></tns:getTopProbeQueryParameters>";

		} elseif ($this->ChartFonc == "getTopTimingChart") {

			$Request = "<tns:getTopTimingChart  xmlns:tns=\"http://services.h5300report.h5audits.com\">\n\t<parameters>\n\t\t<period>".$this->period."</period><topFilter>".$this->topFilter."</topFilter><topMetric>".$this->metric."</topMetric><topSize>".$this->size."</topSize><topType>".$this->type."</topType></parameters></tns:getTopTimingChart>";

		}
		$this->request=$Request;
		return $Request;
	}

/*	public function getRequest() {
		return $this->request;
	}*/

	public function getChart() {
		/**
		 * \brief    Récupérer le résultat de la requette préalablement paramétrer.
		 * \return   Un \e array étant la traduction de la réponse du Web Service .
		 */

		$this->setRequest();
		$soapBody = new \SoapVar($this->request, \XSD_ANYXML);
		$result = parent::__call($this->ChartFonc, array( $soapBody));
		$result=json_decode(json_encode($result), true);

		return $result;
	}

	public function getTimingChart() {
		/**
		METRIC_CHART_SETTINGS
		 * \brief    Récupérer le résultat de la requette préalablement paramétrer.
		 * \return   Un \e string étant la traduction de la réponse du Web Service. (Pour une utilisation avec javascript pour un graphe série)
		 */
		$this->setRequest();
		$soapBody = new \SoapVar($this->request, \XSD_ANYXML);
		$result = parent::__call($this->ChartFonc, array( $soapBody));
		$result=json_decode(json_encode($result), true);
		//var_dump($result);
		$flag=0;
		$end="],series:[";
		foreach ($result["timingEntries"] as $metric => $tab){
			//var_dump($tab);
			$end=$end."{dataField:'serie$flag',displayText:'".$tab["description"]." ".$this->getLabelFr($tab["metric"])."',metriclabel:'".$this->getLabelFr($tab["metric"])."',metrictype:'".$this->getMetricType($tab["metric"])."',},";
			foreach($tab["timingPoints"] as $key => $val){
				$date = new DateTime($val["date"]);
				$data[$tab["metric"]][$date->getTimestamp()]=$val["value"];
				$tmp[$date->getTimestamp()]= "{date:".$date->getTimestamp();
			}
			$flag=$flag +1;
		}

		$chartData = "{source:[";
		
		$flag=0;
		foreach ($data as $metric){
			foreach ($metric as $time => $val){
				$tmp[$time]= $tmp[$time].",serie$flag:".$val;
			}
			$flag = $flag + 1;
		}

		foreach ($tmp as $time => $val){
			$chartData= $chartData.$val.",},";
		}

		return $chartData.$end."],}";
	}
		public function getTimingChart2() {
		/**
		METRIC_CHART_SETTINGS
		 * \brief    Récupérer le résultat de la requette préalablement paramétrer.
		 * \return   Un \e string étant la traduction de la réponse du Web Service. (Pour une utilisation avec javascript pour un graphe série)
		 */
		$this->setRequest();
		$soapBody = new \SoapVar($this->request, \XSD_ANYXML);
		$result = parent::__call($this->ChartFonc, array( $soapBody));
		$result=json_decode(json_encode($result), true);
		//var_dump($result);
		$flag=0;
		$end="],series:[";
		foreach ($result["timingEntries"] as $metric => $tab){
			$end=$end."{dataField:'serie$flag',displayText:'".$tab["description"]." ".$this->getLabelFr($tab["metric"])."',metriclabel:'".$this->getLabelFr($tab["metric"])."',metrictype:'".$this->getMetricType($tab["metric"])."',},";
			foreach($tab["timingPoints"] as $key => $val){
				$date = new DateTime($val["date"]);
				$data[$tab["metric"]][$date->getTimestamp()]=$val["value"];
				$tmp[$date->getTimestamp()]= "{date:".$date->getTimestamp();
			}
			$flag=$flag +1;
		}

		$chartData = "{source:[";

		$flag=0;
		foreach ($data as $metric){
			foreach ($metric as $time => $val){
				$tmp[$time]= $tmp[$time].",serie$flag:".$val;
			}
			$flag = $flag + 1;
		}

		foreach ($tmp as $time => $val){
			$chartData= $chartData.$val.",},";
		}

		return $chartData.$end."],}";
	}

	public function getTopTimingChart() {
		/**
		TOP_TIMING_CHART_SETTINGS
		 * \brief    Récupérer le résultat de la requette préalablement paramétrer.
		 * \return   Un \e string étant la traduction de la réponse du Web Service. (Pour une utilisation avec javascript pour un graphe de top en série)
		 */
		$this->setRequest();
		$soapBody = new \SoapVar($this->request, \XSD_ANYXML);
		$result = parent::__call($this->ChartFonc, array( $soapBody));
		$result=json_decode(json_encode($result), true);
		//var_dump($result);
		$flag=0;
		$end="],series:[";
		foreach ($result["timingEntries"] as $metric => $tab){
			$end=$end."{dataField:'serie$flag',displayText:'".$tab["description"]."',},";
			foreach($tab["timingPoints"] as $key => $val){
				$date = new DateTime($val["date"]);
				$data[$tab["description"]][$date->getTimestamp()]=$val["value"];
				$tmp[$date->getTimestamp()]= "{date:".$date->getTimestamp();
			}
			$flag=$flag +1;
			$metriclabel = $tab["metric"];
		}
		//,metriclabel:'".$tab["metric"]."',metrictype:'BITRATE
		//],metriclabel:'Volume out',metrictype:'VOLUME',language:'fr_FR',minimum:0,maximum:7218908,};
		$end=$end."],metriclabel:'".$this->getLabelFr($metriclabel)."',metrictype:'".$this->getMetricType($metriclabel)."',language:'fr_FR',minimum:0,maximum:";

		$chartData = "{source:[";

		$flag=0;
		$maximum=0;
		foreach ($data as $description){
			foreach ($description as $time => $val){
				$tmp[$time]= $tmp[$time].",serie$flag:".$val;
				if ($val > $maximum){
					$maximum = $val;
				}
			}
			$flag = $flag + 1;
		}

		foreach ($tmp as $time => $val){
			$chartData= $chartData.$val.",},";
		}

		return $chartData.$end.$maximum.",}";
	}

	public function getPieChart() {
		/**
		TOP_PIE_CHART_SETTINGS
		 * \brief    Récupérer le résultat de la requette préalablement paramétrer.
		 * \return   Un \e string étant la traduction de la réponse du Web Service. (Pour une utilisation avec javascript pour un graphe en camenbert)
		 */
		$this->setRequest();
		$soapBody = new \SoapVar($this->request, \XSD_ANYXML);
		$result = parent::__call($this->ChartFonc, array( $soapBody));
		$result=json_decode(json_encode($result), true);

		$sum=0;
		$chartData = "{data:[";
		foreach ($result["pieEntries"] as $Entries => $tab){
			$chartData=$chartData."{description:'".$tab["description"]."', value:".$tab["value"].", percent:".$tab["percent"].",},";
			$sum=$sum+$tab["value"];
			$metriclabel = $tab["metric"];
		}
		$end= "],metrictype:'".$this->getMetricType($metriclabel)."',sum:'$sum',}";
		return $chartData.$end;
	}


  public function setChartFonc($name) {
		/**
			* \param	$name un \e string représantant le nom de la fonction a executer sur le Web Service.
			* \detail getFilteredTopPieChart, getFilteredTopProbeQueryParameters, getFilteredTopTimingChart, getMetricPieChart, getMetricProbeQueryParameters, getMetricTimingChart, getObjectPieChart, getObjectProbeQueryParameters, getObjectTimingChart, getPieChart, getTimingChart, getTopPieChart, getTopProbeQueryParameters, getTopTimingChart
			* \return	\e l'objet luis même.
			*/

      $this->ChartFonc = $name;
      return $this;
  }
  public function setDataIdentifier($var) {
		/**
			* \param	$var un \e string.
			* \detail peut valoir: TOTAL, IP, WO, BF, HTTP, VLAN
			* \return	\e l'objet luis même.
			*/

      $this->dataIdentifier = $var;
      return $this;
  }
  public function setDataMetrics(array $var) {
		/**
			* \param	$var un \e array de metric pour getMetricTimingChart.
			* \detail peut valoir: bandwidth, bandwidth_in, bandwidth_out, bytes, bytes_in, bytes_out, con_fail_rate_in, con_fail_rate_out, con_req_in, con_req_out, con_setup_time_in, con_setup_time_out, delay_in, delay_out, con_est_in, con_est_out, jitter_in, jitter_out, loss_burst_in, loss_burst_out, loss_rate_in, loss_rate_out, mos_in, mos_out, out_of_seq_in, out_of_seq_out, pkts_in , pkts_out, payload_in, payload_out, rst_in, rst_out, ret_time_in, ret_time_out, rtp_dup_in, rtp_dup_out, rtp_loss_in, rtp_loss_out, rtt_in, rtt_out, serv_resp_time_in, serv_resp_time_out, tcp_dup_in, tcp_dup_out, tcp_loss_in, tcp_loss_out, throughput_in, throughput_out, turn_in, turn_out, call_prog_in, call_prog_out, call_est_in, call_est_out, call_req_in, call_req_out, call_end_in, call_end_out, call_can_in, call_can_out, call_rej_in, call_rej_out, tcp_sess_in, tcp_sess_out, udp_sess_in, udp_sess_out, rtp_sess_in, rtp_sess_out
			* \return	\e l'objet luis même.
			*/

      $this->dataMetrics = $var;
      return $this;
  }
  public function setDataType($var) {
		/**
			* \param	$var un \e string.
			* \detail la corespondance avec le DataIdentifier  TOTAL -> null
			*	\todo trouver les coresponsances pour: IP, WO, BF, HTTP, VLAN
			* \return	\e l'objet luis même.
			*/

      $this->type = $var;
      return $this;
  }
  public function setperiod($var) {
		/**
			* \param	$var un \e string représentant la durés sur la quelle ont veut les données.
			*	\detail Selectione la période sur la quelle on récupére les données: LAST_DAY, LAST_WEEK, LAST_MONTH
			* \return	\e l'objet luis même.
			*/

      $this->period = $var;
      return $this;
  }
  public function setFilter($var) {
		/**
			* \param	$var un \e string.
			* \todo trouver ce qu'il faut luis mettre.
			* \return	\e l'objet luis même.
			*/

      $this->filter = $var;
      return $this;
  }
  public function setFilteredTopType($var) {
		/**
			* \param	$var un \e string.
			* \detail Paramétre le Type de clasement: IP, WO, BF, HTTP, VLAN, TCP, UDP
			* \return	\e l'objet luis même.
			*/

      $this->type = $var;
      return $this;
  }
  public function setIp($var) {
		/**
			* \param	$var une \e addrese \e IP.
			* \detail paramétre le filtre sur une IP passer en paramétre
			* \return	\e l'objet luis même.
			*/

      $this->ip = $var;
      return $this;
  }
  public function setIpOrWo($var) {
		/**
			* \param	$var un \e string.
			* \detail peut valoir: IP ou WO
			*	\todo déterminer ce que ca change si on utilise IP ou WO
			* \return	\e l'objet luis même.
			*/

      $this->ipOrWo = $var;
      return $this;
  }
  public function setMetric($var) {
		/**
			* \param	$var un \e string.
			* \detail peut valoir: bandwidth, bandwidth_in, bandwidth_out, bytes, bytes_in, bytes_out, con_fail_rate_in, con_fail_rate_out, con_req_in, con_req_out, con_setup_time_in, con_setup_time_out, delay_in, delay_out, con_est_in, con_est_out, jitter_in, jitter_out, loss_burst_in, loss_burst_out, loss_rate_in, loss_rate_out, mos_in, mos_out, out_of_seq_in, out_of_seq_out, pkts_in , pkts_out, payload_in, payload_out, rst_in, rst_out, ret_time_in, ret_time_out, rtp_dup_in, rtp_dup_out, rtp_loss_in, rtp_loss_out, rtt_in, rtt_out, serv_resp_time_in, serv_resp_time_out, tcp_dup_in, tcp_dup_out, tcp_loss_in, tcp_loss_out, throughput_in, throughput_out, turn_in, turn_out, call_prog_in, call_prog_out, call_est_in, call_est_out, call_req_in, call_req_out, call_end_in, call_end_out, call_can_in, call_can_out, call_rej_in, call_rej_out, tcp_sess_in, tcp_sess_out, udp_sess_in, udp_sess_out, rtp_sess_in, rtp_sess_out
			* \return	\e l'objet luis même.
			*/

      $this->metric = $var;
      return $this;
  }
  public function setProtocol($var) {
		/**
			* \param	$var un \e string.
			* \detail un filtre sur le protocole passer en paramétre
			* \todo déterminer ses limites
			* \return	\e l'objet luis même.
			*/

      $this->protocol = $var;
      return $this;
  }
  public function setSize($var) {
		/**
			* \param	$var un \e integer.
			* \detail la taille maximale du clasement
			* \return	\e l'objet luis même.
			*/

      $this->size = $var;
      return $this;
  }
  public function setTcpPort($var) {
		/**
			* \param	$var un \e integer.
			* \detail changer le port corespondant au protocol TCP
			* \todo tester pour verification ainsi que voir les limites
			* \return	\e l'objet luis même.
			*/

      $this->tcpPort = $var;
      return $this;
  }
  public function setUdpPort($var) {
		/**
			* \param	$var un \e integer.
			* \detail changer le port corespondant au protocol TCP
			* \todo tester pour verification ainsi que voir les limites
			* \return	\e l'objet luis même.
			*/

      $this->UdpPort = $var;
      return $this;
  }
  public function setVlan($var) {
		/**
			* \param	$var un \e integer.
			* \detail parametre un filtre sur le vlan indiquer
			* \return	\e l'objet luis même.
			*/

      $this->vlan = $var;
      return $this;
  }
  public function setWo($var) {
		/**
			* \param	$var un \e string.
			* \detail filtre sur l'objet surveiller
			* \return	\e l'objet luis même.
			*/

      $this->wo = $var;
      return $this;
  }
  public function setObjects($var) {
		/**
			* \param	$var un \e string.
			* \todo déterminer ce qu'il prend en parametre
			* \return	\e l'objet luis même.
			*/

      $this->objects = $var;
      return $this;
  }
  public function setType($var) {
		/**
			* \param	$var un \e string.
			* \todo déterminer ce qu'il prend en parametre
			* \return	\e l'objet luis même.
			*/

      $this->type = $var;
      return $this;
  }
  public function setTopMetric($var) {
		/**
			* \param	$var un \e string.
			* \detail peut valoir: bandwidth, bandwidth_in, bandwidth_out, bytes, bytes_in, bytes_out, con_fail_rate_in, con_fail_rate_out, con_req_in, con_req_out, con_setup_time_in, con_setup_time_out, delay_in, delay_out, con_est_in, con_est_out, jitter_in, jitter_out, loss_burst_in, loss_burst_out, loss_rate_in, loss_rate_out, mos_in, mos_out, out_of_seq_in, out_of_seq_out, pkts_in , pkts_out, payload_in, payload_out, rst_in, rst_out, ret_time_in, ret_time_out, rtp_dup_in, rtp_dup_out, rtp_loss_in, rtp_loss_out, rtt_in, rtt_out, serv_resp_time_in, serv_resp_time_out, tcp_dup_in, tcp_dup_out, tcp_loss_in, tcp_loss_out, throughput_in, throughput_out, turn_in, turn_out, call_prog_in, call_prog_out, call_est_in, call_est_out, call_req_in, call_req_out, call_end_in, call_end_out, call_can_in, call_can_out, call_rej_in, call_rej_out, tcp_sess_in, tcp_sess_out, udp_sess_in, udp_sess_out, rtp_sess_in, rtp_sess_out			* \return	\e l'objet luis même.
			*/

      $this->metric = $var;
      return $this;
  }
  public function setTopFilter($var) {
		/**
			* \param	$var un \e string.
			* \todo déterminer ce qu'il prend en parametre
			* \return	\e l'objet luis même.
			*/

      $this->topFilter = $var;
      return $this;
  }
  public function setTopSize($var) {
		/**
			* \param	$var un \e string.
			* \return	\e l'objet luis même.
			*/

      $this->size = $var;
      return $this;
  }
  public function setTopType($var) {
		/**
			* \param	$var un \e string.
			* \detail paramétre le Type de clasement: IP, WO, BF, HTTP, VLAN, TCP, UDP
			* \return	\e l'objet luis même.
			*/

      $this->type = $var;
      return $this;
  }

  public function setIp1($ip, $Descr, $type) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->ip1 = $ip;
      $this->ip1Descr = $Descr;
      $this->ip1Type = $type;
      return $this;
  }
  public function setIp2($ip, $Descr, $type) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->ip2 = $ip;
      $this->ip2Descr = $Descr;
      $this->ip2Type = $type;
      return $this;
  }
  public function setIpContainer($Container, $Descr, $type) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->ipContainer = $Container;
      $this->ipContainerDescr = $Descr;
      $this->ipContainerType = $type;
      return $this;
  }
  public function setLimit($var) {
		/**
			* \param	$var un \e string.
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur
			*/

      $this->limit = $var;
      return $this;
  }
  public function setOrder($order, $conv) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->orderRow = $order;
      $this->orderedConv = $conv;
      return $this;
  }
  public function setP2($p, $Descr) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->p2 = $p;
      $this->p2Descr = $Descr;
      return $this;
  }
  public function setP4($p, $Descr) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->p4 = $p;
      $this->p4Descr = $Descr;
      return $this;
  }
  public function setP7($p, $Descr, $type) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->p7 = $p;
      $this->p7Descr = $Descr;
      $this->p7Type = $type;
      return $this;
  }
  public function setsipId1($sipId, $Descr) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->sipId1 = $sipId;
      $this->sipId1Descr = $Descr;
      return $this;
  }
  public function setsipId2($sipId, $Descr) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->sipId2 = $sipId;
      $this->sipId2Descr = $Descr;
      return $this;
  }
  public function setVlanDescr($Descr) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->VlanDescr = $Descr;
      return $this;
  }
  public function setResultType($type) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->resultType = $type;
      return $this;
  }
  public function setRegex($var) {
		/**
			* \return	\e l'objet luis même.
			* \todo	trouver a quoi sert ce paramétre du xml du serveur et comment le paramétrer
			*/

      $this->regex = $var;
      return $this;
  }
  private function getNetbios($ip){
  	require_once ('Zend/Loader.php');
     //On charge la class Zend_db
     Zend_Loader::loadClass('Zend_Db');
     // paramètre de connexion database (à externailser...)
     $parametre_connexion = array (
     'host'     => 'localhost',
     'username' => 'root',
     'password' => 'Aus14net',
     'dbname'   => 'portail'
     );     
     
     // Utilisation du driver PDO::mysql pour la connexion
     $db = Zend_Db::factory('Pdo_Mysql', $parametre_connexion);
     //$db->setFetchMode(Zend_Db::FETCH_OBJ);
  	 $name = $db->fetchRow( "SELECT name FROM iptonetbios WHERE ip = '".$ip."'" );
     if (!$name){
     	$name = $ip;
     } else {
     	$name = $name['name'];
     }
     return $name;
  }
  public function getMetricType($metric){
  $metric_array = array(
"bandwidth" => "BITRATE",
"bandwidth_in" => "BITRATE",
"bandwidth_out" => "BITRATE",
"bytes" => "VOLUME",
"bytes_in" => "VOLUME",
"bytes_out" => "VOLUME",
"con_fail_rate_in" => "PERCENTAGE",
"con_fail_rate_out" => "PERCENTAGE",
"con_req_in" => "QUANTITY",
"con_req_out" => "QUANTITY",
"con_setup_time_in" => "TIME",
"con_setup_time_out" => "TIME",
"delay_in" => "TIME",
"delay_out" => "TIME",
"con_est_in" => "QUANTITY",
"con_est_out" => "QUANTITY",
"jitter_in" => "TIME",
"jitter_out" => "TIME",
"loss_burst_in" => "QUANTITY",
"loss_burst_out" => "QUANTITY",
"loss_rate_in" => "PERCENTAGE",
"loss_rate_out" => "PERCENTAGE",
"mos_in" => "QUANTITY",
"mos_out" => "QUANTITY",
"out_of_seq_in" => "QUANTITY",
"out_of_seq_out" => "QUANTITY",
"pkts_in" => "QUANTITY",
"pkts_out" => "QUANTITY",
"payload_in" => "VOLUME",
"payload_out" => "VOLUME",
"rst_in" => "QUANTITY",
"rst_out" => "QUANTITY",
"ret_time_in" => "TIME",
"ret_time_out" => "TIME",
"rtp_dup_in" => "QUANTITY",
"rtp_dup_out" => "QUANTITY",
"rtp_loss_in" => "QUANTITY",
"rtp_loss_out" => "QUANTITY",
"rtt_in" => "TIME",
"rtt_out" => "TIME",
"serv_resp_time_in" => "TIME",
"serv_resp_time_out" => "TIME",
"tcp_dup_in" => "QUANTITY",
"tcp_dup_out" => "QUANTITY",
"tcp_loss_in" => "QUANTITY",
"tcp_loss_out" => "QUANTITY",
"throughput_in" => "PACKETRATE",
"throughput_out" => "PACKETRATE",
"turn_in" => "QUANTITY",
"turn_out" => "QUANTITY",
"call_prog_in" => "QUANTITY",
"call_prog_out" => "QUANTITY",
"call_est_in" => "QUANTITY",
"call_est_out" => "QUANTITY",
"call_req_in" => "QUANTITY",
"call_req_out" => "QUANTITY",
"call_end_in" => "QUANTITY",
"call_end_out" => "QUANTITY",
"call_can_in" => "QUANTITY",
"call_can_out" => "QUANTITY",
"call_rej_in" => "QUANTITY",
"call_rej_out" => "QUANTITY",
"tcp_sess_in" => "QUANTITY",
"tcp_sess_out" => "QUANTITY",
"udp_sess_in" => "QUANTITY",
"udp_sess_out" => "QUANTITY",
"rtp_sess_in" => "QUANTITY",
"rtp_sess_out" => "QUANTITY"
);
$type = $metric_array[$metric];
return $type;
  }
  
  public function getLabelFr($metric){
  $metric_array = array(
"bandwidth" => "Débit",
"bandwidth_in" => "Débit in",
"bandwidth_out" => "Débit out",
"bytes" => "Volume",
"bytes_in" => "Volume in",
"bytes_out" => "Volume out",
"con_fail_rate_in" => "Taux d'échecs con. in",
"con_fail_rate_out" => "Taux d'échecs con. out",
"con_req_in" => "Requêtes de connexion in",
"con_req_out" => "Requêtes de connexion out",
"con_setup_time_in" => "Tps de connexion in",
"con_setup_time_out" => "Tps de connexion out",
"delay_in" => "RTP Délai inter-paquets in",
"delay_out" => "RTP Délai inter-paquets out",
"con_est_in" => "Connexions établies in",
"con_est_out" => "Connexions établies out",
"jitter_in" => "RTP Gigue in",
"jitter_out" => "RTP Gigue out",
"loss_burst_in" => "RTP Taille des bursts in",
"loss_burst_out" => "RTP Taille des bursts out",
"loss_rate_in" => "Taux de perte in",
"loss_rate_out" => "Taux de perte out",
"mos_in" => "MOS calculé in",
"mos_out" => "MOS calculé out",
"out_of_seq_in" => "RTP Paquets hors séquence in",
"out_of_seq_out" => "RTP Paquets hors séquence out",
"pkts_in" => "Paquets in",
"pkts_out" => "Paquets out",
"payload_in" => "Charge utile in",
"payload_out" => "Charge utile out",
"rst_in" => "Resets TCP in",
"rst_out" => "Resets TCP out",
"ret_time_in" => "Tps de retrans. in",
"ret_time_out" => "Tps de retrans. out",
"rtp_dup_in" => "RTP Paquets dupliqués in",
"rtp_dup_out" => "RTP Paquets dupliqués out",
"rtp_loss_in" => "RTP Paquets perdus in",
"rtp_loss_out" => "RTP Paquets perdus out",
"rtt_in" => "RTT in",
"rtt_out" => "RTT out",
"serv_resp_time_in" => "Tps de réponse serveur in",
"serv_resp_time_out" => "Tps de réponse serveur out",
"tcp_dup_in" => "Paquets dupliqués in",
"tcp_dup_out" => "Paquets dupliqués out",
"tcp_loss_in" => "Paquets perdus in",
"tcp_loss_out" => "Paquets perdus out",
"throughput_in" => "Débit de paquets in",
"throughput_out" => "Débit de paquets out",
"turn_in" => "Pseudo requêtes in",
"turn_out" => "Pseudo requêtes out",
"call_prog_in" => "Appels in",
"call_prog_out" => "Appels out",
"call_est_in" => "Etablissements d'appel in",
"call_est_out" => "Etablissements d'appel out",
"call_req_in" => "Requêtes d'appel in",
"call_req_out" => "Requêtes d'appel out",
"call_end_in" => "Fins d'appel in",
"call_end_out" => "Fins d'appel out",
"call_can_in" => "Annulations d'appel in",
"call_can_out" => "Annulations d'appel out",
"call_rej_in" => "Rejets d'appel in",
"call_rej_out" => "Rejets d'appel out",
"tcp_sess_in" => "TCP Sessions in",
"tcp_sess_out" => "TCP Sessions out",
"udp_sess_in" => "UDP Sessions in",
"udp_sess_out" => "UDP Sessions out",
"rtp_sess_in" => "RTP Sessions in",
"rtp_sess_out" => "RTP Sessions out"
);
$type = $metric_array[$metric];
return $type;
  }
}

