<?php

class MySecureService {
	/**
	 * \file	MySecureService.php
	 * \version	1.0
	 * \date	16 Juin 2015
	 * \brief	Définit les fonction minimal pour la création d'un client SOAP avec authentification.
	 */
	const WSSE_NODE = "Security";
	const WSSE_NS = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
	const WSU_NS = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";	

  protected $soapClient = null;
  protected $wsdl = null;
  protected $https = True;
  protected $user = null;
	protected $options = null;

    public function __construct(WsUser $wsUser, $wsdl, $options = null) {
        $absoluteWsdl = sprintf('%s:%d/%s', $wsUser->getProbe(), $wsUser->getPort(), $wsdl);
				$this->options = $options;
        $this->setWsdl($absoluteWsdl);
        $this->setUser($wsUser);
    }

   protected function _initSoapClient() {
		/**
		 * \brief      Initialise un client soap
		 * \details    Initialise un cient soap avec une configuration par défaut
		 * \return     Ne retourne \b rien car initialise l'atribut \e $soapClient ;
		 */
				$context = stream_context_create(
								      array(
								        'ssl' => array(
								                   'verify_peer' => false,  //default
								                   'allow_self_signed' => true, //needs verify peer, tried that
								                   'ciphers'=>"SHA1", // quite random.
								         				),
								        'https' => array(
								                   'curl_verify_ssl_peer'  => false,
								                   'curl_verify_ssl_host'  => false
								                )
											)
								  );
        $wsdl = $this->getWsdl();
        $this->soapClient = new SoapClient($wsdl, array(
            'soap_version' => SOAP_1_1,
						'trace' => 1,
						'exceptions' => false,
        ));
    }

    public function __call($name, $arguments) {
			/**
			 * \brief      Execute une requete
			 * \details    La requette est exécuter par l'intermédiaire d'un client SOAP
			 * \param    $name         Nom de la fonction executer sur le serveur SOAP.
			 * \param    $arguments         Argument demander par le serveur SOAP.
			 * \return   Un \e array contenant la réponse du serveur SOAP. ou une \b exeption "SOAP Server NULL response" en cas de réponse nul du serveur
			 */
		  $soapClient = $this->getSoapClient();
			$securityHeader = $this->createSecurityHeader();
			$soapClient->__setSoapHeaders($securityHeader);   
			$response = $soapClient->__soapcall($name, $arguments);
	//		echo "-----------     \nREQUEST:\n" . $soapClient->__getLastRequest() . "\n";
		
			if( property_exists($response, 'faultstring')){
				return $response->faultstring ;
			}
		  if ($response) {
		      return property_exists($response, 'return') ? $response->return : $response;
		  }
		  throw new \Exception('SOAP Server NULL response');
    }

    // -------------------------------------------------------------------------
    // Getters & Setters
    // -------------------------------------------------------------------------

    public function setWsdl($Wsdl) {
			/**
			 * \brief    set l'atribut $wsdl
			 * \param    \a $Wsdl         L'adresse du wsdl à récupérer.
			 * \return   Le \e MySecureService  luis même.
			 */
        $this->wsdl = $Wsdl;
        $this->soapClient = null;
        return $this;
    }

    public function getWsdl() {
			/**
			 * \brief    Récupérer la valeur de l'atribut $wsdl
			 * \return   Un \e string représentant l'adresse du wsdl.
			 */
        return 'https://' . $this->wsdl;
    }

    public function getSoapClient() {
			/**
			 * \brief    Récupérer le client soap de l'objet.
			 * \return   Le \e SoapClient De l'objet apelant la fonction.
			 */
        if (null == $this->soapClient) {
            $this->_initSoapClient();
        }
        return $this->soapClient;
    }

	public function setUser(WsUser $user){
		/**
		 * \brief    Paramétre l'utilisateur du web service.
		 * \param    \a $user un objet \e WsUser.
		 * \return   Le \e MySecureService  luis même.
		 */
		$this->user = $user;
		return $this;
	}

	public function getUser(){
		/**
		 * \brief    Récupérer l'utilisateur soap de l'objet.
		 * \return   Le \e WsUser De l'objet apelant la fonction.
		 */
		return $this->user;
	}

	private function createSecurityHeader(){
		/**
		 * \brief    Paramétre l'entête de sécuritée.
		 * \details  L'entête est générée en fonction de l'utilisateur \e WsUser de l'objet appelant.
		 * \return   Un \e string  représenntant l'entête de sécuriter paramétrer a ajouter au client soap.
		 */
		$user = $this->getUser();
		$created = gmdate('Y-m-d\TH:i:s\Z');
		$nonce = base64_encode(pack('H*', mt_rand()));
		$token = new \stdClass();
		$token->Username = new \SoapVar($user->getLogin(), XSD_STRING, null, null, null, self::WSSE_NS);
		$token->Password = new \SoapVar($user->getPassword(), XSD_STRING, null, null, null, self::WSSE_NS);
		$token->Nonce = new \SoapVar($nonce, XSD_BASE64BINARY, null, null, null, self::WSSE_NS);
		$token->Created = new \SoapVar($created, XSD_DATETIME, null, null, null, self::WSU_NS);
		$wSec = new \stdClass();
		$wSec->UsernameToken = new \SoapVar($token, SOAP_ENC_OBJECT, null, null, null, self::WSSE_NS);
		$header = new \SoapHeader(self::WSSE_NS, self::WSSE_NODE, $wSec, true);
		return $header;
	}

}


