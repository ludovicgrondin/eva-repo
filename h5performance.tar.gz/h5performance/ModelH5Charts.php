<?php
 //On inclus le Loader de Zend
     require ('Zend/Loader.php');
     //On charge la class Zend_db
     Zend_Loader::loadClass('Zend_Db');
     // paramètre de connexion database (à externailser...)
     $parametre_connexion = array (
     'host'     => 'localhost',
     'username' => 'root',
     'password' => 'Aus14net',
     'dbname'   => 'portail'
     );     
     
     // Utilisation du driver PDO::mysql pour la connexion
     $db = Zend_Db::factory('Pdo_Mysql', $parametre_connexion);
     //$db->setFetchMode(Zend_Db::FETCH_OBJ);

function getActiveCharts($db){
     $active = 'OUI';
     $result = $db->fetchAll( "SELECT id, Name FROM h5charts WHERE active = '".$active."'" );
     return $result;
}
function getChartById($db,$id){
     $result = $db->fetchRow( "SELECT * FROM h5charts WHERE id = '".$id."'" );
     return $result;
}
function getAllIpToNetbios($db){
	 $result = $db->fetchAll( "SELECT * FROM iptonetbios" );
     return $result;
}
function setIpToNetbios($db,$data){
	 $db->insert('iptonetbios', $data);
}
function updateIpToNetbios($db,$data,$ip){
	 $db->update('iptonetbios', $data, 'ip = "'.$ip.'"');
}