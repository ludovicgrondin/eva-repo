<?php
//error_reporting(E_ALL);
//ini_set('display_errors',1);
/*
if (isset($_POST["ChartType"]) && isset($_POST["Dashlet"]) && isset($_POST["ChartId"])){
	$post_chart_type = $_POST["ChartType"]; // LINE, PIE, STACKEDAREA
	$post_dashlet = $_POST["Dashlet"]; // OBJECT_CHART, METRIC_CHART, TOP_CHART, FILTERED_TOP_CHART
	$post_chart_id = $_POST["ChartId"]; // 1, 2, 3, 4, 5....
	$dashlet_model = getDashletModel($post_dashlet);
	$chart_settings = getChartSetting($post_chart_type, $post_dashlet);
	$poller_address = "10.140.4.6";
	
	$homepage = file_get_contents('https://'.$poller_address.'/h5performance/'.$dashlet_model.'?ChartType='.$post_chart_type);
	$type = strtolower($post_chart_type);
	$setting = $chart_settings;
	$chart_id = $post_chart_id;
}
*/

if (isset($_POST["ChartId"])){
	$post_chart_id = $_POST["ChartId"]; // 1, 2, 3, 4, 5....
	//$post_chart_id = 3;
	//if (isset($post_chart_id)){
	require ('ModelH5Charts.php');
    $result = getChartById($db,$post_chart_id);
	$post_chart_type = $result["ChartType"]; // LINE, PIE, STACKEDAREA
	$post_dashlet = $result["DashletType"]; // OBJECT_CHART, METRIC_CHART, TOP_CHART, FILTERED_TOP_CHART
	//$post_chart_id = $_POST["ChartId"]; // 1, 2, 3, 4, 5....
	
	$arg = '';
	if ($result["Period"] != NULL){ $arg = $arg.'&Period='.$result["Period"]; }
	if ($result["Type"] != NULL){ $arg = $arg.'&Type='.$result["Type"]; }
	if ($result["DataIdentifier"] != NULL){ $arg = $arg.'&DataIdentifier='.$result["DataIdentifier"]; }
	if ($result["Metric"] != NULL){ $arg = $arg.'&Metric='.$result["Metric"]; }
	if ($result["Metric1"] != NULL){ $arg = $arg.'&Metric1='.$result["Metric1"]; }
	if ($result["Metric2"] != NULL){ $arg = $arg.'&Metric2='.$result["Metric2"]; }
	if ($result["Metric3"] != NULL){ $arg = $arg.'&Metric3='.$result["Metric3"]; }
	if ($result["Metric4"] != NULL){ $arg = $arg.'&Metric4='.$result["Metric4"]; }
	if ($result["Metric5"] != NULL){ $arg = $arg.'&Metric5='.$result["Metric5"]; }
	if ($result["Size"] != NULL){ $arg = $arg.'&Size='.$result["Size"]; }
	if ($result["Protocol"] != NULL){ $arg = $arg.'&Protocol='.$result["Protocol"]; }
	if ($result["Port"] != NULL){ $arg = $arg.'&Port='.$result["Port"]; }
	if ($result["IpOrWo"] != NULL){ $arg = $arg.'&IpOrWo='.$result["IpOrWo"]; }
	if ($result["Wo"] != NULL){ $arg = $arg.'&Wo='.urlencode($result["Wo"]); }
	if ($result["Wo1"] != NULL){ $arg = $arg.'&Wo1='.urlencode($result["Wo1"]); }
	if ($result["Wo2"] != NULL){ $arg = $arg.'&Wo2='.urlencode($result["Wo2"]); }
	if ($result["Wo3"] != NULL){ $arg = $arg.'&Wo3='.urlencode($result["Wo3"]); }
	if ($result["Wo4"] != NULL){ $arg = $arg.'&Wo4='.urlencode($result["Wo4"]); }
	if ($result["Wo5"] != NULL){ $arg = $arg.'&Wo5='.urlencode($result["Wo5"]); }
	if ($result["filter"] != NULL){ $arg = $arg.'&filter='.urlencode($result["filter"]); }
	if ($result["regex"] != NULL){ $arg = $arg.'&regex='.urlencode($result["regex"]); }
	
	
	$dashlet_model = getDashletModel($post_dashlet);
	$chart_settings = getChartSetting($post_chart_type, $post_dashlet);
	$poller_address = "55.34.13.240";
	
	$homepage = file_get_contents('https://'.$poller_address.'/h5performance/'.$dashlet_model.'?ChartType='.$post_chart_type.$arg);
	//echo 'https://'.$poller_address.'/h5performance/'.$dashlet_model.'?ChartType='.$post_chart_type.$arg;

	//echo 'https://'.$poller_address.'/h5performance/'.$dashlet_model.'?ChartType='.$post_chart_type.$arg;

	$type = strtolower($post_chart_type);
	$setting = $chart_settings;
	$chart_id = $post_chart_id;
}

// fonctions
function getDashletModel($post_dashlet){
	$model_array = array(
		"ALARM_MONITOR" => "todo.php",
		"ALARM_GRAVITY_HISTORY" => "todo.php",
		"ALARM_GRAVITY_TOP" => "todo.php",
		"OBJECT_CHART" => "ModelObjectChart.php",
		"METRIC_CHART" => "ModelMetricChart.php",
		"TOP_CHART" => "ModelTopChart.php",
		"FILTERED_TOP_CHART" => "ModelFilteredTopChart.php",
	);
	return $model_array[$post_dashlet];
}
function getChartSetting($post_chart_type, $post_dashlet){
/**
Possibilités:
FILTERED_TOP_CHART + LINE = TOP_TIMING_CHART_SETTINGS
FILTERED_TOP_CHART + PIE = TOP_PIE_CHART_SETTINGS
FILTERED_TOP_CHART + STACKEDAREA = TOP_TIMING_CHART_SETTINGS

TOP_CHART + LINE = TOP_TIMING_CHART_SETTINGS
TOP_CHART + PIE = TOP_PIE_CHART_SETTINGS
TOP_CHART + STACKEDAREA = TOP_TIMING_CHART_SETTINGS

METRIC_CHART + LINE = METRIC_CHART_SETTINGS
METRIC_CHART + PIE = TOP_PIE_CHART_SETTINGS
METRIC_CHART + STACKEDAREA = TOP_TIMING_CHART_SETTINGS

OBJECT_CHART + LINE = TOP_TIMING_CHART_SETTINGS
OBJECT_CHART + PIE = TOP_PIE_CHART_SETTINGS
OBJECT_CHART + STACKEDAREA = TOP_TIMING_CHART_SETTINGS
*/ 
if ($post_chart_type == "STACKEDAREA"){
	$chart_setting = "TOP_TIMING_CHART_SETTINGS";
} elseif ($post_chart_type == "PIE"){
	$chart_setting = "TOP_PIE_CHART_SETTINGS";
} elseif ($post_chart_type == "LINE"){
	if ($post_dashlet == "METRIC_CHART"){
		$chart_setting = "METRIC_CHART_SETTINGS";
		} else {
		$chart_setting = "TOP_TIMING_CHART_SETTINGS";
		}
}
return $chart_setting;
}
?>
<script type="text/javascript">
	var CHART_ENABLE_ANIMATIONS = true;
</script>
<div class="chart-container" id="metric-chart-<?php echo $chart_id; ?>" style="width: 100%; height: 250px"></div>    
<script type="text/javascript">
$(document).ready(function() {
	var dashlet = $('#metric-chart-<?php echo $chart_id; ?>');
	
	dashlet.jqxChart('showToolTips', true);
	
	var width = dashlet.width();
	var height = dashlet.height();
	var period = 'LAST_DAY';
	var chartType = '<?php echo $type; ?>';
	var language = 'fr_FR';
	var chartData = <?php echo $homepage; ?>;
	var settings = <?php echo $setting; ?>.getSettings(
				width,
				height,
				period,
				chartData,
				chartType,
				language);
	
	dashlet.jqxChart(settings);
		 
	});
</script>