<?php
class WsUser {
	/**
	 * \file	WsUser.php
	 * \version	1.0
	 * \date	16 Juin 2015
	 * \brief	Définit l'utilisateur du Web service.
	 */

    private $id;
    private $login;
    private $password;
    private $probe;
    private $port;
    private $https;

    public function getId() {
		/**
			* \return	\e L'identifiant de l'utilisateur.
			*/
        return $this->id;
    }
    public function setId($id) {
		/**
			* \param	$id un \e identifiant.
			* \return	\e Void.
			*/
        $this->id = $id;
    }

    public function getLogin() {
		/**
			* \return	Le \e login de utilisateur.
			*/
        return $this->login;
    }
    public function setLogin($login) {
		/**
			* \param	$login le \e login de l'utilisateur.
			* \return	\e Void.
			*/
        $this->login = $login;
    }

    public function getPassword() {
		/**
			* \return	Le \e password de utilisateur.
			*/
        return $this->password;
    }
    public function setPassword($password) {
		/**
			* \param	$password le \e password de l'utilisateur.
			* \return	\e Void.
			*/
        $this->password = md5($password);
    }

    public function getProbe() {
		/**
			* \return \e l'adrrese du web service.
			*/
        return $this->probe;
    }
    public function setProbe($probe) {
		/**
			* \param	$probe \e l'adresse du Web Service.
			* \return	\e Void.
			*/
        $this->probe = $probe;
    }

    public function getPort() {
		/**
			* \return le \e port du web service.
			*/
        return $this->port;
    }
    public function setPort($port) {
		/**
			* \param	$port le \e Port du Web Service.
			* \return	\e Void.
			*/
        $this->port = $port;
    }
}

