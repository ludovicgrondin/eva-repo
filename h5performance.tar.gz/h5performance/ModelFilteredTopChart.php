<?php
//error_reporting(E_ALL);
//ini_set('display_errors',1);
/**
 * \file      FILTERED_TOP_CHART
 * \author    Ludo
 * \version   1.0
 * \date      16 Juin 2015
 * \brief     Graphique de TOP Filtré : $WSdata->setChartFonc("getFilteredTopTimingChart");
 */
 
/**
PARAMETERS:
 
Type de graphe: (pas nécessaire ici)
 - pie 
 - stackedarea 
 - line
 
*** Période : $WSdata->setPeriod("LAST_DAY");
 - LAST_DAY
 - LAST_WEEK
 - LAST_MONTH

*** Type de Top à afficher: $WSdata->setFilteredTopType();
 - IP (IP)
 - WO (Objet surveillé)
 - BF (Flux métier)
 - HTTP (Application HTTP)
 - VLAN (VLAN)
 - TCP (Applications TCP)
 - UDP (Applications UDP)
 
*** La métriques du TOP : $WSdata->setMetric("bandwidth_out");
 
------ Débit/Volume/Charge ------
"bandwidth" => "Débit",
"bandwidth_in" => "Débit in",
"bandwidth_out" => "Débit out",
"bytes" => "Volume",
"bytes_in" => "Volume in",
"bytes_out" => "Volume out",
"pkts_in" => "Paquets in",
"pkts_out" => "Paquets out",
"payload_in" => "Charge utile in",
"payload_out" => "Charge utile out",
"throughput_in" => "Débit de paquets in",
"throughput_out" => "Débit de paquets out",
"turn_in" => "Pseudo requêtes in",
"turn_out" => "Pseudo requêtes out",

------ Temps de réponse ------
"rtt_in" => "RTT in",
"rtt_out" => "RTT out",
"serv_resp_time_in" => "Tps de réponse serveur in",
"serv_resp_time_out" => "Tps de réponse serveur out",

------ Connexions ------
"con_est_in" => "Connexions établies in",
"con_est_out" => "Connexions établies out", 
"con_fail_rate_in" => "Taux d'échecs con. in",
"con_fail_rate_out" => "Taux d'échecs con. out",
"con_req_in" => "Requêtes de connexion in",
"con_req_out" => "Requêtes de connexion out",
"con_setup_time_in" => "Tps de connexion in",
"con_setup_time_out" => "Tps de connexion out",

------ Sessions actives ------
"tcp_sess_in" => "TCP Sessions in",
"tcp_sess_out" => "TCP Sessions out",
"udp_sess_in" => "UDP Sessions in",
"udp_sess_out" => "UDP Sessions out",
"rtp_sess_in" => "RTP Sessions in",
"rtp_sess_out" => "RTP Sessions out"

------ Qualité ------
"loss_rate_in" => "Taux de perte in",
"loss_rate_out" => "Taux de perte out",
"rst_in" => "Resets TCP in",
"rst_out" => "Resets TCP out",
"ret_time_in" => "Tps de retrans. in",
"ret_time_out" => "Tps de retrans. out",
"tcp_dup_in" => "Paquets dupliqués in",
"tcp_dup_out" => "Paquets dupliqués out",
"tcp_loss_in" => "Paquets perdus in",
"tcp_loss_out" => "Paquets perdus out",

------ RTP ------
"mos_in" => "MOS calculé in",
"mos_out" => "MOS calculé out",
"delay_in" => "RTP Délai inter-paquets in",
"delay_out" => "RTP Délai inter-paquets out",
"jitter_in" => "RTP Gigue in",
"jitter_out" => "RTP Gigue out",
"loss_burst_in" => "RTP Taille des bursts in",
"loss_burst_out" => "RTP Taille des bursts out",
"out_of_seq_in" => "RTP Paquets hors séquence in",
"out_of_seq_out" => "RTP Paquets hors séquence out", 
"rtp_dup_in" => "RTP Paquets dupliqués in",
"rtp_dup_out" => "RTP Paquets dupliqués out",
"rtp_loss_in" => "RTP Paquets perdus in",
"rtp_loss_out" => "RTP Paquets perdus out",

------ VOIP ------
"call_prog_in" => "Appels in",
"call_prog_out" => "Appels out",
"call_est_in" => "Etablissements d'appel in",
"call_est_out" => "Etablissements d'appel out",
"call_req_in" => "Requêtes d'appel in",
"call_req_out" => "Requêtes d'appel out",
"call_end_in" => "Fins d'appel in",
"call_end_out" => "Fins d'appel out",
"call_can_in" => "Annulations d'appel in",
"call_can_out" => "Annulations d'appel out",
"call_rej_in" => "Rejets d'appel in",
"call_rej_out" => "Rejets d'appel out",

*** Taille du top : $WSdata->setSize(10);
 - de 1 à 10
 
* Option *** Protocole : $WSdata->setProtocol("TCP");
 - TCP (Applications TCP)
 - UDP (Applications UDP)
 
* Option *** Port TCP ou UDP : $WSdata->setTcpPort("443") ou $WSdata->setUdpPort("123");
 - Numéro de port TCP ou UDP
 
*** IP / Objet surveillé : $WSdata->setIpOrWo("WO");
 - IP (IP)
 - WO (Objet surveillé)

*** IP ou WO (valeur du filtre) : $WSdata->setWo("AMON ADMIN") ou $WSdata->setIP("192.168.0.1");
 - IP (IP)
 - WO (Objet surveillé)

*/
$get_chart_type = "LINE";
$get_period = "LAST_DAY";
$get_type = "IP";
$get_metric = "bandwidth_out";
$get_size = 5;
$get_iporwo = "WO";
$get_wo = "AMON ADMIN";

if (isset($_GET["ChartType"])) {$get_chart_type = $_GET["ChartType"];}
if (isset($_GET["Period"])) {$get_period = $_GET["Period"];}
if (isset($_GET["Type"])) {$get_type = $_GET["Type"];}
if (isset($_GET["Metric"])) {$get_metric = $_GET["Metric"];}
if (isset($_GET["Size"])) {$get_size = $_GET["Size"];}
if (isset($_GET["IpOrWo"])) {$get_iporwo = $_GET["IpOrWo"];}
if (isset($_GET["Wo"])) {$get_wo = $_GET["Wo"];}

require 'WsUser.php';
require 'MyProbeDataService.php';

$UserName= 'administrateur';
$UserPwd= 'h5admin';
$WsServer= '55.34.13.242';
$WsPort= '8080';

$MyWsUser = new WsUser();
$MyWsUser -> setLogin($UserName);
$MyWsUser -> setPassword($UserPwd);
$MyWsUser -> setProbe($WsServer);
$MyWsUser -> setPort($WsPort);

$WSdata= new MyProbeDataService($MyWsUser, "probe-data?wsdl");

if ($get_chart_type == "PIE"){ //PIE
	$WSdata->setChartFonc("getProbeFilteredTopPieChart");
} else { // LINE ou STACKEDAREA
	$WSdata->setChartFonc("getProbeFilteredTopTimingChart");
}

// paramètres niveau 1
$WSdata->setPeriod($get_period);
$WSdata->setFilteredTopType($get_type);
$WSdata->setMetric($get_metric);
$WSdata->setSize($get_size);

// paramètres niveau 2
//option $WSdata->setProtocol("TCP");
//option $WSdata->setTcpPort("443"); //$WSdata->setUdpPort("123");
$WSdata->setIpOrWo($get_iporwo);	
$WSdata->setWo($get_wo); // ou $WSdata->setIP("192.168.0.1");

// appel des données
if ($get_chart_type == "PIE"){ //PIE
	$data=$WSdata->getPieChart(); 
} else { // LINE ou STACKEDAREA
	$data=$WSdata->getTopTimingChart();
}

// envoie des données
echo $data;