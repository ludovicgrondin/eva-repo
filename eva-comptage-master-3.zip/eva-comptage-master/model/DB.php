<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('USESQLSRV', 0);

require ('Zend/Loader.php');

function connectRW($dbname){
     //On charge la class Zend_db
     Zend_Loader::loadClass('Zend_Db');
	 
     // paramètre de connexion database
     $parametre_connexion = array (
     	'host'     => 'localhost',
     	'username' => 'centreon',
     	'password' => 'Aus14net',
     	'dbname'   => $dbname
     	);     

     // Utilisation du driver PDO::mysql pour la connexion
     $db = Zend_Db::factory('Pdo_Mysql', $parametre_connexion);
	 return $db;
}

function connectTEP($dbname){
     Zend_Loader::loadClass('Zend_Db');
      
     $parametre_connexion = array (
          'host'     => 'localhost',
          'username' => 'centreon',
          'password' => 'Aus14net',
          'dbname'   => $dbname
          );
     $db = Zend_Db::factory('Pdo_Mysql', $parametre_connexion);
     return $db;
}

function connectTEPSqlSrv($dbname){
     global $tepDbError;
     $serverName = "localhost";
     $user = "centreon";
     $pass = "Aus14net";
     $db = null;
     try  
     {
          $db = new PDO( "sqlsrv:server=$serverName ; Database=$dbname",  $user, $pass);  
          $db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );  
     }
     catch(Exception $e)  
     {
          $tepDbError = "erreur conexion sqlsrv: " . $e->getMessage();
          $db = null;
          return null;
     }
     return $db;
}

function getTepData($date){
     $prefix = "";
     $result = null;
     if (USESQLSRV)
          $db = connectTEPSqlSrv("AdvanceEDS");
     else
          $db = connectTEP("AdvanceEDS");
     if ($db != null) {
          $sql = "select " . $prefix . "RESULTSRAW.TS, " . $prefix . "DATADEFINITIONS.DEVICE, " . $prefix . "DATADEFINITIONS.VARIABLE, " . $prefix . "DATADEFINITIONS.DATAID, " . $prefix . "RESULTSRAW.VAL 
               from " . $prefix . "DATADEFINITIONS
               inner join " . $prefix . "RESULTSRAW
               on " . $prefix . "DATADEFINITIONS.DATAID = " . $prefix . "RESULTSRAW.DATA
               where " . $prefix . "DATADEFINITIONS.VARIABLE in ('A-_T1','A-_T2','A+_T1','A+_T2')
               and " . $prefix . "RESULTSRAW.TS = CAST(:date AS DATETIME)";
          $stm = $db->prepare($sql);
          $stm->execute(array(':date' => $date . ' 10:00:00.000'));
          $result['indexData'] = $stm->fetchAll();
          $stm = $db->prepare("select * from " . $prefix . "STATIONS");
          $stm->execute();
          $result['stationData'] = $stm->fetchAll(PDO::FETCH_COLUMN, 0);
          $stm = $db->prepare("select * from " . $prefix . "DEVICES");
          $stm->execute();
          $result['deviceData'] = $stm->fetchAll();
     }
     return $result;
}

?>