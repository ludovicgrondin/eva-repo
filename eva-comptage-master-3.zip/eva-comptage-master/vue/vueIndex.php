<?php

	$page['container']['header'] = '<div id="header"><div id="dateSelector">' . $dateSelector . '</div><input type="button"  onclick="sync()" value="Synchroniser"></input>' . '</div>';
	$page['container']['footer'] = '<p><p/>';

	//require_once 'Calcul/result.php';
	//require_once 'Calcul/set.php';
	
	$page['container']['main'] .= '<div class="leftPart">' . $station .  '</div><div class="rightPart">' . $facture .  '</div>';

	require_once 'vueFrame.php';

	echo $page['container']['frameSet'];
?>
