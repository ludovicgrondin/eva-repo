<?php
	$factureInserted = 0;
	$factureMsg = '';

	$factureInserted = insertPostFacture($_POST, $date2);


	require_once 'controlleurIndex.php';

?>