function sync(){
	var e = document.getElementById("yearSelector");
	var year = e.options[e.selectedIndex].value + '-';
	var e = document.getElementById("monthSelector"); 
	var month = e.options[e.selectedIndex].value;
	if (month < 10)
		month = '0' + month;
	var date = year + month + '-01';
	$.ajax({
		type: 'POST',
		url: 'sync.php',
		data : 'date=' + date,
		dataType : 'html',
		success: function(data) {
			alert(data);
			changeDate();
		}
	})
};    

function updatePage(){
	var e = document.getElementById("yearSelector");
	var year = e.options[e.selectedIndex].value + '-';
	var e = document.getElementById("monthSelector"); 
	var month = e.options[e.selectedIndex].value;
	/*var e = document.getElementById("stgSelector"); 
	var stgId = e.options[e.selectedIndex].value;*/

	if (month < 10)
		month = '0' + month;
	var date = year + month + '-01';
	var form = document.createElement("form");
	form.setAttribute("method", "POST");
	
	var hiddenField = document.createElement("input");
	hiddenField.setAttribute("type", "hidden");
	hiddenField.setAttribute("name", 'date');
	hiddenField.setAttribute("value", date);

	/*var hiddenField2 = document.createElement("input");
	hiddenField2.setAttribute("type", "hidden");
	hiddenField2.setAttribute("name", 'stationgroup_id');
	hiddenField2.setAttribute("value", stgId);*/

	form.appendChild(hiddenField);
	//form.appendChild(hiddenField2);
	
	document.body.appendChild(form);
	form.submit();	
}