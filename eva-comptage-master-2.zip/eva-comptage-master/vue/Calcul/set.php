<?php
$page['container']['calc_form'] = '
  <div id="calc_form">
    <form>
    ' . $msg['ouvrage_input'] . '
    </form>
  </div>';

?>