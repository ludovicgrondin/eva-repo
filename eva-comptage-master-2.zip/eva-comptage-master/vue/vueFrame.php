<?php

$page['container']['frameSet'] = '
  <html>
    <head>'
      .$page['css']
      .$page['script'].
    '</head>
    <body>'
      .$page['container']['header']
      .$page['container']['main']
      .$page['container']['footer'].
    '</body>
  </html>';

?>