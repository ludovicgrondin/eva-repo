<?php
require_once "model/modelCalcul.php";
require_once "model/modelOuvrage.php";

if($_POST && $_POST['ouv'])
{
	$calcul = new Calcul();
	$name_parts = array(' Energy A+ Rate 1', ' Energy A+ Rate 2', ' Energy A+ Rate 1', ' Energy A+ Rate 2');
	foreach ($_POST['ouv'] as $name) {
		foreach ($name_parts as $name_part) {
			$calcul.addVal($name . $name_part, Ouvrage::getValByName());
		}
	}
}

$ret = $calcul->getCalcul();
$ouvrage_tab = array("O1", "O2", "O3", "O4", "O5"); // As récup de la db / entré utilisateur 

$msg['ouvrage_input'] = '';
foreach ($ouvrage_tab as $elem) {
	$msg['ouvrage_input'] .= '<label class="checkbox-inline"><input type="checkbox" value="' . $elem . '" />' . $elem . '</label><br />';
}
//var_dump($msg);
$msg['calc_str'] = $ret['str'];
$msg['calc_val'] = $ret['value'];


?>