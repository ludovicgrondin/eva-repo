-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2017 at 04:26 PM
-- Server version: 5.7.17-0ubuntu0.16.04.1
-- PHP Version: 7.0.13-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comptage`
--

-- --------------------------------------------------------

--
-- Table structure for table `bilan`
--

CREATE TABLE `bilan` (
  `bilan_id` int(11) NOT NULL,
  `station_station_id` int(11) NOT NULL,
  `bilan_date` datetime NOT NULL,
  `bilan_kwh` float NOT NULL,
  `bilan_puht` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_address` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `device_id` int(10) NOT NULL,
  `station_station_id` int(10) NOT NULL,
  `device_name` varchar(100) NOT NULL,
  `device_alias` varchar(100) NOT NULL,
  `device_description` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `facture`
--

CREATE TABLE `facture` (
  `facture_id` int(11) NOT NULL,
  `facture_number` varchar(100) NOT NULL,
  `facture_date` datetime NOT NULL,
  `facture_period` datetime NOT NULL,
  `facture_zone` varchar(100) NOT NULL,
  `facture_total_letter` varchar(255) NOT NULL,
  `stationgroup_stationgroup_id` int(11) NOT NULL,
  `client_client_id` int(11) NOT NULL,
  `facture_total_number` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `index`
--

CREATE TABLE `index` (
  `index_id` int(10) NOT NULL,
  `device_device_id` int(10) NOT NULL,
  `index_date` datetime NOT NULL,
  `index_rate_+1_value` float NOT NULL,
  `index_rate_+1_operator` varchar(1) NOT NULL DEFAULT '+',
  `index_rate_+2_value` float NOT NULL,
  `index_rate_+2_operator` varchar(1) NOT NULL DEFAULT '+',
  `index_rate_-1_value` float NOT NULL,
  `index_rate_-1_operator` varchar(1) NOT NULL DEFAULT '-',
  `index_rate_-2_value` float NOT NULL,
  `index_rate_-2_operator` varchar(1) NOT NULL DEFAULT '-',
  `index_status` tinyint(4) NOT NULL DEFAULT '1',
  `index_fromuser` tinyint(1) NOT NULL DEFAULT '0',
  `index_calc_dir` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(6) NOT NULL,
  `station_name` varchar(100) NOT NULL,
  `station_alias` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stationgroup`
--

CREATE TABLE `stationgroup` (
  `stationgroup_id` int(11) NOT NULL,
  `stationgroup_name` varchar(255) NOT NULL,
  `stationgroup_alias` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `station_stationgroup_relations`
--

CREATE TABLE `station_stationgroup_relations` (
  `sgr_id` int(11) NOT NULL,
  `stationgroup_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`bilan_id`),
  ADD UNIQUE KEY `bilan_id` (`bilan_id`,`station_station_id`,`bilan_date`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`device_id`),
  ADD UNIQUE KEY `device_name` (`device_name`);

--
-- Indexes for table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`facture_id`),
  ADD UNIQUE KEY `facture_number` (`facture_number`);

--
-- Indexes for table `index`
--
ALTER TABLE `index`
  ADD PRIMARY KEY (`index_id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`),
  ADD UNIQUE KEY `station_name` (`station_name`);

--
-- Indexes for table `stationgroup`
--
ALTER TABLE `stationgroup`
  ADD PRIMARY KEY (`stationgroup_id`);

--
-- Indexes for table `station_stationgroup_relations`
--
ALTER TABLE `station_stationgroup_relations`
  ADD PRIMARY KEY (`sgr_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `bilan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `device_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT for table `facture`
--
ALTER TABLE `facture`
  MODIFY `facture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `index`
--
ALTER TABLE `index`
  MODIFY `index_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;
--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `station_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `stationgroup`
--
ALTER TABLE `stationgroup`
  MODIFY `stationgroup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `station_stationgroup_relations`
--
ALTER TABLE `station_stationgroup_relations`
  MODIFY `sgr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
